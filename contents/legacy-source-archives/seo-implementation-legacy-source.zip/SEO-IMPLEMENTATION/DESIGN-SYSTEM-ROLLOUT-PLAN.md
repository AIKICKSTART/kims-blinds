# Design System Rollout Plan — Public Website + Content Pages

## Goal
Promote the approved `/design-system` direction across the public website at `/` and every content-page family without introducing one-off page UI. The design-system page remains the source of truth; production pages should only use shared components, shared tokens, and route/data patterns that can be mirrored by the static generator.

## Current State
- `/design-system` documents the preferred header chrome, green action system, card materials, typography, product-library components, form states, accessibility rules, governance and website adoption gate.
- `/`, `/services/security-doors`, `/blog/security-door-cost-sydney`, and `/contact` already use the main visual language: graphite header, chrome nav/actions, Source Serif display type, Shire green proof accents, card surfaces, trust bars, footer and contact dock.
- Route inventory is large: 5 services, 1,102 suburb pages, 5,510 service-suburb pages, 41 blog posts and 18 core pages. The implementation must update route templates and data-driven rendering, not hand-style individual pages.
- Static generation matters: `scripts/generate-static-pages.mjs` writes crawlable HTML for representative routes. Any public content-shape change in React must be mirrored where static HTML is generated.

## Locked Design Decisions
- **Material language:** dark graphite header, chrome-ring buttons, Shire green action states, light card fields, restrained product-family accents.
- **Typography:** Source Serif 4 for page and section authority; Söhne/Manrope for body/UI; IBM Plex Mono for proof labels, metadata and specs.
- **Primary chrome:** `SiteHeader`, `SiteFooter`, `ContactDock`, `site-action`, trust bars and breadcrumbs stay shared. Do not create page-specific header/footer variants.
- **Card system:** service, feature, report, pricing, proof, product and quote cards should inherit the shared card material contract instead of custom per-page boxes.
- **Assets:** use the approved `/brand/*` product, hero, logo, dealer and avatar assets already registered in the design system.

## Route Family Plan

### 1. Website Shell
Apply to every public route.
- Keep `WebsiteShell` as the only production wrapper for header, breadcrumbs, footer and dock.
- Confirm all pages inherit the same token stack from `src/website.css`.
- Preserve crawlable breadcrumbs and matching BreadcrumbList schema.
- Keep `/design-system` and `/components` as internal reference routes, excluded from sitemap/robots.

### 2. Homepage `/`
Current visual alignment is strong. Treat as the baseline production specimen.
- Keep split hero, dealer proof, trust stats, product cards, testimonial, guide cards and final CTA.
- Tighten any cards that do not use shared `FeatureCard`, `ServiceCard`, `TrustBar`, `CTASection` or `FAQAccordion` patterns.
- Use homepage as the visual reference for service-page and guide-page spacing.

### 3. Services Hub + Service Pages
Routes: `/services`, `/services/:service`.
- Use one service-page template for all five product families: security doors, security screens, fly screens, plantation shutters and outdoor blinds.
- Required section order: hero, answer-first intro, product/range cards, proof/spec cards, process, coastal/local notes, service areas, FAQ, related products, CTA.
- Use product-family accents only through the shared card material variants; no bespoke palette per service.
- Promote design-system product-library components where useful: `ProductRangeCard`, `SpecTileGrid`, `ProofBadge`, `ProductTechnologyGrid`, `BrochureModule`.

### 4. Local Pages
Routes: `/suburbs`, `/suburbs/:suburb`, `/services/:service/:suburb`.
- Keep the content data-driven from `seoSite.ts` and `suburbs80km.ts`.
- Use a consistent local-page module set: local hero, trust strip, service checklist, nearby/priority suburb links, map/service-area proof, FAQ and quote CTA.
- Avoid bespoke suburb styling. Rich priority suburbs can have unique copy, but the same visual grammar must hold across all local pages.
- Static generator must keep rendering crawlable local content for priority static pages.

### 5. Blog and Guide Pages
Routes: `/blog`, `/blog/:post`.
- Build one article template that uses the design system fully: article hero, Steve byline/review line, trust strip, key product notes, article card sections, key questions accordion, related services, related guides and CTA.
- Replace any plain article grids that feel like raw SEO content with shared card/report/product modules.
- Keep answer-first summaries and question headings for GEO, but present them through the Shire card system.
- Ensure static HTML mirrors article body, related links, FAQs and schema.

### 6. Commercial Decision Pages
Routes: `/pricing`, `/comparison/prowler-proof-vs-crimsafe`, `/faq`.
- Pricing: use pricing cards, quote-path proof, product-family cost bands, FAQ and quote CTA.
- Comparison: use report/comparison cards, proof rails, table overflow handling, brand-neutral explanation, FAQ and service links.
- FAQ: group questions by category using shared accordions and trust/CTA modules.

### 7. Trust, Legal and E-E-A-T Pages
Routes: `/about`, `/warranty`, `/testimonials`, `/privacy-policy`, `/terms-of-service`.
- About: use Steve/credentials proof cards, owner story, service proof and CTA. Swap in real photos when supplied.
- Warranty: use proof badges, FAQ and quote reassurance.
- Testimonials: use shared testimonial/proof cards, but do not add self-serving review schema.
- Privacy/Terms: keep readable legal content, but still use site shell, section spacing, breadcrumbs and footer chrome.

### 8. Contact Page
Current alignment is strong.
- Keep the contact form, trust proof, response promise, service-area card and footer.
- Make the service-area/map module resilient when the embedded map does not load.
- Keep form field count and submit copy aligned with CRO rules.

## Implementation Phases

### Phase 1 — Audit and Lock
- Compare screenshots for `/design-system`, `/`, `/services/security-doors`, `/blog/security-door-cost-sydney`, `/contact`, `/pricing`, `/faq`, `/comparison/prowler-proof-vs-crimsafe`, `/suburbs/cronulla`, and `/services/security-doors/cronulla`.
- Document any drift as route-family issues, not isolated page nits.

### Phase 2 — Shared Component Tightening
- Add only missing shared components that remove repeated route markup.
- Prefer extending existing components in `src/components/shared` over new abstractions.
- Keep CSS token-driven in `src/website.css`; avoid page-specific overrides unless they describe a real template role.

### Phase 3 — Route Template Promotion
- Update `src/pages/WebsitePage.tsx` templates by route family.
- Keep `src/data/seoSite.ts` as the content source for services, guides, FAQs, comparison data and rich suburb content.
- Do not hand-code one-off page sections that cannot be generated from data.

### Phase 4 — Static Rendering Parity
- Mirror React content-shape changes in `scripts/generate-static-pages.mjs`.
- Verify static output still includes full article bodies, FAQs, related links, breadcrumbs and JSON-LD.
- Keep sitemap/route inventory counts consistent after build.

### Phase 5 — Verification
- Run `npm run build`.
- Capture desktop and mobile Playwright screenshots for the route families listed in Phase 1.
- Check 320px, 390px, 768px, 1440px and wide desktop for overflow, cropped text and broken sticky chrome.
- Keyboard-check header menu, accordions, form fields and primary CTAs.
- View-source representative static routes to confirm crawlable content remains present.

## Acceptance Criteria
- All public route families visibly match the approved `/design-system` language.
- No new one-off header, footer, button, card, form, FAQ or CTA styles are introduced.
- Service, suburb, blog, commercial, trust and legal pages all use shared components and shared tokens.
- `npm run build` passes.
- `dist/static-page-report.json` and route inventory remain coherent.
- Representative desktop/mobile screenshots are saved under `output/playwright/`.
- Static HTML remains rich and crawlable for representative content pages.

## Current Evidence
- Design system screenshot: `output/playwright/rollout-design-system-desktop.png`
- Homepage screenshots: `output/playwright/rollout-home-desktop.png`, `output/playwright/rollout-home-mobile.png`
- Service page screenshot: `output/playwright/rollout-service-desktop.png`
- Blog guide screenshot: `output/playwright/rollout-blog-desktop.png`
- Contact page screenshot: `output/playwright/rollout-contact-desktop.png`
