# Implementation Plan — Phased Waves

Execution via agent teams + direct surgical edits. Each wave ends with `npm run build` verification.

## Architecture decision: reconcile triplicated data
Before mass content work, reduce the 3-way data duplication risk. **Chosen approach (low-risk):** keep `seoSite.ts` as canonical; make the two `.mjs` scripts *import the compiled data where feasible*, OR enforce a strict sync checklist per change. Given `.mjs` can't easily import `.ts`, we keep manual sync but add rich-content rendering to the static generator so blog `articleBlocks`/`keyQuestions` render to crawlable HTML (fixes thin-HTML gap #4). This is the single highest-SEO-leverage architectural fix.

---

## WAVE 1 — Foundation / Technical (direct edits, low risk)
Files: `scripts/generate-seo-files.mjs`, `public/robots.txt`, `public/llms.txt`, `src/pages/WebsitePage.tsx`, `index.html`.
- TECH-02/03: robots.txt AI crawlers + correct sitemap URL + exclude /design-system,/components.
- TECH-22: create `/public/llms.txt`.
- TECH-01/sitemap: priority + changefreq + exclude dev routes; real lastmod ok-as-today.
- TECH-05: `<html lang="en-AU">` in index.html + static template.
- SCHEMA-08: BreadcrumbList builder + visible breadcrumbs on non-home pages.
- SCHEMA-07: data-driven FAQPage schema (matches visible FAQ) — fix hardcoded single-Q.
- SCHEMA-01/02/04/05: upgrade homepage to `@graph` (WebSite+Org+LocalBusiness+Service).
- SCHEMA-06: Service schema provider→@id.
- SCHEMA-10: Article/BlogPosting w/ author Steve + dates.
- ONPAGE-01..17: exact titles/metas/H1s in `getMeta` + components.
- CRO-04/TECH-19: sticky mobile click-to-call (QuickContactDock already exists — verify/upgrade).
- TECH-16: audit all phone refs → tel:.

## WAVE 2 — Ready-written content integration
Files: `seoSite.ts`, `WebsitePage.tsx`, both scripts.
- CONTENT-02: FAQ page → 26 Qs data-driven + FAQPage schema (5 categories).
- CONTENT-01: Comparison page → full ForceField vs Crimsafe content + table + 10-Q FAQ.
- CONTENT-04: Pricing page → full pricing guide tables + 9-Q FAQ; also blog mirror.
- CONTENT-03/LOCAL-17: Sutherland Shire pillar page + hub-and-spoke links.

## WAVE 3 — Static generator rich rendering (architectural fix #4)
File: `scripts/generate-static-pages.mjs`.
- Render full `articleBlocks`, `keyQuestions` (FAQ), comparison tables, breadcrumbs into static HTML.
- Emit matching FAQPage/Article/BreadcrumbList JSON-LD in static HTML.
- Keep data sync helper/checklist.

## WAVE 4 — Tier-1 new content pages (agent team, parallel)
Add as rich blog posts / guides in `seoSite.ts` (+ script sync):
- CONTENT-05 buying guide, CONTENT-09 window screens guide, CONTENT-10 cleaning guide.
- CONTENT-06/07/08 Cronulla/Miranda/Caringbah rich suburb content.

## WAVE 5 — E-E-A-T + legal pages
- EEAT-02/08 About/Meet Steve (Person schema), EEAT-10 Privacy + Terms, CONTENT-31 Testimonials, CONTENT-32 Warranty.
- Footer links to all; byline system (EEAT-01).

## WAVE 6 — Tier-2/3 content + suburb upgrades (agent team, batched)
- CONTENT-11..18 Tier-2 guides; CONTENT-19..29 suburb upgrades; CONTENT-30/33/36/37 extra.
- Apply suburb content formula (CONTENT-39).

## WAVE 7 — Internal linking sweep + CRO polish
- LINK-01..12 across all pages; CRO-01/03/06/07/08/09/10/13/14/15/17.

## WAVE 8 — Verify + handoff
- `npm run build`; validate schema; check sitemap; write OWNER-HANDOFF.md (owner-only items).
- Lighthouse/CWV spot check.

---
## Progress log

### 2026-06-18 — Session 1
**Wave 1 (Foundation) — DONE & build-verified:**
- robots.txt: AI crawlers (GPTBot, OAI-SearchBot, ChatGPT-User, ClaudeBot, Claude-Web, PerplexityBot, Google-Extended, Applebot-Extended, Bingbot) allowed; /design-system + /components disallowed. [TECH-02, TECH-03]
- public/llms.txt created with business + services + key resources. [TECH-22]
- sitemap.xml: per-route priority + changefreq; dev routes excluded. [TECH-01 partial]
- `<html lang="en-AU">`. [TECH-05]
- Schema rebuilt as composable @graph nodes with stable @id: homepage WebSite+Organization+LocalBusiness(HomeAndConstructionBusiness, full address/geo/hours/credential/areaServed/potentialAction)+Service catalog; Service schema (provider→@id) on service pages; BlogPosting w/ Person(Steve) author on posts; data-driven FAQPage; BreadcrumbList on all non-home pages. [SCHEMA-01,02,03,04,05,06,07,08,10,13]
- Visible breadcrumb nav + CSS (matches BreadcrumbList). [TECH-11]
- Exact report titles + meta descriptions for home/services/suburbs/blog/pricing/faq/comparison/contact + 4 named service pages (serviceMetaOverrides). [ONPAGE-01..12]
- Header utility action now shows tappable phone number (tel:). QuickContactDock (sticky call/contact/email) confirmed present. [TECH-16,20; CRO-04,05; TECH-19]
- Enriched `business` constants in seoSite.ts (streetAddress, locality, region, postcode, country, geo, openingHours, priceRange, phoneE164, licenceNumber, owner).

**Wave 2 (Ready content) — IN PROGRESS:**
- CONTENT-02 FAQ page: 26 Q&As (full written content) in 6 categories, answer-first intro hero, per-category accordions, CTA; FAQPage schema auto-generated from the visible list. DONE (tsc clean).
- CONTENT-01 Comparison, CONTENT-04 Pricing, CONTENT-03 Shire pillar — pending.

**Wave 3 (static generator rich rendering) — DELEGATED:** background agent rewriting scripts/generate-static-pages.mjs (titles/metas sync, rich blog body, FAQ+Breadcrumb+@graph schema). Awaiting completion before next full build.

**Wave 2 cont. — DONE this session:**
- CONTENT-01 Comparison page fully rewritten in React: answer-first H1 intro, "why compare" section, 12-row side-by-side table, welded-vs-screw-clamp, coastal, warranty comparison, 10-Q FAQ, CTA; FAQPage schema (10 Q) wired. Build green.
- Full build verified end-to-end (1,249 static pages). Wave-3 static generator now renders rich blog bodies + correct titles/metas + @graph + breadcrumbs.

**Single-source reconciliation — DELEGATED (background agent aaa3f28):** moving faqItems(26)/comparisonRows(12)/comparisonFaqItems(10) into seoSite.ts as the single source for both React + static generator, and rendering full /faq (26 Q) and /comparison bodies into static HTML (fixes the static-vs-React drift). Owns seoSite.ts + WebsitePage.tsx + generate-static-pages.mjs. Build-verifies itself.

**Deliverables written:** SPEC.md, MASTER-CHECKLIST.md (153 items), IMPLEMENTATION-PLAN.md, OWNER-HANDOFF.md.

### Remaining waves (next loop iterations):
- Wave 2 finish: CONTENT-04 Pricing page full (read pricing md, expand PricingPage + tables + 9-Q FAQ); CONTENT-03 Sutherland Shire pillar page (new route + hub-and-spoke links to suburbs).
- Wave 4: Tier-1 new pages as rich blog posts/guides (CONTENT-05 buying guide, 09 window screens guide, 10 cleaning guide HowTo) + CONTENT-06/07/08 Cronulla/Miranda/Caringbah rich suburb content. (Data added to seoSite.ts blogPosts + both scripts synced; OR via new route kinds.)
- Wave 5: About/Meet Steve (Person schema), Warranty, Privacy, Terms, Testimonials — new routes in matcher/render/getMeta + sitemap corePages + static gen + footer legal links (/privacy→/privacy-policy, /terms→/terms-of-service) + credential badges (EEAT-05/06).
- Wave 6: Tier-2/3 content (CONTENT-11..18, 30,33,36,37) + suburb content formula (CONTENT-39) for priority suburbs.
- Wave 7: internal-linking sweep per LINK-01..12 (cross-service, hub-and-spoke, related-guides on each page) + CRO copy (first-person CTAs, trust badges, ≤5-field form, response-time promise).
- Wave 8: final build + schema validation (Rich Results), flip MASTER-CHECKLIST boxes, finalise OWNER-HANDOFF.

### NOTE — architecture reminder for every content add:
Route/content data is effectively triplicated across `seoSite.ts`, `generate-static-pages.mjs`, `generate-seo-files.mjs`. Blog posts AND blog slugs now parse from seoSite.ts (both scripts) — a new guide is a ONE-FILE edit (seoSite.ts blogPosts). New CORE routes still need: WebsitePage matcher/renderRoute/getMeta + generate-static-pages.mjs (routes + pageContent) + generate-seo-files.mjs (corePages). Always `npm run build` to verify.

### 2026-06-18 — Session 1 (cont.)
- **Single-source reconciliation DONE:** faqItems(27)/comparisonRows(12)/comparisonFaqItems(10) moved to seoSite.ts; React + static both consume; static /faq shows 27 Q, /comparison full. Build green.
- **generate-seo-files.mjs** now parses blog slugs from seoSite.ts (removed hardcoded list) — sync point eliminated.
- **Wave 4 DONE (agent):** 6 thin blog posts upgraded to rich guides (build green, 1,249 pages): `security-door-cost-sydney` (pricing guide, 9 FAQ), `ultimate-security-door-buying-guide-sydney` (pillar ~2,100w), `security-window-screens-home-security`, `security-door-maintenance-coastal-homes` (HowTo), `complete-guide-security-doors-sutherland-shire` (Shire pillar), `as-5039-security-doors-explained`. [CONTENT-04,05,09,10,03,33]
- **Wave 5 DISPATCHED (agent a5c9af4):** new core routes /about (Person schema), /warranty (FAQ), /testimonials (no review schema), /privacy-policy, /terms-of-service + footer links. Owns WebsitePage.tsx + both scripts; build-verifies.
- KNOWN: static blog `relatedServiceSlugs` cards render client-side only (not in static HTML) — fix in Wave 7 (render related links in static postBody).

### Still remaining after Wave 5:
- Wave 6: upgrade more thin blog posts to rich (forcefield-vs-crimsafe blog, security-screens-vs-fly-screens, 316-marine-grade-stainless-steel, best-security-doors-coastal-areas, sliding-vs-hinged, cheap-security-door-compliance-risk, verify-installer, replace-old-security-door, welded-vs-screwed, holiday-home-security, case studies, plantation/outdoor/fly cost+product guides) + rich suburb content for priority suburbs (Cronulla/Miranda/Caringbah — CONTENT-06/07/08, CONTENT-39 formula via ServiceSuburb/Suburb intros in seoSite.ts).
- Wave 7: internal-linking sweep (LINK-01..12) incl. rendering related links in static; CRO copy (first-person CTAs, trust badges row, ≤5-field form check, response-time promise, service-specific CTAs).
- Wave 8: final `npm run build`, schema validation (Rich Results), flip MASTER-CHECKLIST boxes, finalise OWNER-HANDOFF.
