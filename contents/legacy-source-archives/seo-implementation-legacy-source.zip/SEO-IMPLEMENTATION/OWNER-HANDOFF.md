# Owner Handoff — Items That Cannot Be Done in Code

These report recommendations require account access, external platforms, business data, or photography that only the business owner (Steve / Daniel) can provide. The website code is being built to support all of them (schema fields, badge slots, review display, etc.), but the actions below must be completed by the owner.

## Accounts & verification
- [ ] **TECH-21** Register & verify in **Bing Webmaster Tools** (bing.com/webmasters); submit `https://shiresecuritydoors.com.au/sitemap.xml`. (87% of ChatGPT citations come from Bing's index.)
- [ ] Verify site in **Google Search Console**; submit sitemap; monitor the Enhancements (schema) report weekly. [SCHEMA-16]
- [ ] Confirm the production domain. Code is standardised on `https://shiresecuritydoors.com.au`. If the live domain differs, update `business.baseUrl` in `src/data/seoSite.ts` (one place) and rebuild.

## Google Business Profile (LOCAL-01..06)
- [ ] Primary category "Security System Installer"; add up to 9 secondary categories (Window Supplier, Screen Store, Security Service, Home Improvement Shop, Door Shop, Window Installation Service, Building Materials Supplier, Fencing Supply Store).
- [ ] 750-char GBP description (draft in report §4.1.2) incl. Licence #000105713, Prowler Proof dealer, NSSA, 10-yr warranty.
- [ ] Upload 20+ geotagged photos across team/product/before-after/on-site/credentials; add 2–3 monthly.
- [ ] 100% profile completion; add up to 20 Shire suburbs as service areas; 1 GBP post/week.

## NAP & citations (LOCAL-07..13)
- [ ] Canonical NAP everywhere: "Shire Security Doors and Screens", Engadine NSW 2233, 0410 474 256.
- [ ] Submit to top-20 AU directories (3 tiers, list in report §4.2.2). Claim NSSA + Prowler Proof dealer listings. ProductReview.com.au.
- [ ] NAP audit + quarterly re-audit.

## Reviews (LOCAL-14..16, EEAT-12)
- [ ] 5–10 new Google reviews/month; 50+ at 4.5★ within 90 days. SMS request system + respond within 24h (templates in report §4.3.2/3).

## GEO off-site (GEO-07..14)
- [ ] Brand-mention program: Reddit (r/Sydney, r/HomeImprovement), Whirlpool/Homeone forums, Quora, SourceBottle expert profile.
- [ ] Publish original "Sutherland Shire Home Security Report" survey (needs 20–30 customer responses) — high-value citation asset.
- [ ] GEO baseline audit (test 25–30 prompts across ChatGPT/Perplexity/Google AI) + weekly scorecard.

## Local link building (LOCAL-20..27)
- [ ] Sutherland Shire Business Chamber membership; sponsor local junior sports club; community directories; local press (The Leader); guest posts.

## Assets needed for E-E-A-T / CRO pages (provide to dev)
- [ ] Professional photo of Steve (not stock) — for About/Meet Steve page. [EEAT-02]
- [ ] 5–6 real before/after installation photos + named customer testimonials w/ suburb. [EEAT-04, CRO-10/12]
- [ ] 1 short (60–90s) video testimonial. [CRO-11]
- [ ] Confirm founding year (report says 2005; written content says "since 2014") — needed for `foundingDate` schema. Currently omitted to avoid asserting a wrong date.
- [ ] Social profile URLs (Facebook, Instagram, LinkedIn, GBP) for Organization `sameAs` schema — currently omitted (no fabricated URLs).

## Back-end / infra (CRO-18, TECH-06/24)
- [ ] Instant lead notifications to phone + email; missed-call auto-text.
- [ ] Optionally add `@vercel/speed-insights` for live Core Web Vitals (needs deploy access). [TECH-06]
- [ ] A/B testing program for CTA colour/copy/placement. [CRO-02/19]

## KPI tracking (KPI-01..04)
- [ ] Set up dashboards: GSC, Ahrefs/SEMrush, Vercel Speed Insights, Local Falcon, GA4 (track chatgpt.com / perplexity.ai referrals).
