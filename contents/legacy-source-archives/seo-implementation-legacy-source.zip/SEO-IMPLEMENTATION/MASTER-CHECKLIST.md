# Shire Security Doors & Screens — Master SEO/GEO Implementation Checklist

> Source: Kimi_Agent SEO Report (final report + sec00–12 + research/ + 4 written content pages).
> 153 actionable items across 9 categories + cross-cutting KPIs.
> Status legend: `[ ]` todo · `[~]` in progress · `[x]` done · `[-]` n/a-or-deferred.
> Canonical decisions (locked): domain `https://shiresecuritydoors.com.au` · phone `0410 474 256` / `tel:0410474256` · email `steve@shiredoors.com.au` · address Engadine NSW 2233 · Licence #000105713.

---

## 1. Technical SEO
- [x] **TECH-01** — XML sitemap incl. all routes, lastmod + priority. (script: generate-seo-files.mjs)
- [x] **TECH-02** — Fix robots.txt sitemap reference to resolving canonical URL.
- [x] **TECH-03** — robots.txt explicitly allow AI crawlers: GPTBot, OAI-SearchBot, ChatGPT-User, ClaudeBot, PerplexityBot, BingBot, Google-Extended, Applebot-Extended. Keep `User-agent: *` / `Allow: /`.
- [x] **TECH-04** — Self-referencing canonical on every page.
- [x] **TECH-05** — `<html lang="en-AU">` + self-referencing `hreflang="en-AU"`.
- [ ] **TECH-06** — Vercel Speed Insights (`@vercel/speed-insights`) in root.
- [ ] **TECH-07** — Meet CWV: LCP<2.5s, INP<200ms, CLS<0.1, TTFB<200ms, FCP<1.8s.
- [x] **TECH-08** — Images: explicit width/height, WebP/AVIF, lazy below fold.
- [x] **TECH-09** — Hero images `fetchpriority=high`; gallery lazy.
- [x] **TECH-10** — Image `sizes` attribute set.
- [x] **TECH-11** — Visible breadcrumb nav on all non-home pages (matches BreadcrumbList schema).
- [x] **TECH-12** — URL architecture patterns maintained as site expands.
- [x] **TECH-13** — Topical silo architecture (pillar + cluster per service).
- [x] **TECH-14** — Responsive 320–1440px.
- [x] **TECH-15** — Touch targets ≥44×44px.
- [x] **TECH-16** — All phone numbers as `tel:` links (header, footer, inline, CTAs).
- [ ] **TECH-17** — Mobile page speed <3s; no intrusive interstitials.
- [x] **TECH-18** — Input font-size ≥16px (prevent iOS zoom).
- [x] **TECH-19** — Sticky mobile click-to-call button (hidden >768px).
- [x] **TECH-20** — Phone prominent in mobile header (tappable).
- [ ] **TECH-21** — Bing Webmaster Tools verify + submit sitemap (manual/owner).
- [x] **TECH-22** — `/llms.txt` at root.
- [x] **TECH-23** — Verify SSR: View-Source shows headings/content/alt/schema without JS.
- [ ] **TECH-24** — Third-party scripts async/lazy.
- [ ] **TECH-25** — HTTPS everywhere, no mixed content (Vercel-managed).

## 2. On-Page SEO
- [x] **ONPAGE-01..06** — Exact title tags per page (home, security-doors, security-screens, plantation-shutters, outdoor-blinds, contact).
- [x] **ONPAGE-07..12** — Exact meta descriptions per page.
- [x] **ONPAGE-13..17** — Exact H1s (`{Service} in Sutherland Shire`).
- [x] **ONPAGE-18** — Security Doors H2/H3 sequence (Problem→Solution→Proof→Next Step).
- [x] **ONPAGE-19** — Question-form H2/H3 mirroring queries; answer in first 1–2 sentences.
- [x] **ONPAGE-20** — Logical heading hierarchy, no skips, no styling-by-heading.
- [x] **ONPAGE-21** — Service pages ≥800 words (Security Doors 1,000–1,200).
- [x] **ONPAGE-22** — Homepage 600–900 words.
- [x] **ONPAGE-23** — Per service page: answer-first 60–80w, product range, coastal content, suburb list, FAQ 5–8, social proof.
- [x] **ONPAGE-24** — NSW Police 80% burglary stat on Security Doors page.
- [x] **ONPAGE-25** — Keyword density 1–2%, primary kw in title/meta/H1/first-100w/≥1 H2/alt/anchor.
- [x] **ONPAGE-26** — Security Doors first 100w includes "security doors" + "Sutherland Shire".
- [x] **ONPAGE-27** — LSI/semantic keywords per page.
- [x] **ONPAGE-28** — Branded product keywords on respective pages (ForceField, Protec, Guardian, Diamond).
- [x] **ONPAGE-29** — Descriptive alt text on every image (kw + geo).
- [x] **ONPAGE-30** — Descriptive hyphenated image filenames.
- [x] **ONPAGE-31** — WebP/AVIF + JPEG fallback.

## 3. Schema / Structured Data
- [x] **SCHEMA-01** — Homepage `@graph`: WebSite + Organization + LocalBusiness(HomeAndConstructionBusiness) + Service hasOfferCatalog.
- [x] **SCHEMA-02** — LocalBusiness full fields (address, geo ≥5dp, hours, priceRange, telephone E.164, areaServed, hasCredential, memberOf, potentialAction).
- [x] **SCHEMA-03** — `addressCountry: "AU"`.
- [x] **SCHEMA-04** — Organization on every page, stable `@id`, sameAs array.
- [x] **SCHEMA-05** — WebSite schema on homepage, inLanguage en-AU.
- [x] **SCHEMA-06** — Service schema on each service page (general `Service` type, provider→LocalBusiness @id).
- [x] **SCHEMA-07** — FAQPage schema on each service page + FAQ page; visible text matches; 2 highest-value Qs first; NOT on homepage.
- [x] **SCHEMA-08** — BreadcrumbList schema on all non-home pages, matches visible breadcrumb.
- [x] **SCHEMA-09** — HowTo schema on step-by-step guides.
- [x] **SCHEMA-10** — Article/BlogPosting schema on blog posts w/ author + dates.
- [-] **SCHEMA-11** — Product schema on product detail pages (if created).
- [x] **SCHEMA-12** — Person schema for Steve on author page.
- [x] **SCHEMA-13** — Licence #000105713 in hasCredential.
- [x] **SCHEMA-14** — NO self-serving review/aggregateRating on LocalBusiness/Organization.
- [x] **SCHEMA-15** — Validate all schema (Rich Results + Schema.org + JSONLint), zero errors.
- [ ] **SCHEMA-16** — Phased schema rollout + GSC Enhancements monitoring (owner).

## 4. GEO / AI-Search
- [x] **GEO-01** — Answer-first 50–80w lead on every content page.
- [x] **GEO-02** — Three-layer architecture (answer / body 800–1,200w / FAQ schema) on every content page.
- [x] **GEO-03** — Specific statistics/hard data on every page.
- [x] **GEO-04** — Atomic answers (self-contained 40–60w under H2s + FAQ).
- [x] **GEO-05** — Exact user-question H2/H3; listicle/numbered formats.
- [x] **GEO-06** — Cover 30+ conversational queries mapped to pages.
- [ ] **GEO-07** — Brand-mention frequency program (owner/marketing).
- [ ] **GEO-08** — Reddit participation (owner).
- [ ] **GEO-09** — AU forums/Quora participation (owner).
- [ ] **GEO-10** — SourceBottle expert profile (owner).
- [ ] **GEO-11** — Original research report (Sutherland Shire Home Security Report) — page asset + survey (owner-data).
- [ ] **GEO-12** — GEO baseline audit (owner).
- [ ] **GEO-13** — GEO KPI tracking (owner).
- [ ] **GEO-14** — Monthly AI visibility audit (owner).

## 5. Content Pages to Create
**Ready-written (integrate):**
- [x] **CONTENT-01** — ForceField vs Crimsafe → `/comparison/prowler-proof-vs-crimsafe` (exists, expand to full written content).
- [x] **CONTENT-02** — FAQ → `/faq` (exists, expand to 26 Qs + FAQPage schema).
- [x] **CONTENT-03** — Sutherland Shire service area pillar → `/suburbs/sutherland-shire` or core page (build).
- [x] **CONTENT-04** — Security Door Pricing Guide → integrate into `/pricing` + `/blog/security-door-prices-sydney`.
**To write (Tier 1, Month 1):**
- [x] **CONTENT-05** — Security Doors Buying Guide (2,500w pillar) `/blog/security-door-buying-guide`.
- [x] **CONTENT-06** — Cronulla suburb page (rich, coastal/316 angle).
- [x] **CONTENT-07** — Miranda suburb page (rich).
- [x] **CONTENT-08** — Caringbah suburb page (rich).
- [x] **CONTENT-09** — Window Security Screens Guide `/blog/window-security-screens-sydney`.
- [x] **CONTENT-10** — How to Clean & Maintain Security Doors (HowTo) `/blog/how-to-clean-security-doors`.
**To write (Tier 2, Months 2–3):**
- [x] **CONTENT-11** — Security Screens vs Fly Screens.
- [x] **CONTENT-12** — Guardian Fall Prevention Window Screens.
- [x] **CONTENT-13** — Bushfire Security Screens & BAL Ratings.
- [x] **CONTENT-14** — Plantation Shutters Guide.
- [x] **CONTENT-15** — Outdoor Blinds Guide.
- [x] **CONTENT-16** — 316 vs 304 Stainless Steel.
- [x] **CONTENT-17** — Security Door Installation Process (HowTo).
- [x] **CONTENT-18** — Case Studies / Project Gallery.
**Suburb pages (rich, Tier 1–2):**
- [x] **CONTENT-19..27** — Sutherland, Gymea, Sylvania, Menai, Bangor, Como, Jannali, Engadine, Kirrawee (upgrade to rich content).
- [x] **CONTENT-28** — Remaining Shire suburbs (rich, batch).
- [x] **CONTENT-29** — St George corridor expansion pages.
**Additional content:**
- [x] **CONTENT-30** — Security Doors for Coastal Homes pillar.
- [x] **CONTENT-31** — Testimonials page.
- [x] **CONTENT-32** — Warranty Information page.
- [x] **CONTENT-33** — AS 5039 / Australian Standards page.
- [x] **CONTENT-34** — How-to series (measure, colours, prep, seasonal maintenance).
- [x] **CONTENT-35** — Seasonal content calendar pages.
- [x] **CONTENT-36** — Best Security Screen Brands blog post.
- [x] **CONTENT-37** — 10 expert blog posts (Steve byline).
- [x] **CONTENT-38** — 5 cluster pillar pages.
- [x] **CONTENT-39** — Suburb page content formula applied to every suburb page.

## 6. Internal Linking
- [x] **LINK-01** — Blog posts 3–5 contextual links/1,000w.
- [x] **LINK-02** — Service pages 5–8 links to support/related.
- [x] **LINK-03** — Homepage links to 8–12 key pages, 3 service pillars.
- [x] **LINK-04** — Every new page ≥2–3 inbound internal links (no orphans).
- [x] **LINK-05** — Descriptive anchor text (no "click here").
- [x] **LINK-06** — Cross-service linking journey.
- [x] **LINK-07** — Shire pillar ↔ all suburb pages (hub-and-spoke).
- [x] **LINK-08** — Suburb pages link to service pillars + adjacent suburbs.
- [x] **LINK-09** — Cluster pages ↔ pillar links.
- [x] **LINK-10** — Window Screens guide ↔ Guardian + Security Doors.
- [x] **LINK-11** — Seasonal/blog → 1–2 service pages + CTA.
- [x] **LINK-12** — Query/keyword → destination-page map applied.

## 7. E-E-A-T / Trust
- [x] **EEAT-01** — "Steve" named author byline on all content; link to author page.
- [x] **EEAT-02** — `/meet-steve` (or `/about`) with photo, credentials, story, Person schema.
- [x] **EEAT-03** — "Reviewed by" line on technical content.
- [ ] **EEAT-04** — 5–6 case studies w/ original photos.
- [x] **EEAT-05** — Licence #000105713 in header/footer + About + Contact + near forms.
- [x] **EEAT-06** — Credential badges w/ verification links.
- [x] **EEAT-07** — Industry content referencing AS 5039/5040/5041.
- [x] **EEAT-08** — About Us page (story, real photos, credentials, milestones).
- [x] **EEAT-09** — NAP prominent header/footer every page; identical across platforms.
- [x] **EEAT-10** — Privacy Policy + Terms of Service pages, footer-linked.
- [x] **EEAT-11** — SSL indicators near forms.
- [ ] **EEAT-12** — Review portfolio program (owner).

## 8. Local SEO (mostly owner/off-site)
- [ ] **LOCAL-01..06** — GBP categories, description, photos, completion, weekly posts.
- [ ] **LOCAL-07..08** — Canonical NAP + audit/correct across directories.
- [ ] **LOCAL-09** — Top-20 AU directory citations (3 tiers).
- [ ] **LOCAL-10..13** — NSSA, Prowler Proof dealer, trade-lead platforms, ProductReview.com.au.
- [ ] **LOCAL-14..16** — Reviews growth, SMS request system, response templates.
- [x] **LOCAL-17** — Shire anchor page (= CONTENT-03).
- [ ] **LOCAL-18** — Suburb rollout sequence.
- [x] **LOCAL-19** — Embedded Google Map on anchor + suburb pages.
- [ ] **LOCAL-20..27** — Local link building (chamber, sponsorship, community dirs, press, guest posts) (owner).

## 9. Conversion / CRO
- [x] **CRO-01** — Primary CTA "Get My Free Measure & Quote" above fold every page.
- [ ] **CRO-02** — A/B test CTA colour (owner).
- [x] **CRO-03** — First-person CTA copy + location variants.
- [x] **CRO-04** — Persistent mobile click-to-call split bar.
- [x] **CRO-05** — Desktop phone top-right header, tel: link.
- [x] **CRO-06** — Service-specific CTAs per page.
- [x] **CRO-07** — 3-badge trust row below hero CTA.
- [x] **CRO-08** — 10-Year Warranty badge in hero.
- [x] **CRO-09** — Trust microcopy below CTA.
- [ ] **CRO-10** — ≥5 testimonials per relevant page; below hero CTA on home.
- [ ] **CRO-11** — Video testimonial (owner-asset).
- [ ] **CRO-12** — Steve/team photos by testimonials.
- [x] **CRO-13** — Quote form ≤5 fields.
- [x] **CRO-14** — Phone field microcopy.
- [x] **CRO-15** — Submit button copy "Get My Free Quote — Steve Will Call Within 1 Hour".
- [x] **CRO-16** — Form placement rules per page type.
- [x] **CRO-17** — Response-time promise near form + thank-you page.
- [ ] **CRO-18** — Back-end lead notifications + missed-call auto-text (owner).
- [ ] **CRO-19** — Systematic CTA A/B program (owner).

## Cross-cutting KPIs (owner tracking)
- [ ] **KPI-01..04** — Traditional SEO / Local / GEO / Business KPIs.

---

### Owner-only items (cannot be done in code; flagged for handoff)
TECH-21 (Bing WMT), all GEO-07..14, SCHEMA-16 monitoring, LOCAL-01..16 & 20..27, EEAT-12, CRO-02/11/18/19, KPI-01..04. These require account access, external accounts, or business data and are documented in `OWNER-HANDOFF.md`.
