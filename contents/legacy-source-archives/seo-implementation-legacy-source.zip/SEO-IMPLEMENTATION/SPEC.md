# Perfected SEO/GEO Website — Specification

## Goal
Transform shiresecuritydoors.com.au into a launch-ready, SEO + GEO-perfected site: every report recommendation implementable in code is implemented; all ready-written content pages live; every internal-link suggestion wired; structured data complete and valid; answer-engine (ChatGPT/Perplexity/Google AIO) optimised.

## Locked decisions
- **Canonical domain:** `https://shiresecuritydoors.com.au` (matches code `business.baseUrl`).
- **NAP:** Shire Security Doors and Screens · Engadine NSW 2233 · 0410 474 256 · steve@shiredoors.com.au.
- **Licence:** Master Security Licence #000105713. **Dealer:** Prowler Proof Authorised Dealer. **Assoc:** NSSA Member. **Warranty:** 10-yr Prowler Proof full replacement.
- **Geo:** lat -34.06560, long 151.01200.

## Current architecture (must respect)
- React 18 + Vite SPA, hand-rolled route matcher in `src/pages/WebsitePage.tsx`; canonical content in `src/data/seoSite.ts`.
- Static HTML + SEO files emitted by `scripts/generate-static-pages.mjs` and `scripts/generate-seo-files.mjs`.
- **Triplicated route data** across those 3 files — every content/route change must sync all three (or be refactored to a single source).
- 6,659 routes: 5 services, 1102 suburbs, 5,510 service×suburb, 32 blog posts, ~12 core.

## Known architectural gaps to fix (from site map)
1. Hardcoded single-question FAQ schema not matching visible FAQ — make data-driven.
2. No BreadcrumbList schema, no visible breadcrumbs.
3. robots.txt lacks AI-crawler allowances; no `/llms.txt`.
4. Thin static blog HTML (summary + boilerplate) — rich `articleBlocks` are JS-only, invisible to crawlers. Static generator must render full article body + FAQ + schema.
5. 24/32 blog posts are thin (sections[] only) — upgrade to rich.
6. Sitemap advertises 6,659 URLs but only 1,249 pre-rendered (non-priority service×suburb are SPA-only).
7. `/design-system` & `/components` indexed — exclude from sitemap/robots.
8. Sitemap `<lastmod>` = today for all; no priority/changefreq.

## Definition of "perfected launch" (acceptance)
- [ ] All ready-written pages (FAQ, Comparison, Pricing, Shire pillar) live with full content + meta + FAQPage schema.
- [ ] Tier-1 new pages written (buying guide, window screens guide, cleaning guide, Cronulla/Miranda/Caringbah rich suburb pages).
- [ ] Core pages have exact report titles/metas/H1s.
- [ ] Homepage `@graph` schema (WebSite+Org+LocalBusiness) valid; Service schema on service pages; BreadcrumbList on non-home; Article on blog; FAQPage matches visible Q&As.
- [ ] robots.txt allows AI crawlers; `/llms.txt` present; design-system/components excluded.
- [ ] Internal-link map wired (no orphan new pages; cross-service + hub-and-spoke).
- [ ] tel: links everywhere; sticky mobile click-to-call; first-person CTAs; trust badges.
- [ ] E-E-A-T pages: About/Meet Steve (Person schema), Warranty, Privacy, Terms, Testimonials.
- [ ] Static generator renders full crawlable content (no thin HTML); triplicated data reconciled or kept in sync.
- [ ] `npm run build` succeeds; schema validates; sitemap correct.
- [ ] Owner-only items documented in OWNER-HANDOFF.md.

## Content quality bar (every new content page)
1. Answer-first 60–80w direct answer before preamble.
2. Body 800–1,200w+ (pillars 2,000–2,500w), question-form H2/H3.
3. Specific stats/data (prices, AS standards, mesh grades, warranty terms).
4. FAQ 5–10 Qs, 40–60w atomic answers, FAQPage schema, 2 best Qs first.
5. ≥2–3 inbound internal links + outbound contextual links + Contact CTA.
6. Steve byline + dates (Article/BlogPosting schema).
