## 6. Schema Markup & Structured Data

### 6.1 Schema Strategy Overview

#### 6.1.1 Single Highest-Leverage Action: Serves SEO, GEO, CRO, Local SEO, E-E-A-T

Schema markup is the single highest-leverage technical action available to Shire Security Doors. A single JSON-LD block placed in the `<head>` of each page simultaneously advances five strategic objectives: it signals relevance to Google's ranking algorithm, feeds structured entities to AI search engines for citation, increases click-through rates via rich results, anchors the business in local search features (Maps, Knowledge Panel, local pack), and builds machine-readable E-E-A-T signals that no competitor in the Sutherland Shire currently exploits. [^1^][^2^] Structured data adoption across the Australian trades sector remains below 30%, leaving a first-mover advantage that compounds over time as AI search interfaces proliferate. [^35^]

The business case is quantifiable. Research demonstrates that structured data alone increases citation probability by 35% in AI-generated results. [^35^] BreadcrumbList schema has delivered 34% CTR improvements in e-commerce case studies and 67% local search visibility lifts for location-based businesses. [^21^] Review schema (where eligible) produces 20-30% CTR increases through star-rating rich snippets. [^18^] By 2027, AI search interfaces will influence 70% of online discovery journeys. [^35^] For a local installer competing against larger brands with bigger backlink profiles, schema markup provides a technical edge that requires no content-creation budget—only precise implementation.

#### 6.1.2 JSON-LD @graph Approach

JSON-LD (JavaScript Object Notation for Linking Data) is Google's recommended format. It separates structured data from HTML markup, eliminating the need to wrap individual page elements in Microdata or RDFa tags. [^32^] JSON-LD is placed once per page inside a single `<script type="application/ld+json">` block in the `<head>` section.

The `@graph` array approach is the cleanest implementation for any page that carries multiple entity types. Instead of deploying four separate `<script>` blocks for WebSite, Organization, LocalBusiness, and Service schemas, the `@graph` container nests all entities in a single block and links them via stable `@id` references. [^31^] This produces:

- **Faster page parsing** — one script block vs. multiple scattered blocks
- **Explicit entity relationships** — schemas reference each other by `@id`, creating a linked data graph that AI systems traverse more effectively
- **Easier maintenance** — one location per page to update
- **Cleaner validation** — single URL paste into Google Rich Results Test returns all entities at once

Every entity in the `@graph` must carry a stable `@id` based on its canonical URL plus a fragment identifier (e.g., `https://shiredoors.com.au/#organization`). Site-wide entities (Organization, WebSite) are referenced from page-level entities rather than duplicated. [^31^]

#### 6.1.3 35% Increase in AI Citation Probability

AI systems—ChatGPT, Gemini, Perplexity, and Google AI Overviews—do not "read" pages the way humans do. They ingest structured data, entity relationships, and content chunks in that order. When a user asks an AI assistant for a "security door installer in Sutherland Shire with Saturday hours," the assistant does not browse websites linearly; it queries its knowledge graph for LocalBusiness entities matching the geographic and temporal constraints. [^36^] Businesses with complete LocalBusiness schema including `openingHoursSpecification`, `geo` coordinates, and `areaServed` entities are extracted first and cited at measurably higher rates. [^35^]

FAQPage schema is especially potent for AI citations. Pages with FAQ schema markup are cited at significantly higher rates than pages without, because the Question-Answer structure maps directly to how LLMs synthesise conversational responses. [^46^] HowTo schema delivers a similar advantage: its numbered-step format corresponds exactly to how LLMs present procedural instructions, making it the preferred structure for installation and maintenance content. [^13^]

---

### 6.2 Required Schema Types

#### 6.2.1 LocalBusiness Schema Details

LocalBusiness schema is the most important structured data type for a local trades business. It powers Google Knowledge Panels, Maps results, local search carousels, and AI assistant responses. [^1^] The required properties are `name` and `address` (as a full `PostalAddress` object). [^3^] However, the critical decision is selecting the most specific `@type` subtype available.

For Shire Security Doors, `HomeAndConstructionBusiness` is the optimal subtype—more precise than the generic `LocalBusiness` type and more accurate than `Locksmith` or `HomeImprovementStore`. [^4^] This subtype signals to Google that the business operates in residential construction and home improvement, aligning with the full service catalogue.

Recommended properties that significantly enhance rich results and AI extraction include:

- `aggregateRating` — overall rating (must come from a third-party platform, not self-served)
- `geo` — `GeoCoordinates` with latitude and longitude (minimum 5 decimal places) [^28^]
- `openingHoursSpecification` — exact hours per day in 24-hour format [^29^]
- `priceRange` — relative price indicator (`$$` for mid-range)
- `telephone` — E.164 format (`+61-410-474-256`)
- `url` — canonical homepage URL
- `image` — high-resolution showroom or team photo
- `areaServed` — array of `City` and `AdministrativeArea` objects covering the service territory
- `hasOfferCatalog` — nested `OfferCatalog` listing all services
- `hasCredential` — Master Security Licence #000105713
- `memberOf` — NSSA membership

For Australian addresses, the `addressCountry` field must use the ISO 3166-1 alpha-2 code `"AU"`—not "Australia" or "AUS". [^30^] The `addressRegion` uses `"NSW"` and `addressLocality` uses `"Engadine"`. GeoCoordinates should be sourced by entering the business address into Google Maps and extracting the lat/long values from the URL.

#### 6.2.2 Service Schema via hasOfferCatalog

Service schema clarifies what the business offers, ensuring Google associates the site with the correct service queries. [^6^] The `ProfessionalService` class has been deprecated in favour of the general `Service` type, which should be used for all service markup. [^6^]

On the homepage, Service entities are nested inside LocalBusiness via `hasOfferCatalog` containing an `OfferCatalog` with individual `Offer` items. Each Offer references a `Service` with `name`, `url`, and `description`. [^7^] This creates a machine-readable service menu that AI systems can extract as a structured list when answering "what services does Shire Security Doors offer?"

On individual service pages, Service schema should be deployed as a standalone entity (not nested inside LocalBusiness) with a `provider` property that references the homepage LocalBusiness `@id`. [^8^] This pattern tells Google: "this specific page is about one service, provided by this known business."

Key Service properties include:

- `provider` — references the LocalBusiness `@id`
- `serviceType` — the activity (e.g., "Security Door Installation")
- `additionalType` — Wikipedia or Wikidata URL for semantic disambiguation
- `areaServed` — geographic entity matching LocalBusiness service area
- `hasOfferCatalog` — on service pages, lists specific product variants under that service

#### 6.2.3 FAQPage Schema — #1 for AI Citations

FAQPage schema is the highest-priority schema type after LocalBusiness and Organization. Even though Google scaled back traditional FAQ rich results in SERPs, the schema remains indispensable because it enhances content clarity for search engines and AI systems at a structural level. [^9^] Pages with FAQ schema are cited at higher rates than pages without because the Question-Answer format maps directly to how LLMs synthesise responses. [^46^]

Critical implementation rules:

- Only use FAQPage when the page lists questions with single, clear answers provided by the site—not for forum pages or user-submitted Q&A. [^10^]
- Include the full text of each question and answer in the schema; partial or truncated text violates guidelines. [^10^]
- All FAQ content must be visible on the page—no hidden FAQ blocks.
- Google displays a maximum of two FAQ rich results, always the first two in the markup—place the two most strategically valuable questions first. [^11^]
- Hyperlinks in answers should use standard HTML anchor tags with single quotation marks around URLs; the first two FAQ answers are the only ones that will display links in rich results. [^11^]

Each service page should carry its own FAQPage schema with 5-8 questions specific to that service. The homepage should NOT carry FAQPage schema—reserve it for pages with dedicated FAQ sections.

#### 6.2.4 Organization Schema with sameAs

Organization schema connects the business to social media accounts, logos, founders, and official URLs, increasing the probability of appearing in Google's Knowledge Panel. [^22^] It should appear on every page of the website, typically in a global script tag in the site header or footer.

The `sameAs` property is the most strategically valuable field in Organization schema. It links to social media profiles and directory listings and is used by Google to build the Knowledge Graph entity for the business. [^23^] Every active profile and verified listing should be included:

- Facebook business page
- Instagram business profile
- Google Business Profile (the Google Maps / GBP URL)
- LinkedIn company page (when created)
- NSSA member directory listing
- Prowler Proof authorised dealer directory

Use stable `@id` values (e.g., `https://shiredoors.com.au/#organization`) so that every other schema on the site can reference the same entity. [^27^]

#### 6.2.5 BreadcrumbList Schema

BreadcrumbList schema helps search engines understand website hierarchy and replaces raw URLs in SERPs with a readable breadcrumb trail, making listings more informative and clickable. [^19^] Google's requirements are specific: at least 2 items, `position` starting from 1, `name` for each item, and `item` URL for each item except the last (current page). [^20^]

Best practices for implementation:

- Match the visible breadcrumb navigation displayed on the page
- Use canonical URLs for each item
- Keep names concise and descriptive
- Always include the homepage as the first item
- Maintain a consistent hierarchy structure across all pages

BreadcrumbList should be present on every page except the homepage, wrapped in the same `@graph` block as the page's primary schema.

#### 6.2.6 HowTo Schema

HowTo schema marks up step-by-step instructions so Google can display them as rich results with expandable steps. [^12^] The format corresponds exactly to how LLMs present instructions—numbered and digestible—making it highly effective for AI search visibility. [^13^]

Required properties are `name` and `step` (an array of `HowToStep` objects). Each step should include `text` and optionally `image`. Optional but valuable properties include `totalTime`, `estimatedCost`, `supply`, and `tool`—all of which enrich the rich result and provide more extraction surface for AI systems.

Apply HowTo schema to:

- Blog posts explaining installation or maintenance procedures
- "How to choose" guides for security products
- Cleaning and care instructions for security doors and screens
- Measurement guides for customers preparing for a quote

---

### 6.3 Implementation

#### 6.3.1 Complete JSON-LD @graph for Homepage (Copy-Paste Ready)

The following block combines WebSite, Organization, and LocalBusiness (with nested Service `hasOfferCatalog`) into a single `@graph` array. Place this in the `<head>` of the homepage only. Replace placeholder URLs with actual asset paths before deployment.

```json
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "WebSite",
      "@id": "https://shiredoors.com.au/#website",
      "url": "https://shiredoors.com.au/",
      "name": "Shire Security Doors and Screens",
      "description": "Security doors, window screens, plantation shutters and outdoor blinds in Sutherland Shire, Sydney. Master Security Licence #000105713. Prowler Proof Authorised Dealer.",
      "publisher": {
        "@id": "https://shiredoors.com.au/#organization"
      },
      "inLanguage": "en-AU"
    },
    {
      "@type": "Organization",
      "@id": "https://shiredoors.com.au/#organization",
      "name": "Shire Security Doors and Screens",
      "alternateName": ["Shire Doors", "Shire Security Doors"],
      "url": "https://shiredoors.com.au/",
      "logo": {
        "@type": "ImageObject",
        "url": "https://shiredoors.com.au/logo.png",
        "width": 600,
        "height": 60
      },
      "image": "https://shiredoors.com.au/images/showroom.jpg",
      "description": "Sydney's trusted security door and window screen specialists. Master Security Licence #000105713. Prowler Proof Authorised Dealer. NSSA Member.",
      "foundingDate": "2005",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "Unit 2, 1011 Old Princes Highway",
        "addressLocality": "Engadine",
        "addressRegion": "NSW",
        "postalCode": "2233",
        "addressCountry": "AU"
      },
      "contactPoint": {
        "@type": "ContactPoint",
        "telephone": "+61-410-474-256",
        "contactType": "customer service",
        "availableLanguage": ["English"],
        "areaServed": "AU",
        "email": "steve@shiredoors.com.au"
      },
      "sameAs": [
        "https://www.facebook.com/shiredoors",
        "https://www.instagram.com/shiredoors",
        "https://g.page/shiredoors"
      ],
      "hasCredential": "Master Security Licence #000105713",
      "memberOf": {
        "@type": "Organization",
        "name": "National Security Screen Association (NSSA)"
      }
    },
    {
      "@type": "HomeAndConstructionBusiness",
      "@id": "https://shiredoors.com.au/#localbusiness",
      "name": "Shire Security Doors and Screens",
      "url": "https://shiredoors.com.au/",
      "telephone": "+61-410-474-256",
      "email": "steve@shiredoors.com.au",
      "description": "Sydney's leading security door and window screen specialists serving the Sutherland Shire. Master Security Licence #000105713. Prowler Proof Authorised Dealer. NSSA Member.",
      "image": "https://shiredoors.com.au/images/showroom.jpg",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "Unit 2, 1011 Old Princes Highway",
        "addressLocality": "Engadine",
        "addressRegion": "NSW",
        "postalCode": "2233",
        "addressCountry": "AU"
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": -34.06560,
        "longitude": 151.01200
      },
      "openingHoursSpecification": [
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
          "opens": "07:00",
          "closes": "17:00"
        },
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": "Saturday",
          "opens": "08:00",
          "closes": "14:00"
        }
      ],
      "priceRange": "$$",
      "areaServed": [
        { "@type": "City", "name": "Engadine" },
        { "@type": "City", "name": "Sutherland" },
        { "@type": "City", "name": "Cronulla" },
        { "@type": "City", "name": "Menai" },
        { "@type": "City", "name": "Miranda" },
        { "@type": "City", "name": "Caringbah" },
        { "@type": "AdministrativeArea", "name": "Sutherland Shire" },
        { "@type": "City", "name": "Sydney" }
      ],
      "hasOfferCatalog": {
        "@type": "OfferCatalog",
        "name": "Security and Screening Services",
        "itemListElement": [
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Security Doors",
              "url": "https://shiredoors.com.au/services/security-doors/",
              "description": "Premium security doors including Prowler Proof Forcefield, diamond grille and stainless steel mesh options. Custom made to fit your home."
            }
          },
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Window Screens",
              "url": "https://shiredoors.com.au/services/security-screens/",
              "description": "Security window screens, fly screens and mesh options to protect your home while maintaining ventilation and views."
            }
          },
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Plantation Shutters",
              "url": "https://shiredoors.com.au/services/plantation-shutters/",
              "description": "Beautiful plantation shutters in PVC and timber. Custom fitted to enhance your home's style, privacy and energy efficiency."
            }
          },
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Outdoor Blinds",
              "url": "https://shiredoors.com.au/services/outdoor-blinds/",
              "description": "Ziptrak, patio and outdoor blinds to extend your living space. Protection from sun, wind and rain all year round."
            }
          }
        ]
      },
      "additionalType": [
        "https://www.wikidata.org/wiki/Q2912397",
        "https://en.wikipedia.org/wiki/Home_improvement"
      ],
      "hasCredential": "Master Security Licence #000105713",
      "potentialAction": {
        "@type": "ReserveAction",
        "name": "Book Free Measure & Quote",
        "target": {
          "@type": "EntryPoint",
          "urlTemplate": "https://shiredoors.com.au/contact/"
        }
      }
    }
  ]
}
</script>
```

#### 6.3.2 Per-Page Schema Recommendations

The table below maps every schema type to its target pages, priority, and purpose. Implement in the order listed.

| Priority | Schema Type | Target Pages | Purpose | Citation |
|----------|-------------|--------------|---------|----------|
| Critical | Organization | All pages (global header/footer) | Brand identity, Knowledge Graph linkage, `sameAs` profiles | [^22^] |
| Critical | LocalBusiness (`HomeAndConstructionBusiness`) | Homepage only | Local search, Maps, Knowledge Panel, AI local recommendations | [^1^] |
| Critical | Service (standalone) | Each service page (`/services/security-doors/`, `/services/security-screens/`, `/services/plantation-shutters/`, `/services/outdoor-blinds/`) | Service-specific rankings, provider reference to LocalBusiness | [^8^] |
| High | FAQPage | Each service page (5-8 questions per page) | Rich snippets, AI answer extraction, zero-click visibility | [^9^][^46^] |
| High | BreadcrumbList | All pages except homepage | Navigation hierarchy, URL replacement in SERPs, +34% CTR potential | [^19^][^21^] |
| High | WebSite | Homepage | Site entity definition, publisher linkage | [^24^] |
| Medium | HowTo | Blog posts and guides (e.g., "How to Choose a Security Door", "How to Clean Your Security Screen") | Step-by-step rich results, procedural AI citations | [^12^][^13^] |
| Medium | Article/BlogPosting | All blog posts | Content rich results, author attribution, date signals | [^26^][^27^] |
| Low | Product | Individual product detail pages (if created) | Product snippets, review aggregation | [^14^][^15^] |

**Service Page Pattern.** Every service page follows the same structure: a `@graph` containing BreadcrumbList + standalone Service. The Service entity references the homepage LocalBusiness via `"@id": "https://shiredoors.com.au/#localbusiness"` in its `provider` property. [^8^] The `additionalType` field should include a relevant Wikipedia URL for semantic disambiguation (e.g., `"https://en.wikipedia.org/wiki/Security_door"` for the Security Doors page).

**FAQPage Pattern.** Each service page carries its own FAQPage schema within its `@graph`, placed after the Service entity. Include 5-8 questions that are specific to that service. The first two questions should be the highest-value ones (pricing and service area questions, for example), because only the first two are eligible for rich result display. [^11^] All answer text must match the visible on-page FAQ content exactly.

**Organization Global Pattern.** The Organization schema (shown in the homepage `@graph` above) should also be output as a separate standalone script block in the global site header or footer so it appears on every page. The `@id` must remain identical (`https://shiredoors.com.au/#organization`) across all instances so that page-level schemas can reference it consistently. [^31^]

**Self-Serving Review Warning.** Do NOT mark up customer testimonials on the website using LocalBusiness or Organization `review` or `aggregateRating` properties. Google's self-serving review policy prohibits this and may trigger manual actions. [^16^] Review schema is only eligible on Product pages (reviewing specific products, not the business) or when aggregated from third-party platforms. [^17^] Instead, build reviews on Google Business Profile and industry directories.

#### 6.3.3 Testing with Google Rich Results Test

Every page carrying schema must pass two validators before going live:

1. **Google Rich Results Test** (`https://search.google.com/test/rich-results`) — validates structured data for Google's supported rich results subset, showing eligibility and any warnings. [^33^]
2. **Schema Markup Validator** (`https://validator.schema.org/`) — validates all Schema.org types for vocabulary and shape correctness, regardless of Google's rich result support. [^33^]

Use both tools together. The Rich Results Test confirms what Google will display; the Schema Markup Validator catches vocabulary errors that the Rich Results Test may overlook. [^33^]

**Pre-publication checklist for every page:**

- Validate JSON syntax with JSONLint first (malformed JSON will fail both validators silently)
- Match schema types with page intent—Service schema on service pages, Article on blog posts
- Verify all `@id` references resolve correctly (e.g., Service `provider.@id` matches LocalBusiness `@id`)
- Confirm zero errors and zero critical warnings in both validators
- Ensure schema content matches visible on-page content exactly
- Match all URLs with canonical URL declarations
- Roll out in batches: first the homepage, monitor 48 hours, then deploy service pages
- Monitor Google Search Console "Enhancements" report weekly for structured data error alerts [^34^]

**Implementation timeline:** deploy Organization schema globally in Week 1; deploy the homepage `@graph` (WebSite + LocalBusiness + Service catalog) in Week 1; deploy service page schemas (BreadcrumbList + Service + FAQPage) in Week 2; deploy HowTo and Article schemas on blog content in Weeks 3-4. Validate every batch before proceeding to the next. [^34^]

After deployment, monitor AI visibility via manual prompt testing across ChatGPT, Gemini, and Perplexity. Query: "What security door services are available in Sutherland Shire?" and "Who installs Prowler Proof security doors in Engadine?" The presence of structured data increases the probability that AI systems will cite Shire Security Doors by name, include accurate hours and phone numbers, and list the correct service range. [^36^] Expect measurable AI citation improvements within 6-8 weeks of full deployment as crawl and indexing cycles complete.
