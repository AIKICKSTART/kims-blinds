# Dimension 6: Schema Markup & Structured Data

## Research Summary: Schema Markup & Structured Data for Shire Security Doors and Screens

**Business:** Shire Security Doors and Screens
**Location:** Engadine, Sutherland Shire, Sydney, NSW, Australia
**Services:** Security Doors, Window Screens, Plantation Shutters, Outdoor Blinds
**Licence:** Master Security Licence #000105713 | Prowler Proof Authorised Dealer | NSSA Member
**Contact:** Phone 0410 474 256 | Email steve@shiredoors.com.au
**Service Area:** Sutherland Shire and surrounding Sydney suburbs

---

## Table of Contents

1. [LocalBusiness Schema Best Practices](#1-localbusiness-schema-best-practices)
2. [Service Schema Markup](#2-service-schema-markup)
3. [FAQPage Schema Implementation](#3-faqpage-schema-implementation)
4. [HowTo Schema for Installation Guides](#4-howto-schema-for-installation-guides)
5. [Product Schema for Security Doors/Screens](#5-product-schema-for-security-doorsscreens)
6. [Review/AggregateRating Schema](#6-reviewaggregaterating-schema)
7. [BreadcrumbList Schema](#7-breadcrumblist-schema)
8. [Organization Schema](#8-organization-schema)
9. [WebSite Schema with SearchAction](#9-website-schema-with-searchaction)
10. [Article/BlogPosting Schema](#10-articleblogposting-schema)
11. [GeoCoordinates & OpeningHoursSpecification](#11-geocoordinates--openinghoursspecification)
12. [JSON-LD Implementation Best Practices](#12-json-ld-implementation-best-practices)
13. [Schema Testing and Validation Tools](#13-schema-testing-and-validation-tools)
14. [Impact of Schema on AI Search Visibility](#14-impact-of-schema-on-ai-search-visibility)
15. [Complete JSON-LD Examples](#15-complete-json-ld-examples)

---

## 1. LocalBusiness Schema Best Practices

### Finding 1.1: LocalBusiness Schema is Essential for Local Search Visibility

**Claim:** LocalBusiness schema is the most important structured data type for a local trades business. It powers Knowledge Panels, Google Maps results, local search carousels, and AI assistant responses. [^1^]

**Source:** greadme.com
**URL:** https://www.greadme.com/blog/schemas/what-is-local-business-schema-complete-guide
**Date:** 2026-05-21
**Excerpt:** "LocalBusiness schema is a type of structured data -- based on the Schema.org LocalBusiness vocabulary -- that tells Google exactly what your business is, where it is located, and when it is open. When correctly implemented, it powers the business details that appear in Google Knowledge Panels, Maps results, and local search carousels, and it significantly improves how AI assistants describe and recommend your business."
**Context:** Required properties are `name` and `address` (as a full PostalAddress object). Always use a specific subtype rather than the generic LocalBusiness type when possible.
**Confidence:** High

---

**Claim:** LocalBusiness schema supports several key features in Google's ecosystem: local search results, Google Maps listings, Knowledge Panels, and business information sections in search results. [^2^]

**Source:** codestratzbschool.com
**URL:** https://codestratzbschool.com/blog/seo/how-to-create-and-implement-local-business-schema/
**Date:** 2026-04-02
**Excerpt:** "Structured data for local businesses supports several features in Google's ecosystem, including: Local search results, Google Maps listings, Knowledge panels, Business information sections in search results."
**Context:** Four types should be stacked together on the homepage: WebSite, Organization, LocalBusiness, and Service schemas.
**Confidence:** High

### Finding 1.2: Required vs Recommended Properties for LocalBusiness

**Claim:** The required properties for LocalBusiness are `name` and `address`. Recommended properties that significantly enhance rich results include: `aggregateRating`, `geo` (GeoCoordinates), `openingHoursSpecification`, `priceRange`, `telephone`, `url`, `image`, and `review`. [^3^]

**Source:** Schema App
**URL:** https://www.schemaapp.com/schema-markup/how-to-do-schema-markup-for-local-business/
**Date:** 2026-05-13
**Excerpt:** "You must populate the required properties for your content to be eligible for display as a rich result. Recommended properties add more information to your structured data, which could provide a better user experience."
**Context:** GeoCoordinates require latitude and longitude with at least 5 decimal places precision. OpeningHoursSpecification requires `closes`, `dayOfWeek`, and `opens`.
**Confidence:** High

### Finding 1.3: Use a Specific Subtype Rather Than Generic LocalBusiness

**Claim:** Using a more specific subtype (e.g., `ProfessionalService`, `HomeAndConstructionBusiness`, `Locksmith`) gives search engines more precise context than the generic `LocalBusiness` type. [^4^]

**Source:** unhead.unjs.io
**URL:** https://unhead.unjs.io/docs/schema-org/api/schema/local-business
**Date:** 2026-03-05
**Excerpt:** "For better visibility, use a specific subtype like Dentist, Restaurant, or ProfessionalService rather than the generic LocalBusiness type."
**Context:** For a security doors business, `HomeAndConstructionBusiness` > `HomeImprovementStore` or `ProfessionalService` are the most appropriate subtypes.
**Confidence:** High

### Finding 1.4: Ideal Schema Structure for Single-Location Local Business

**Claim:** For a single-location local business, the ideal structure stacks four key schema types together: WebSite, Organization, LocalBusiness, and Service. These should be placed on the homepage using a single JSON-LD `@graph` block. [^5^]

**Source:** chazedward.com
**URL:** https://chazedward.com/how-to-use-schema-for-local-seo/
**Date:** 2025-06-15
**Excerpt:** "For a single-location local business, you typically want to use at least four key schema types: Website Schema (WebSite) > Defines the site as an entity. Organization Schema (Organization) > Represents the business itself. LocalBusiness Schema (LocalBusiness) > Adds local relevance & contact info. Service Schema (Service) > Adds service details, can be nested in LocalBusiness for location pages."
**Context:** Best practice is to stack them in one JSON-LD block using `@graph` array for clean interlinked structure.
**Confidence:** High

---

## 2. Service Schema Markup

### Finding 2.1: Service Schema Clarifies What You Offer

**Claim:** Service schema is the broadest class to define a service offered by a business. It clarifies what you offer, ensuring Google ranks you for the right search queries. The `ProfessionalService` class has been deprecated in favour of the more general `Service`. [^6^]

**Source:** Schema App
**URL:** https://www.schemaapp.com/schema-markup/services-schema-markup-schema-org-services/
**Date:** 2026-01-22
**Excerpt:** "Service is the broadest class to define a service offered by a business. The Professional Service class was commonly used in the past, but has since been deprecated by Schema.org in favour of the more general Service."
**Context:** Key properties include `provider` (who offers the service), `additionalType` (define more explicitly using Wikipedia/Wikidata), `areaServed` (geographic area), and `serviceOutput` (what the outcome of the service is).
**Confidence:** High

### Finding 2.2: Service Schema with OfferCatalog for Multiple Services

**Claim:** Using `hasOfferCatalog` with nested `OfferCatalog` items is the best way to represent multiple related services (e.g., Security Doors, Window Screens, Plantation Shutters, Outdoor Blinds) under a single service umbrella. [^7^]

**Source:** Schema.org
**URL:** https://schema.org/Service
**Date:** 2015-01-30
**Excerpt:** "Example encoded as JSON-LD: ACME Home Cleaning offers a variety of services in Massachusetts... uses hasOfferCatalog with nested OfferCatalog items for House Cleaning and One-time services."
**Context:** This is the canonical reference implementation for a service business offering multiple service categories.
**Confidence:** High

### Finding 2.3: Service Schema Should Be Page-Specific

**Claim:** Service schema on individual service pages should reference the business via the `provider` property but should not be nested inside LocalBusiness. Standalone Service schema with a provider reference is preferred for individual service pages. [^8^]

**Source:** chazedward.com
**URL:** https://chazedward.com/how-to-use-schema-for-local-seo/
**Date:** 2025-06-15
**Excerpt:** "For individual service pages, use standalone Service schema, but reference the business: provider: { @type: LocalBusiness, name: Your Business Name, url: https://yourwebsite.com }"
**Context:** This should go only on service pages. The homepage should nest Service inside LocalBusiness.
**Confidence:** High

---

## 3. FAQPage Schema Implementation

### Finding 3.1: FAQ Schema Remains Valuable Despite Rich Result Changes

**Claim:** Even though Google has scaled back traditional FAQ rich results from SERPs, implementing FAQ schema remains valuable because it enhances content clarity and relevance for search engines and AI systems. [^9^]

**Source:** StudioHawk (Australia)
**URL:** https://studiohawk.com.au/blog/faq-schema/
**Date:** 2025-11-09
**Excerpt:** "Even though Google has scaled back or removed traditional FAQ rich results from SERPs, implementing FAQ schema remains a valuable strategy. The key takeaway is that structured data, like FAQ schema, enhances your content's clarity and relevance for search engines."
**Context:** FAQPage schema should only be used when the page lists questions with single, clear answers provided by the site. Not for forum pages or user-submitted Q&A.
**Confidence:** High

### Finding 3.2: FAQPage Guidelines and Best Practices

**Claim:** Key guidelines for FAQPage schema include: include full text of each question and answer, don't use FAQPage for ads, don't use for offensive content, ensure all FAQ content is visible on the page, and use FAQ schema only for single-answer questions (use HowTo for step-by-step guides). [^10^]

**Source:** StudioHawk (Australia)
**URL:** https://studiohawk.com.au/blog/faq-schema/
**Date:** 2025-11-09
**Excerpt:** "Use FAQPage Schema only when your page lists questions with single, clear answers provided by the site... Include full text of each question and answer in the schema."
**Context:** For a security doors business, FAQ schema should be placed on individual service pages to answer service-specific questions.
**Confidence:** High

### Finding 3.3: Hyperlinks in FAQ Answers

**Claim:** You can include hyperlinks in the answer component of FAQPage schema using standard HTML anchor tags with single quotation marks around URLs. Google will show a maximum of two FAQs as rich results -- always the first two. [^11^]

**Source:** Medium / Daniel Cheung
**URL:** https://medium.com/@danielkcheung/can-you-insert-links-into-faq-schema-yes-and-here-is-how-to-do-it-5c7425959a54
**Date:** 2023-08-14
**Excerpt:** "Google will show a maximum of two FAQs and these are always the first two questions and answers marked up in FAQPage schema.org Type. Therefore, if you want to benefit from links in FAQPage schema, make sure you load them in the first two answers."
**Context:** Links in FAQ answers can drive traffic to specific service pages. First two FAQs should be strategically chosen.
**Confidence:** High

---

## 4. HowTo Schema for Installation Guides

### Finding 4.1: HowTo Schema for Step-by-Step Guides

**Claim:** HowTo schema marks up step-by-step instructions so Google can display them as rich results with expandable steps. It's ideal for tutorials, guides, DIY instructions, and how-to content related to installation, maintenance, and care. [^12^]

**Source:** unhead.unjs.io
**URL:** https://unhead.unjs.io/docs/schema-org/api/schema/how-to
**Date:** 2026-03-05
**Excerpt:** "HowTo schema marks up step-by-step instructions so Google can display them as rich results with expandable steps. Use it for tutorials, guides, DIY instructions, and how-to content."
**Context:** Required properties are `name` and `step` (array of HowToStep objects). Each step should have `text` and optionally `image`.
**Confidence:** High

### Finding 4.2: HowTo Format for AI Visibility

**Claim:** The HowTo schema format corresponds exactly to how LLMs present instructions -- numbered and digestible steps. This makes it highly effective for AI search visibility. [^13^]

**Source:** ailabsaudit.com
**URL:** https://ailabsaudit.com/blog/en/schema-markup-ai-visibility-guide
**Date:** 2026-05-16
**Excerpt:** "The HowTo schema is ideal for step-by-step tutorials and guides. This format corresponds exactly to how LLMs present instructions -- numbered and digestible steps."
**Context:** Progressive implementation strategy: Organization first, then FAQPage, then Article, then HowTo and Product.
**Confidence:** High

---

## 5. Product Schema for Security Doors/Screens

### Finding 5.1: Product Schema + Offer + AggregateRating for Security Products

**Claim:** Product schema with nested Offer and AggregateRating is essential for product-rich results. Key properties include: `name`, `description`, `image`, `sku`/`gtin`, `brand`, `offers` (price, availability), `aggregateRating`, and `review`. [^14^]

**Source:** Geneo
**URL:** https://geneo.app/blog/schema-markup-best-practices-ai-citations-2025/
**Date:** 2025-10-05
**Excerpt:** "Product: name, description, image, sku/gtin, brand, offers (price/availability), aggregateRating, review."
**Context:** For security doors/screens that don't have fixed pricing, the Product schema can still be used without the Offer sub-schema, focusing on brand, description, and ratings.
**Confidence:** High

### Finding 5.2: Product Schema for Non-E-commerce Applications

**Claim:** Product Snippet Schema adds key product info to search results even on non-purchasable product pages, such as reviews or comparison guides. Rich results may include aggregate ratings, review summaries, pros and cons, brand, model, and SKU. [^15^]

**Source:** corpowid.ai
**URL:** https://corpowid.ai/blog/advanced-guide-schema-markup-seo-2025
**Date:** 2026-06-17
**Excerpt:** "Product Snippet Schema: Adds key product info to search results even on non-purchasable product pages, such as reviews or comparison guides. Rich results may include: Aggregate ratings, Review summaries, Pros and cons (on editorial pages), Brand, model, SKU."
**Context:** This is perfect for security door product pages that showcase products without direct online purchasing.
**Confidence:** High

---

## 6. Review/AggregateRating Schema

### Finding 6.1: The Self-Serving Review Rule

**Claim:** Google's "self-serving review" guideline prohibits businesses from marking up their own customer testimonials/reviews on their own website using LocalBusiness or Organization schema to generate star review rich results. However, Product review schema on product pages IS eligible. [^16^]

**Source:** iLoveSchema
**URL:** https://iloveschema.com/review-snippet-schema-markup-generator/
**Date:** 2026-06-04
**Excerpt:** "If the entity being reviewed controls the reviews about itself, those pages using LocalBusiness or any other type of Organization structured data are ineligible for the star review feature."
**Context:** What IS eligible: Product review schema on product pages (reviews of specific products, not the business). Third-party review sites reviewing other businesses are also eligible.
**Confidence:** High

### Finding 6.2: AggregateRating on Service Pages

**Claim:** For a service business, `AggregateRating` can be used on service pages (not homepage/LocalBusiness) to show overall service ratings. The schema should use `Service` as the itemReviewed type rather than `LocalBusiness` or `Organization`. [^17^]

**Source:** BrightLocal
**URL:** https://www.brightlocal.com/learn/review-schema/
**Date:** 2025-10-14
**Excerpt:** "When building review schema, you'll usually work with two key properties: Review and aggregateRating. Review is used to mark up details in individual customer reviews. AggregateRating is used to show the overall score for a product or service."
**Context:** Key properties: `ratingValue`, `reviewCount`, `ratingCount`, `bestRating`, `worstRating`. Product and service review schema is fully eligible for rich results.
**Confidence:** High

### Finding 6.3: Review Schema Increases CTR by 20-30%

**Claim:** Review schema markup helps search engines understand reviews and display them as rich snippets, increasing click-through rates by 20-30% and building trust before visitors reach the site. [^18^]

**Source:** revukit.com
**URL:** https://www.revukit.com/tools/review-schema-generator
**Date:** Unknown
**Excerpt:** "Review schema markup helps search engines understand your reviews and display them as rich snippets -- the star ratings you see directly in Google search results. This visual proof increases click-through rates by 20-30%."
**Context:** For Shire Security Doors, review schema should be implemented on individual service pages (not homepage) using the Service type, or on product pages using Product type.
**Confidence:** Medium

---

## 7. BreadcrumbList Schema

### Finding 7.1: Breadcrumb Schema Replaces Raw URLs in SERPs

**Claim:** BreadcrumbList schema helps search engines understand website hierarchy and navigation structure, displaying a breadcrumb trail in Google search results instead of the raw URL. This makes listings more informative and clickable. [^19^]

**Source:** pikaseo.com
**URL:** https://pikaseo.com/free-tools/breadcrumb-schema-generator
**Date:** Unknown
**Excerpt:** "Breadcrumb Schema (BreadcrumbList) is structured data that helps search engines understand your website's hierarchy and navigation structure. When implemented correctly, it can display a breadcrumb trail in Google search results instead of the raw URL, making your listings more informative and clickable."
**Context:** Required properties: `@type`, `itemListElement`, `position`, `name`, and `item` URL (except for the last/current page).
**Confidence:** High

### Finding 7.2: BreadcrumbList Best Practices

**Claim:** Google's requirements for BreadcrumbList include: at least 2 items, `position` starting from 1, `name` for each item, `item` URL for each item (except last). Best practices: match visible breadcrumb navigation on page, use canonical URLs, keep names concise, include homepage as first item. [^20^]

**Source:** pikaseo.com
**URL:** https://pikaseo.com/free-tools/breadcrumb-schema-generator
**Date:** Unknown
**Excerpt:** "Match visible breadcrumb navigation on page. Use canonical URLs for each item. Keep names concise and descriptive. Include the homepage as first item. Maintain consistent hierarchy structure."
**Context:** For Shire Security Doors, breadcrumbs would be: Home > Services > Security Doors (on the Security Doors page).
**Confidence:** High

### Finding 7.3: BreadcrumbList Case Studies Show Significant CTR Improvement

**Claim:** Case studies show breadcrumb schema implementation can improve CTR by 34% for e-commerce, increase organic traffic by 56% for documentation sites, and increase local search visibility by 67% for real estate listings. [^21^]

**Source:** pikaseo.com
**URL:** https://pikaseo.com/free-tools/breadcrumb-schema-generator
**Date:** Unknown
**Excerpt:** "E-commerce: +34% CTR Improvement. Real Estate: +67% Local Search Visibility."
**Context:** These are case study results, not guarantees, but they demonstrate the potential impact.
**Confidence:** Medium

---

## 8. Organization Schema

### Finding 8.1: Organization Schema Strengthens Brand Identity

**Claim:** Organization schema connects a business to social media accounts, logos, founders, and official URLs. It increases the chances of appearing in Google's Knowledge Panel. Key fields: `name`, `logo`, `url`, `contactPoint`, `sameAs` (social profiles), `address`, and `founder`. [^22^]

**Source:** chazedward.com
**URL:** https://chazedward.com/how-to-use-schema-for-local-seo/
**Date:** 2025-06-15
**Excerpt:** "The Organization schema connects your business to social media accounts, logos, founders, and official URLs."
**Context:** Should be included on every page. Include consistent organization schema on every page footer for better global recognition.
**Confidence:** High

### Finding 8.2: sameAs Property for Knowledge Graph

**Claim:** The `sameAs` property in Organization schema links to social media profiles and is used by Google to build the Knowledge Graph. This should include all active social media profiles, directory listings, and review platforms. [^23^]

**Source:** jsonld.com
**URL:** https://jsonld.com/social-network-profiles/
**Date:** 2026-05-01
**Excerpt:** "This is a special type of JSON-LD defined by Google to enable social network icons in the Knowledge Graph."
**Context:** Include Facebook, Instagram, LinkedIn, Google Business Profile, and any trade directory listings (NSSA, Prowler Proof dealer directory).
**Confidence:** High

---

## 9. WebSite Schema with SearchAction

### Finding 9.1: WebSite Schema Enables Sitelinks Search Box

**Claim:** WebSite schema tells search engines how the site is structured and enables features like Google Sitelinks Search Box. It uses `potentialAction` with a `SearchAction` type to define internal site search. [^24^]

**Source:** schema.org
**URL:** https://schema.org/SearchAction
**Date:** 2026-03-19
**Excerpt:** "(A WebSite describing its search options) - uses potentialAction with SearchAction and target URL template."
**Context:** Google officially retired the sitelinks search box display feature in November 2024, but WebSite schema still helps with site structure understanding.
**Confidence:** High

### Finding 9.2: Google Retired Sitelinks Search Box Display

**Claim:** As of November 21, 2024, Google officially removed the sitelinks search box feature from SERPs due to declining usage. While the structured data remains valid schema, it no longer triggers the visual search box feature. [^25^]

**Source:** robertwent.com
**URL:** https://robertwent.com/blog/remove-sitelinks-search-box-schema-from-yoast-structured-data/
**Date:** 2024-11-26
**Excerpt:** "On the 21st of November 2024, Google retired Sitelinks Search Box from SERPs."
**Context:** WebSite schema should still be implemented for entity definition purposes, but the SearchAction/potentialAction component is no longer necessary for visual SERP features.
**Confidence:** High

---

## 10. Article/BlogPosting Schema

### Finding 10.1: Article/BlogPosting Schema for Content Publishing

**Claim:** Article/BlogPosting schema communicates headline, author, publish date, image, and publisher information. This is essential for blog content and articles that provide educational content about security doors, window screens, and home security topics. [^26^]

**Source:** DesignAgency
**URL:** https://www.designagencygroup.com/schema-markup-in-2025-the-structured-data-layer-your-seo-and-ai-visibility-depends-on/
**Date:** 2025-12-12
**Excerpt:** "Article/BlogPosting: Communicates headline, author, publish date, image, publisher."
**Context:** For Shire Security Doors' blog posts about security topics, use BlogPosting schema with `headline`, `datePublished`, `dateModified`, `author`, `publisher`, `image`, and `mainEntityOfPage` properties.
**Confidence:** High

### Finding 10.2: Schema Best Practices for AI Citations

**Claim:** Foundational schema hygiene requires: prefer JSON-LD, keep markup aligned with on-page content, cover core types thoroughly (Article/BlogPosting: headline, image, datePublished, dateModified, author, publisher, mainEntityOfPage), and validate aggressively. [^27^]

**Source:** Geneo
**URL:** https://geneo.app/blog/schema-markup-best-practices-ai-citations-2025/
**Date:** 2025-10-05
**Excerpt:** "Article/BlogPosting: headline, image, datePublished, dateModified, author, publisher, mainEntityOfPage."
**Context:** Use stable URLs and consistent IDs. Add `@id` for Organization and Person entities and reuse across pages.
**Confidence:** High

---

## 11. GeoCoordinates & OpeningHoursSpecification

### Finding 11.1: GeoCoordinates Improve Map Precision

**Claim:** Specifying latitude and longitude via GeoCoordinates schema improves precise mapping on Google Maps. This is particularly important for businesses in densely populated areas where the street address alone is not specific enough. Coordinates should have at least 5 decimal places precision. [^28^]

**Source:** Schema App
**URL:** https://www.schemaapp.com/schema-markup/how-to-do-schema-markup-for-local-business/
**Date:** 2026-05-13
**Excerpt:** "The latitude of the business location. The precision should be at least 5 decimal places."
**Context:** For Engadine, Sutherland Shire, coordinates can be found by searching the business address in Google Maps and extracting lat/long from the URL.
**Confidence:** High

### Finding 11.2: OpeningHoursSpecification Format

**Claim:** OpeningHoursSpecification allows precise specification of opening hours per weekday using 24-hour time format (e.g., "09:00" not "9am"). For closed days, either omit the day entirely or use `opens: "00:00"` and `closes: "00:00"`. Seasonal variations can be mapped via `validFrom` and `validThrough`. [^29^]

**Source:** hiagency.au
**URL:** https://hiagency.au/shopify-seo/how-to-add-organization-localbusiness-schema-in-shopify/
**Date:** 2026-03-04
**Excerpt:** "Use 24-hour time format (09:00, not 9am). For closed days, use opens: '00:00' and closes: '00:00' or omit the day entirely."
**Context:** For a trades business like Shire Security Doors, hours should reflect actual showroom/office hours and any emergency service availability.
**Confidence:** High

### Finding 11.3: Australian Address Format in Schema

**Claim:** For Australian addresses, the `addressCountry` field must use the two-letter ISO 3166-1 alpha-2 country code: "AU". Do not write "Australia" or "AUS". [^30^]

**Source:** greadme.com
**URL:** https://www.greadme.com/blog/schemas/what-is-local-business-schema-complete-guide
**Date:** 2026-05-21
**Excerpt:** "Always use the two-letter ISO 3166-1 alpha-2 country code: US for the United States, GB for the United Kingdom, DE for Germany, and so on. Writing United States or USA is invalid."
**Context:** For Shire Security Doors: `"addressCountry": "AU"`, `"addressRegion": "NSW"`, `"addressLocality": "Engadine"`.
**Confidence:** High

---

## 12. JSON-LD Implementation Best Practices

### Finding 12.1: Five Core Principles for JSON-LD Implementation

**Claim:** Five core principles for JSON-LD implementation: (1) One page-level JSON-LD script per page using `@graph` array, (2) Stable `@id` strategy based on canonical URL, (3) Strict separation of site-wide vs page-level entities, (4) Match URLs exactly with canonical, (5) Preserve unless invalid when cleaning up. [^31^]

**Source:** clickforest.com
**URL:** https://www.clickforest.com/en/blog/json-ld-implementation-guide
**Date:** 2026-01-29
**Excerpt:** "One page-level JSON-LD script per page. Place all page-specific structured data in one <script type="application/ld+json"> block with a @graph array. Not four separate scripts."
**Context:** Site-wide entities (WebSite, Organization) in a separate script loaded on every page. Page-level entities (WebPage, Service, BlogPosting, BreadcrumbList, FAQPage) live in page-specific script and reference site-wide entities via `@id`.
**Confidence:** High

### Finding 12.2: JSON-LD is Google's Recommended Format

**Claim:** JSON-LD (JavaScript Object Notation for Linking Data) is the format recommended by Google. It's easier to implement and maintain than Microdata or RDFa, separates structure from HTML code, and no content duplication is necessary. [^32^]

**Source:** searchviu.com
**URL:** https://www.searchviu.com/en/schema-markup-and-ai-in-2025-what-chatgpt-claude-perplexity-gemini-really-see/
**Date:** 2025-12-02
**Excerpt:** "JSON-LD -- JavaScript Object Notation for Linking Data -- The format recommended by Google. It is separated from HTML and is implemented in <script> tags."
**Context:** Place JSON-LD in the `<head>` section of each page. For WordPress sites, use plugins that allow custom JavaScript per page.
**Confidence:** High

---

## 13. Schema Testing and Validation Tools

### Finding 13.1: Google Rich Results Test vs Schema Markup Validator

**Claim:** The Google Rich Results Test validates structured data for Google's supported rich results subset, showing eligibility and warnings. The Schema Markup Validator (from Schema.org) validates all Schema.org types for vocabulary and shape correctness. Both should be used together. [^33^]

**Source:** Moz Community
**URL:** https://moz.com/community/q/topic/71257/schema-markup-validator-vs-rich-results-test
**Date:** 2024-02-04
**Excerpt:** "The Rich Result test is restricted to testing only the markup of structured data that's used in Google's results for the search. However, the Schema.org markup validation is more intended for 'general purposes'."
**Context:** Google Rich Results Test: https://search.google.com/test/rich-results. Schema Markup Validator: https://validator.schema.org/
**Confidence:** High

### Finding 13.2: Pre-Publication Checklist for JSON-LD

**Claim:** Before going live with JSON-LD: validate JSON syntax with JSONLint, match schema types with page intent, check all `@id` references, test with Google Rich Results Test, test with Schema Markup Validator, ensure no errors or critical warnings, match content with visible page content, match URLs with canonical URLs, add dateModified if article is updated, and maintain a changelog. [^34^]

**Source:** clickforest.com
**URL:** https://www.clickforest.com/en/blog/json-ld-implementation-guide
**Date:** 2026-01-29
**Excerpt:** "Validate JSON syntax with JSONLint. Test with Google Rich Results Test. Test with Schema Markup Validator. No errors or critical warnings in validators. Content in structured data matches visible page content."
**Context:** Batch process: first 5 pages live, monitor 48h, then roll out to more pages.
**Confidence:** High

---

## 14. Impact of Schema on AI Search Visibility

### Finding 14.1: Structured Data Increases AI Citation Probability by 35%

**Claim:** Structured data alone increases citation probability by 35% in AI-generated results. By 2027, AI search interfaces will influence 70% of online discovery journeys. Structured data adoption remains below 30%, leaving massive first-mover advantage. [^35^]

**Source:** DGTLmart
**URL:** https://dgtlmart.com/blog/ai-seo-services-for-chatgpt-gemini-perplexity-how-to-rank/
**Date:** 2025-10-31
**Excerpt:** "Structured data alone increases citation probability by 35% in AI-generated results. By 2027, AI search interfaces will influence 70% of online discovery journeys."
**Context:** ChatGPT leads AI referral traffic at 79%. Perplexity accounts for nearly 20% of AI traffic to health and ecommerce websites.
**Confidence:** Medium

### Finding 14.2: Schema Markup is a GEO (Generative Engine Optimization) Measure

**Claim:** Local Schema Markup is simultaneously a GEO measure. AI systems use structured data to generate precise local recommendations. When a user asks an AI assistant for a business with specific requirements, the system can only generate accurate answers from structured opening hours and location data. [^36^]

**Source:** blckalpaca.at
**URL:** https://blckalpaca.at/en/knowledge-base/seo-geo/local-seo/local-schema-markup-structured-data-for-local-search
**Date:** 2026-04-07
**Excerpt:** "Local Schema Markup is simultaneously a GEO measure. AI systems use structured data to generate precise local recommendations. When a user asks ChatGPT for a tax advisor in Vienna with Saturday opening hours, the system can only generate the answer from structured opening hours data."
**Context:** This directly applies to security doors businesses -- when someone asks "who installs security doors in Sutherland Shire?", AI assistants read structured data first.
**Confidence:** High

### Finding 14.3: AI Traffic Shows Superior Engagement

**Claim:** AI traffic shows 23% lower bounce rate, 12% more page views, and 41% longer session duration than non-AI traffic. This makes optimization for AI search highly valuable. [^37^]

**Source:** WSINextGenMarketing
**URL:** https://wsinextgenmarketing.com/how-generative-ai-is-reshaping-search-visibility-in-2025/
**Date:** 2025-10-30
**Excerpt:** "By February 2025, AI traffic had a 23% lower bounce rate than all other traffic, generated 12% more page views, and lasted 41% longer than non-AI traffic."
**Context:** 88% of AI summaries cited three or more sources, meaning AI platforms prefer diverse source citations.
**Confidence:** Medium

### Finding 14.4: Content Transformation for AI Visibility

**Claim:** Go Fish Digital demonstrated that strategic content optimization can directly influence ChatGPT Search results. By adding structured "Notable Clients" sections with bullet-point key-value pairs, they gained enhanced trust signals in AI-generated responses within one week. [^38^]

**Source:** StartupGTM
**URL:** https://startupgtm.substack.com/p/get-visibility-in-chatgpt-perplexity
**Date:** 2025-07-04
**Excerpt:** "Key Takeaway: 'When ChatGPT uses the Search function, right now you CAN have the ability to influence the output. The first thing you need is an article/piece of content that can feed into the citations'."
**Context:** Structured data like FAQPage, Organization, and HowTo schema provide the machine-readable format that AI systems prefer for citations.
**Confidence:** High

---

## 15. Complete JSON-LD Examples

### 15.1 Homepage: Complete LocalBusiness Schema (Main Schema)

**Recommended @type:** `HomeAndConstructionBusiness` (most specific available subtype for a security/home improvement business)

**Note:** Place this on the homepage. Uses `@graph` to combine WebSite, Organization, and LocalBusiness in a single script block.

```json
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "WebSite",
      "@id": "https://shiredoors.com.au/#website",
      "url": "https://shiredoors.com.au/",
      "name": "Shire Security Doors and Screens",
      "description": "Security doors, window screens, plantation shutters and outdoor blinds in Sutherland Shire, Sydney. Master Security Licence #000105713. Prowler Proof Authorised Dealer.",
      "publisher": {
        "@id": "https://shiredoors.com.au/#organization"
      }
    },
    {
      "@type": "Organization",
      "@id": "https://shiredoors.com.au/#organization",
      "name": "Shire Security Doors and Screens",
      "alternateName": "Shire Doors",
      "url": "https://shiredoors.com.au/",
      "logo": {
        "@type": "ImageObject",
        "url": "https://shiredoors.com.au/logo.png",
        "width": 600,
        "height": 60
      },
      "image": "https://shiredoors.com.au/images/showroom.jpg",
      "description": "Sydney's leading security door and window screen specialists. Supplying and installing security doors, fly screens, plantation shutters and outdoor blinds across the Sutherland Shire since 2005.",
      "sameAs": [
        "https://www.facebook.com/shiredoors",
        "https://www.instagram.com/shiredoors",
        "https://g.page/shiredoors"
      ],
      "contactPoint": {
        "@type": "ContactPoint",
        "telephone": "+61-410-474-256",
        "contactType": "customer service",
        "areaServed": ["Sutherland Shire", "Sydney"],
        "availableLanguage": ["English"],
        "email": "steve@shiredoors.com.au"
      }
    },
    {
      "@type": "HomeAndConstructionBusiness",
      "@id": "https://shiredoors.com.au/#localbusiness",
      "name": "Shire Security Doors and Screens",
      "url": "https://shiredoors.com.au/",
      "telephone": "+61-410-474-256",
      "email": "steve@shiredoors.com.au",
      "description": "Sydney's leading security door and window screen specialists serving the Sutherland Shire. Master Security Licence #000105713. Prowler Proof Authorised Dealer. NSSA Member.",
      "image": "https://shiredoors.com.au/images/showroom.jpg",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "Unit 2, 1011 Old Princes Highway",
        "addressLocality": "Engadine",
        "addressRegion": "NSW",
        "postalCode": "2233",
        "addressCountry": "AU"
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": -34.0656,
        "longitude": 151.0120
      },
      "openingHoursSpecification": [
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
          "opens": "07:00",
          "closes": "17:00"
        },
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": "Saturday",
          "opens": "08:00",
          "closes": "14:00"
        }
      ],
      "priceRange": "$$",
      "areaServed": [
        {
          "@type": "City",
          "name": "Engadine"
        },
        {
          "@type": "City",
          "name": "Sutherland"
        },
        {
          "@type": "City",
          "name": "Cronulla"
        },
        {
          "@type": "City",
          "name": "Menai"
        },
        {
          "@type": "City",
          "name": "Miranda"
        },
        {
          "@type": "City",
          "name": "Caringbah"
        },
        {
          "@type": "AdministrativeArea",
          "name": "Sutherland Shire"
        },
        {
          "@type": "City",
          "name": "Sydney"
        }
      ],
      "hasOfferCatalog": {
        "@type": "OfferCatalog",
        "name": "Security and Screening Services",
        "itemListElement": [
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Security Doors",
              "url": "https://shiredoors.com.au/services/security-doors/",
              "description": "Premium security doors including Prowler Proof forcefield, diamond grille and stainless steel mesh options. Custom made to fit your home."
            }
          },
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Window Screens",
              "url": "https://shiredoors.com.au/services/security-screens/",
              "description": "Security window screens, fly screens and mesh options to protect your home while maintaining ventilation and views."
            }
          },
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Plantation Shutters",
              "url": "https://shiredoors.com.au/services/plantation-shutters/",
              "description": "Beautiful plantation shutters in PVC and timber. Custom fitted to enhance your home's style, privacy and energy efficiency."
            }
          },
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Outdoor Blinds",
              "url": "https://shiredoors.com.au/services/outdoor-blinds/",
              "description": "Ziptrak, patio and outdoor blinds to extend your living space. Protection from sun, wind and rain all year round."
            }
          }
        ]
      },
      "additionalType": [
        "https://www.wikidata.org/wiki/Q2912397",
        "https://en.wikipedia.org/wiki/Home_improvement"
      ],
      "hasCredential": "Master Security Licence #000105713",
      "memberOf": {
        "@type": "Organization",
        "name": "National Security Screen Association (NSSA)"
      },
      "potentialAction": {
        "@type": "ReserveAction",
        "name": "Book Free Measure & Quote",
        "target": {
          "@type": "EntryPoint",
          "urlTemplate": "https://shiredoors.com.au/contact/"
        }
      }
    }
  ]
}
</script>
```

---

### 15.2 Service Schema for Each Service Type

#### A. Security Doors Service Page Schema
```json
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "BreadcrumbList",
      "@id": "https://shiredoors.com.au/services/security-doors/#breadcrumb",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://shiredoors.com.au/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Services",
          "item": "https://shiredoors.com.au/services/"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": "Security Doors"
        }
      ]
    },
    {
      "@type": "Service",
      "@id": "https://shiredoors.com.au/services/security-doors/#service",
      "name": "Security Doors Sydney | Sutherland Shire",
      "url": "https://shiredoors.com.au/services/security-doors/",
      "description": "Premium security doors custom made and professionally installed. Prowler Proof forcefield, diamond grille and stainless steel mesh options. Master Security Licence #000105713.",
      "provider": {
        "@type": "HomeAndConstructionBusiness",
        "@id": "https://shiredoors.com.au/#localbusiness"
      },
      "serviceType": "Security Door Installation",
      "additionalType": "https://en.wikipedia.org/wiki/Security_door",
      "areaServed": {
        "@type": "AdministrativeArea",
        "name": "Sutherland Shire",
        "containedInPlace": {
          "@type": "City",
          "name": "Sydney"
        }
      },
      "hasOfferCatalog": {
        "@type": "OfferCatalog",
        "name": "Security Door Products",
        "itemListElement": [
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Product",
              "name": "Prowler Proof Forcefield Security Door",
              "description": "Stainless steel mesh security door with patented Forcefield technology. Unmatched strength and clear views.",
              "brand": {
                "@type": "Brand",
                "name": "Prowler Proof"
              }
            }
          },
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Product",
              "name": "Diamond Grille Security Door",
              "description": "Classic diamond pattern grille security door. Affordable protection with a traditional look."
            }
          },
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Product",
              "name": "Stainless Steel Mesh Security Door",
              "description": "Marine-grade stainless steel mesh for maximum corrosion resistance and security in coastal areas."
            }
          }
        ]
      }
    }
  ]
}
</script>
```

#### B. Window Screens Service Page Schema
```json
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "BreadcrumbList",
      "@id": "https://shiredoors.com.au/services/security-screens/#breadcrumb",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://shiredoors.com.au/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Services",
          "item": "https://shiredoors.com.au/services/"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": "Window Screens"
        }
      ]
    },
    {
      "@type": "Service",
      "@id": "https://shiredoors.com.au/services/security-screens/#service",
      "name": "Security Window Screens | Fly Screens Sydney",
      "url": "https://shiredoors.com.au/services/security-screens/",
      "description": "Security window screens and fly screens custom fitted to your windows. Prowler Proof, stainless steel mesh and fibreglass options available across the Sutherland Shire.",
      "provider": {
        "@type": "HomeAndConstructionBusiness",
        "@id": "https://shiredoors.com.au/#localbusiness"
      },
      "serviceType": "Window Screen Installation",
      "additionalType": "https://en.wikipedia.org/wiki/Window_screen",
      "areaServed": {
        "@type": "AdministrativeArea",
        "name": "Sutherland Shire",
        "containedInPlace": {
          "@type": "City",
          "name": "Sydney"
        }
      }
    }
  ]
}
</script>
```

#### C. Plantation Shutters Service Page Schema
```json
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "BreadcrumbList",
      "@id": "https://shiredoors.com.au/services/plantation-shutters/#breadcrumb",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://shiredoors.com.au/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Services",
          "item": "https://shiredoors.com.au/services/"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": "Plantation Shutters"
        }
      ]
    },
    {
      "@type": "Service",
      "@id": "https://shiredoors.com.au/services/plantation-shutters/#service",
      "name": "Plantation Shutters Sydney | Sutherland Shire",
      "url": "https://shiredoors.com.au/services/plantation-shutters/",
      "description": "Custom plantation shutters in PVC and timber, professionally measured and fitted. Enhance your home's style, privacy and energy efficiency across the Sutherland Shire.",
      "provider": {
        "@type": "HomeAndConstructionBusiness",
        "@id": "https://shiredoors.com.au/#localbusiness"
      },
      "serviceType": "Plantation Shutter Installation",
      "additionalType": "https://en.wikipedia.org/wiki/Window_shutter",
      "areaServed": {
        "@type": "AdministrativeArea",
        "name": "Sutherland Shire",
        "containedInPlace": {
          "@type": "City",
          "name": "Sydney"
        }
      }
    }
  ]
}
</script>
```

#### D. Outdoor Blinds Service Page Schema
```json
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "BreadcrumbList",
      "@id": "https://shiredoors.com.au/services/outdoor-blinds/#breadcrumb",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://shiredoors.com.au/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Services",
          "item": "https://shiredoors.com.au/services/"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": "Outdoor Blinds"
        }
      ]
    },
    {
      "@type": "Service",
      "@id": "https://shiredoors.com.au/services/outdoor-blinds/#service",
      "name": "Outdoor Blinds Sydney | Ziptrak & Patio Blinds",
      "url": "https://shiredoors.com.au/services/outdoor-blinds/",
      "description": "Ziptrak, patio and outdoor blinds to extend your living space. Custom fitted protection from sun, wind and rain. Servicing the Sutherland Shire and Sydney.",
      "provider": {
        "@type": "HomeAndConstructionBusiness",
        "@id": "https://shiredoors.com.au/#localbusiness"
      },
      "serviceType": "Outdoor Blind Installation",
      "additionalType": "https://en.wikipedia.org/wiki/Window_blind",
      "areaServed": {
        "@type": "AdministrativeArea",
        "name": "Sutherland Shire",
        "containedInPlace": {
          "@type": "City",
          "name": "Sydney"
        }
      }
    }
  ]
}
</script>
```

---

### 15.3 FAQPage Schema

**Note:** Place this FAQPage schema on individual service pages to answer service-specific questions. Do NOT place on the homepage. Each service page should have its own relevant FAQPage schema.

```json
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "@id": "https://shiredoors.com.au/services/security-doors/#faq",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What types of security doors do you install in Sutherland Shire?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "We install a range of premium security doors including Prowler Proof Forcefield (stainless steel mesh), diamond grille doors, and heavy-duty aluminium frame doors. All are custom measured and professionally installed by licensed technicians with Master Security Licence #000105713."
      }
    },
    {
      "@type": "Question",
      "name": "How much does a security door cost in Sydney?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Security door prices vary based on size, style and material. Our diamond grille security doors start from an affordable price point, while Prowler Proof Forcefield stainless steel mesh doors are at the premium end. We offer free on-site measure and quote throughout the Sutherland Shire. Call 0410 474 256 or book online."
      }
    },
    {
      "@type": "Question",
      "name": "Are your security doors compliant with Australian standards?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes, all our security doors meet or exceed Australian Standards AS5039 and AS5040 for security screen doors and security door installations. We are NSSA (National Security Screen Association) members and Prowler Proof authorised dealers, ensuring the highest quality products and installation standards."
      }
    },
    {
      "@type": "Question",
      "name": "Do you service areas outside of Sutherland Shire?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes, while we are based in Engadine in the heart of the Sutherland Shire, we service surrounding Sydney suburbs including Menai, Cronulla, Caringbah, Miranda, Sutherland, Loftus, Yarrawarrah and beyond. Contact us on 0410 474 256 to confirm service to your area."
      }
    },
    {
      "@type": "Question",
      "name": "How long does security door installation take?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Most standard security door installations are completed in 2-3 hours. Custom-made security doors require a manufacturing period of approximately 2-3 weeks from measure to installation. We will provide a clear timeline during your free quote appointment."
      }
    }
  ]
}
</script>
```

---

### 15.4 BreadcrumbList Schema

#### Contact Page Breadcrumb Example
```json
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "@id": "https://shiredoors.com.au/contact/#breadcrumb",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Home",
      "item": "https://shiredoors.com.au/"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "Contact Us"
    }
  ]
}
</script>
```

---

### 15.5 Organization Schema

**Note:** This should appear on every page of the website, typically in a global script tag in the site header or footer. The `@id` must match the reference used in other schemas.

```json
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "@id": "https://shiredoors.com.au/#organization",
  "name": "Shire Security Doors and Screens",
  "alternateName": ["Shire Doors", "Shire Security Doors"],
  "url": "https://shiredoors.com.au/",
  "logo": {
    "@type": "ImageObject",
    "url": "https://shiredoors.com.au/logo.png",
    "width": 600,
    "height": 60
  },
  "image": "https://shiredoors.com.au/images/showroom.jpg",
  "description": "Sydney's trusted security door and window screen specialists. Master Security Licence #000105713. Prowler Proof Authorised Dealer. NSSA Member.",
  "foundingDate": "2005",
  "founder": {
    "@type": "Person",
    "name": "Steve"
  },
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "Unit 2, 1011 Old Princes Highway",
    "addressLocality": "Engadine",
    "addressRegion": "NSW",
    "postalCode": "2233",
    "addressCountry": "AU"
  },
  "contactPoint": [
    {
      "@type": "ContactPoint",
      "telephone": "+61-410-474-256",
      "contactType": "customer service",
      "availableLanguage": ["English"],
      "areaServed": "AU",
      "email": "steve@shiredoors.com.au"
    },
    {
      "@type": "ContactPoint",
      "telephone": "+61-410-474-256",
      "contactType": "sales",
      "availableLanguage": ["English"],
      "areaServed": "AU"
    }
  ],
  "sameAs": [
    "https://www.facebook.com/shiredoors",
    "https://www.instagram.com/shiredoors",
    "https://g.page/shiredoors"
  ],
  "hasCredential": "Master Security Licence #000105713",
  "memberOf": {
    "@type": "Organization",
    "name": "National Security Screen Association (NSSA)"
  },
  "brand": {
    "@type": "Brand",
    "name": "Prowler Proof Authorised Dealer"
  }
}
</script>
```

---

### 15.6 WebSite Schema

**Note:** Google's sitelinks search box display feature was retired in November 2024. However, WebSite schema still provides valuable entity definition. The SearchAction component is optional but still valid schema.

```json
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "@id": "https://shiredoors.com.au/#website",
  "url": "https://shiredoors.com.au/",
  "name": "Shire Security Doors and Screens",
  "description": "Security doors, window screens, plantation shutters and outdoor blinds in Sutherland Shire, Sydney. Master Security Licence #000105713.",
  "publisher": {
    "@id": "https://shiredoors.com.au/#organization"
  },
  "inLanguage": "en-AU"
}
</script>
```

---

### 15.7 HowTo Schema Example

**Note:** Use HowTo schema on blog posts or dedicated guide pages. Example below for a "How to Choose the Right Security Door" guide.

```json
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "@id": "https://shiredoors.com.au/blog/choose-security-door/#howto",
  "name": "How to Choose the Right Security Door for Your Sydney Home",
  "description": "A step-by-step guide to selecting the best security door for your home. Learn about different types, materials, and what to look for in a quality installation.",
  "image": {
    "@type": "ImageObject",
    "url": "https://shiredoors.com.au/images/blog/security-door-guide.jpg"
  },
  "totalTime": "PT15M",
  "estimatedCost": {
    "@type": "MonetaryAmount",
    "currency": "AUD",
    "value": "0"
  },
  "supply": [
    {
      "@type": "HowToSupply",
      "name": "Tape Measure"
    },
    {
      "@type": "HowToSupply",
      "name": "Camera or Smartphone"
    }
  ],
  "tool": [
    {
      "@type": "HowToTool",
      "name": "Pen and Paper for Notes"
    }
  ],
  "step": [
    {
      "@type": "HowToStep",
      "position": 1,
      "name": "Measure Your Door Opening",
      "text": "Measure the height and width of your existing door frame opening. Record both measurements accurately as security doors are custom-made to fit. Standard Australian door openings are typically 2040mm high and 820mm, 870mm or 920mm wide.",
      "url": "https://shiredoors.com.au/blog/choose-security-door/#step1",
      "image": "https://shiredoors.com.au/images/blog/measure-door.jpg"
    },
    {
      "@type": "HowToStep",
      "position": 2,
      "name": "Choose Your Security Door Type",
      "text": "Consider the three main types: Prowler Proof Forcefield (highest security, clear views), Diamond Grille (affordable, traditional look), or Stainless Steel Mesh (marine-grade corrosion resistance ideal for coastal Sutherland Shire homes). Each offers different levels of protection and aesthetics.",
      "url": "https://shiredoors.com.au/blog/choose-security-door/#step2",
      "image": "https://shiredoors.com.au/images/blog/door-types.jpg"
    },
    {
      "@type": "HowToStep",
      "position": 3,
      "name": "Check Australian Standards Compliance",
      "text": "Ensure any security door you choose meets Australian Standards AS5039 (security screen doors and security window grilles) and AS5040 (installation of security screen doors and window grilles). Ask your supplier for certification.",
      "url": "https://shiredoors.com.au/blog/choose-security-door/#step3",
      "image": "https://shiredoors.com.au/images/blog/australian-standards.jpg"
    },
    {
      "@type": "HowToStep",
      "position": 4,
      "name": "Select Your Frame and Colour",
      "text": "Choose between powder-coated aluminium frames in a range of colours to match your home. Popular options include White, Black, Cream, Brown and heritage colours. A professional supplier will have colour samples to compare against your existing frames.",
      "url": "https://shiredoors.com.au/blog/choose-security-door/#step4",
      "image": "https://shiredoors.com.au/images/blog/frame-colours.jpg"
    },
    {
      "@type": "HowToStep",
      "position": 5,
      "name": "Book a Professional Measure and Quote",
      "text": "Contact a licensed security door installer for a free on-site measure and quote. A professional will verify your measurements, assess installation requirements, and provide an accurate fixed-price quote. In the Sutherland Shire, call Shire Security Doors on 0410 474 256 to book your free consultation.",
      "url": "https://shiredoors.com.au/blog/choose-security-door/#step5",
      "image": "https://shiredoors.com.au/images/blog/professional-quote.jpg"
    }
  ]
}
</script>
```

---

## Implementation Strategy

### Phase 1: Site-Wide Schemas (Week 1)
- Implement Organization schema in global site header/footer (all pages)
- Implement WebSite schema on homepage
- Validate with Google Rich Results Test and Schema Markup Validator

### Phase 2: Homepage & Service Pages (Week 2)
- Implement combined LocalBusiness + Service OfferCatalog on homepage
- Implement BreadcrumbList on all service pages
- Implement standalone Service schema on each service page
- Add FAQPage schema to each service page with relevant Q&A

### Phase 3: Content Pages (Week 3-4)
- Implement HowTo schema on blog posts/guides
- Implement Article/BlogPosting schema on all blog content
- Add Product schema where applicable (individual product pages)

### Phase 4: Testing & Monitoring (Ongoing)
- Test all pages with Google Rich Results Test
- Monitor Google Search Console for structured data errors
- Review AI visibility after 6-8 weeks (ChatGPT, Gemini, Perplexity)
- Update schema when business details change

---

## Key Recommendations Summary

| Priority | Schema Type | Pages | Purpose |
|----------|-------------|-------|---------|
| Critical | LocalBusiness | Homepage | Local search, Maps, Knowledge Panel |
| Critical | Organization | All pages | Brand identity, Knowledge Graph |
| Critical | Service | Service pages | Service-specific rankings |
| High | FAQPage | Service pages | Rich snippets, AI answers |
| High | BreadcrumbList | All pages (except homepage) | Navigation, CTR improvement |
| High | WebSite | Homepage | Site entity definition |
| Medium | HowTo | Blog/guides | Step-by-step rich results |
| Medium | Product | Product detail pages | Product rich results |
| Medium | Article/BlogPosting | Blog posts | Content rich results |

---

## Important Warnings

### Self-Serving Review Rule
**Do NOT** mark up customer testimonials on your own website using LocalBusiness or Organization schema. This violates Google's guidelines and may result in manual actions. Instead:
- Focus on building reviews on Google Business Profile
- Use third-party review platforms (Yelp, ProductReview, etc.)
- Only use Review/AggregateRating schema on Product pages (reviewing specific products, not the business)

### Content Matching
All schema content MUST match visible on-page content. Do not mark up invisible or misleading elements. Google's spam policies (2025) explicitly prohibit this.

### Validation
Always validate schema before deployment:
1. **Google Rich Results Test:** https://search.google.com/test/rich-results
2. **Schema Markup Validator:** https://validator.schema.org/
3. **JSONLint:** https://jsonlint.com/ (for JSON syntax validation)

---

*Research compiled: 2025*
*Sources: 25+ authoritative references including Schema.org, Google Search Central, Schema App, BrightLocal, StudioHawk, and industry-leading SEO publications*
