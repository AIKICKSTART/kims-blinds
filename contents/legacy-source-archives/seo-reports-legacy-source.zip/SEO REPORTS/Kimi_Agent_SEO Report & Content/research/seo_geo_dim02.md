# Dimension 2: On-Page SEO Optimization

**Website:** https://shire-security-doors-demo.vercel.app/  
**Business:** Shire Security Doors and Screens (Prowler Proof Authorised Dealer, Sutherland Shire, Sydney)  
**Date:** January 2025  
**Research Searches Conducted:** 18+

---

## Table of Contents
1. [Executive Summary](#1-executive-summary)
2. [Research Findings with Citations](#2-research-findings-with-citations)
   - 2.1 [Title Tag Best Practices](#21-title-tag-best-practices)
   - 2.2 [Meta Description Optimization](#22-meta-description-optimization)
   - 2.3 [H1, H2, H3 Heading Structure](#23-heading-structure)
   - 2.4 [Keyword Density and Placement](#24-keyword-density-and-placement)
   - 2.5 [Content Length Recommendations](#25-content-length-recommendations)
   - 2.6 [Image Alt Text Optimization](#26-image-alt-text-optimization)
   - 2.7 [Internal Linking Strategies](#27-internal-linking-strategies)
   - 2.8 [SEO-Friendly URL Structures](#28-seo-friendly-url-structures)
   - 2.9 [Optimization for "Near Me" Searches](#29-optimization-for-near-me-searches)
   - 2.10 [Product/Service Schema Markup](#210-productservice-schema-markup)
   - 2.11 [Featured Snippet Optimization](#211-featured-snippet-optimization)
   - 2.12 [Voice Search Content Optimization](#212-voice-search-content-optimization)
3. [Current Website Analysis](#3-current-website-analysis)
4. [Specific Recommendations by Page](#4-specific-recommendations-by-page)
5. [Implementation Priority Matrix](#5-implementation-priority-matrix)
6. [References](#6-references)

---

## 1. Executive Summary

This report provides comprehensive on-page SEO recommendations for Shire Security Doors and Screens, a Prowler Proof authorised dealer operating in Sutherland Shire, Sydney. The research covers 12 critical on-page SEO dimensions based on 2025-2026 best practices and current industry data.

### Key Findings:
- **Title tags** should be 30-60 characters with primary keyword front-loaded and location specified [^31^]
- **Meta descriptions** should be 120-160 characters featuring local keywords and unique selling points [^31^][^32^]
- **H1 tags** must include primary service + location (e.g., "Security Doors in Sutherland Shire") [^32^][^33^]
- **Keyword density** should be 1-2% with strategic placement in first 100 words, headings, alt text [^34^][^36^]
- **Content length** for service pages: minimum 300-600 words; optimal 800-1,500 words; pillar content 1,500-2,500+ words [^126^][^128^][^130^]
- **Alt text** should be 5-15 words (125 characters), descriptive, with natural keyword inclusion [^48^][^51^]
- **Internal linking** should use descriptive anchor text with 3-5 links per 1000 words [^50^][^46^]
- **URLs** should be under 60 characters using hyphens, lowercase, with focus keyword near the start [^49^][^55^]
- **"Near me" optimization** requires Google Business Profile, local landing pages, and NAP consistency [^78^][^80^]
- **Schema markup** should include LocalBusiness, Service, FAQPage, and BreadcrumbList [^86^][^88^]
- **Featured snippets** require 40-60 word answers under H2/H3 headings with structured content [^83^]
- **Voice search** favors conversational keywords, FAQ schema, and question-based content [^81^][^84^][^85^]

---

## 2. Research Findings with Citations

### 2.1 Title Tag Best Practices

#### Finding 1: Character Length and Structure
```
Claim: Title tags should aim for 30-60 characters with clarity first, front-loading the main topic, adding a specific hook, and keeping branding at the end. [^31^]
Source: SeekLab - SEO Title Tags & Meta Descriptions: Best Practices For 2026
URL: https://seeklab.io/blog/on-page-seo-titles-metas-structure/
Date: 2026-06-03
Excerpt: "Aim for clarity first, then worry about length. A common target is roughly 30 to 60 characters, but pixel width is what determines truncation. Front-load the main topic naturally (especially on competitive queries). Add a specific hook (scope, audience, year, or outcome). Keep branding consistent, usually at the end."
Context: Service pages should follow the formula: Service + qualifier + location/market.
Confidence: High
```

#### Finding 2: Local Service Page Title Tags
```
Claim: Put target keyword and city name in the title tag of every location-relevant page, keeping titles under 60 characters while including both target keyword and location. [^32^][^37^]
Source: TerraHQ - Essential Local SEO Checklist for 2026
URL: https://terrahq.com/en/blog/optimizing-local-seo-the-2024-8-step-checklist/
Date: 2026-06-08
Excerpt: "Put the target keyword and city name in the title tag of every location-relevant page... Title tag optimization requires precision. Keep titles under 60 characters while including both your target keyword and location. 'Emergency Plumbing Services in Austin, TX - 24/7 Response' clearly communicates both service and location within search engine display limits."
Context: The title tag must clearly communicate both service and location within search engine display limits.
Confidence: High
```

#### Finding 3: Front-Load Keywords and Location
```
Claim: Search engines give more weight to the first few words in the title tag. Start with the main service keyword, followed by the location. [^45^]
Source: Best Version Media - Location-Based Page Titles Explained
URL: https://www.bestversionmedia.com/location-based-page-titles-explained-a-practical-strategy-to-boost-local-seo/
Date: 2025-10-22
Excerpt: "Search engines tend to give more weight to the first few words in your title tag. To maximize SEO impact, start with your main service or product keyword, followed by the location... More effective: 'Austin Plumbing Services | Emergency & Residential'"
Context: Early placement of the keyword and location captures both user and search engine attention immediately.
Confidence: High
```

#### Finding 4: Title Tag Patterns for Service Pages
```
Claim: For service pages, use the formula: Service + qualifier + location/market. Include specific location names rather than broad terms. [^31^][^45^]
Source: SeekLab + Best Version Media
URL: https://seeklab.io/blog/on-page-seo-titles-metas-structure/
Date: 2026-06-03
Excerpt: "Service page: Technical SEO Audit for B2B Sites (US, EU, APAC)... The more precise your location, the better, as users may search for a wide range of locations like city names, zip codes or neighborhoods."
Context: For Sutherland Shire, use specific location names like "Sutherland Shire" and "Sydney" rather than just "NSW."
Confidence: High
```

### 2.2 Meta Description Optimization

#### Finding 5: Length and Content
```
Claim: Meta descriptions should be 120-160 characters (with mobile usually truncating earlier), featuring local keywords and unique selling points specific to that location. [^31^][^37^]
Source: SeekLab + Arc4 Complete Guide to Local SEO Rankings
URL: https://seeklab.io/blog/on-page-seo-titles-metas-structure/
Date: 2026-06-03
Excerpt: "A safe target range is often 120 to 160 characters, with mobile usually truncating earlier... Meta descriptions within 160 characters should feature local keywords and unique selling points specific to that location."
Context: While not a direct ranking factor, meta descriptions are a major CTR lever and often determine whether users click.
Confidence: High
```

#### Finding 6: Unique Meta Descriptions Per Page
```
Claim: Write unique meta descriptions (155-160 characters) for each key page, including a local keyword and a compelling call-to-action. [^32^]
Source: TerraHQ - Essential Local SEO Checklist for 2026
URL: https://terrahq.com/en/blog/optimizing-local-seo-the-2024-8-step-checklist/
Date: 2026-06-08
Excerpt: "Write unique meta descriptions (155-160 characters) for each key page, including a local keyword... Add FAQPage schema to your most important pages (AI Overviews pull heavily from FAQ-structured content)."
Context: Each service page needs its own unique meta description that includes location-specific keywords.
Confidence: High
```

### 2.3 H1, H2, H3 Heading Structure

#### Finding 7: One H1 Per Page with Service + Location
```
Claim: Use H1 tags that name your primary service and city (e.g., 'Plumbing Services in Denver'). The H1 should follow the formula: Topic or Service + Qualifier + (Optional) Audience or Location. [^32^][^33^]
Source: TerraHQ + SEO Team Toronto
URL: https://www.seoteamtoronto.ca/blog/header-structure-best-practices-h1-h2-h3
Date: 2026-02-03
Excerpt: "Use H1 tags that name your primary service and city (e.g., 'Plumbing Services in Denver')... H1: '{Service} for {Audience} in Toronto'... One page, one primary topic, one clear H1. The H1 should name the page's core subject in plain language."
Context: The H1 is the promise of the page - it tells both readers and crawlers what the page is about.
Confidence: High
```

#### Finding 8: H2s as Section Topics
```
Claim: Use H2s as main sections that support the H1 topic. Each H2 should answer a meaningful sub-question or decision point. Follow patterns like Problem -> Solution -> Proof -> Next Step for service pages. [^33^]
Source: SEO Team Toronto - Header Structure Best Practices
URL: https://www.seoteamtoronto.ca/blog/header-structure-best-practices-h1-h2-h3
Date: 2026-02-03
Excerpt: "Use H2s as the main sections that support that topic. Each H2 should answer a meaningful sub-question or decision point... Problem -> Solution -> Proof -> Next Step (great for service pages)"
Context: The first 1-2 sentences under an H2 should answer the heading directly - this improves clarity and creates snippet-ready sections.
Confidence: High
```

#### Finding 9: Don't Skip Heading Levels
```
Claim: Do not skip levels (avoid H2 to H4). H3s should only be used when an H2 needs sub-structure. Write headings that still make sense out of context. [^33^][^42^]
Source: SEO Team Toronto + DevTrios
URL: https://devtrios.com/blog/h1-tag-best-practices/
Date: 2026-03-01
Excerpt: "Do not skip levels. Avoid jumping from H2 to H4 because a template 'looks right.' Write headings that still make sense out of context. Search can surface a section without the rest of the page, and headings should hold up on their own."
Context: Headings are for structure, not styling. If you use headings as design elements, the hierarchy becomes noise.
Confidence: High
```

#### Finding 10: Heading Templates for Service Pages
```
Claim: For service pages, H1 should be '{Service} in {Location}', followed by H2s covering: what the service includes, who it's for, common problems, process/method, and FAQs. [^33^]
Source: SEO Team Toronto
URL: https://www.seoteamtoronto.ca/blog/header-structure-best-practices-h1-h2-h3
Date: 2026-02-03
Excerpt: "Template 1: Service Page (Single Intent)... H1: '{Service} for {Audience} in Toronto' (only when location is relevant); H2: 'What {Service} Covers'; H2: 'Who This Is For'; H2: 'Common Problems We Fix'; H2: 'Method and QA Process'; H2: 'FAQs'"
Context: This structure mirrors the buyer's evaluation flow and supports both readers and search crawlers.
Confidence: High
```

### 2.4 Keyword Density and Placement

#### Finding 11: Optimal Keyword Density
```
Claim: Ideal keyword density is between 1-2%. Focus on relevance, strategic placement, moderation, and supporting keyword use rather than exact density metrics. [^34^][^36^]
Source: Search Atlas + BIANYS
URL: https://searchatlas.com/blog/keyword-density/
Date: 2026-01-26
Excerpt: "If you respect these rules and focus on providing value to your readers, you will likely naturally reach an ideal density between 1% and 2%."
Context: Google's NLP-based ranking algorithms reward clarity and coherence, not keyword density.
Confidence: High
```

#### Finding 12: Strategic Keyword Placement Locations
```
Claim: Keywords should be placed in: titles and meta descriptions, H1/H2/H3 headings, first 100 words of content, image alt text, and anchor text of internal links. [^34^][^38^]
Source: Search Atlas + Armour Corporation
URL: https://searchatlas.com/blog/keyword-density/ + https://armourcorporation.com/mastering-precise-keyword-placement-for-superior-on-page-seo-techniques-strategies-and-deep-implementation/
Date: 2026-01-26 / 2025-11-05
Excerpt: "Include keywords in: Titles and meta descriptions; Headings (H1, H2, H3); First 100 words; Alt text; Anchor text... Place your main keyword early to signal relevance to crawlers and engage readers immediately."
Context: The first 100 words carry extra weight with search engines - include target keywords naturally within this section.
Confidence: High
```

#### Finding 13: Semantic Keywords and LSI
```
Claim: Use Latent Semantic Indexing (LSI) keywords - synonyms and related terms - instead of repeating the exact target keyword. Modern search engines use NLP to understand semantic relationships. [^35^][^34^]
Source: Post Affiliate Pro + Search Atlas
URL: https://www.postaffiliatepro.com/faq/optimal-keyword-density/
Date: 2025-11-28
Excerpt: "Using Latent Semantic Indexing (LSI) keywords-synonyms and related terms that are contextually relevant to your main keyword... Search engines have become sophisticated enough to recognize these semantic relationships and understand that your content is comprehensively covering the topic."
Context: For "security doors Sutherland Shire," use variations like "security screen doors," "home security doors Sydney," "Prowler Proof doors."
Confidence: High
```

### 2.5 Content Length Recommendations

#### Finding 14: Word Count is Not a Direct Ranking Factor
```
Claim: Google does not directly use word count as a ranking signal. Text length factors dropped to zero in correlation studies. What matters is topical coverage, relevance, and completeness - not padding. [^128^][^131^]
Source: SurferSEO + SEMrush
URL: https://surferseo.com/blog/word-count-does-not-matter-for-seo/
Date: 2025-08-14
Excerpt: "Text-length factors dropped to zero... Term usage surged in importance... Google isn't evaluating content the way it used to. With LLMs parsing pages using enormous context windows... it no longer relies on word count as a shortcut for quality. It evaluates meaning, relevance, and topical completeness."
Context: Content should be as long as needed to answer the question comprehensively - whether 200 or 2,000 words.
Confidence: High
```

#### Finding 15: Content Length Guidelines by Type
```
Claim: Minimum 300 words for standard pages, 200+ for product descriptions, 900+ for cornerstone content, and 1,500-2,500 for ranking-focused long-form content. Service pages should have at least 600-800 words. [^126^][^130^]
Source: Accentuate Agency + Yoast
URL: https://www.accentuate.agency/word-count-for-seo/ + https://yoast.com/blog-post-word-count-seo/
Date: 2025-09-10 / 2025-12-22
Excerpt: "Yoast advises a minimum of 300 words for pages or posts. Over 200 words for product descriptions. Upwards of 900 words for cornerstone content pages... Posts between 1,500-2,400 words typically perform best."
Context: For local service pages (trades/security), aim for 600-1,200 words minimum to provide sufficient depth and signal expertise.
Confidence: High
```

#### Finding 16: Quality Over Quantity
```
Claim: A 1,000-word page can outrank a 3,000-word article if it better aligns with searchers' needs. Focus on value, user intent, and direct answers rather than word count. [^131^][^136^]
Source: SEMrush + Search Engine Land
URL: https://www.semrush.com/blog/what-is-the-best-content-length-for-seo/
Date: 2025-09-16
Excerpt: "There is no single 'best' content length for SEO because the ideal length depends on search intent, topic complexity, and what it takes to create a better piece than competing pages. Google doesn't rank content based on word count. Instead, it evaluates whether content satisfies user intent."
Context: For Shire Security Doors service pages, aim for 800-1,200 words of genuinely useful content rather than padding to hit a word count.
Confidence: High
```

### 2.6 Image Alt Text Optimization

#### Finding 17: Alt Text Length and Format
```
Claim: Optimal alt text is 5-15 words or approximately 125 characters. It should be precise, context-related, and include the primary keyword naturally without keyword stuffing. [^48^][^51^]
Source: SEO-Day + Marketeam Australia
URL: https://www.seo-day.de/wiki/on-page-seo/bilder-seo/alt-tags.php?lang=en + https://marketeam.com.au/resources/articles/seo/alt-text-seo-everything-you-need-to-know
Date: 2026-04-01 / 2025-09-21
Excerpt: "Optimal: 5-15 words or 125 characters... Be descriptive but concise. Clearly describe what's in the image in a few words or a short sentence... Include relevant keywords naturally."
Context: Alt text serves both accessibility (screen readers) and SEO (image indexing, relevance signals).
Confidence: High
```

#### Finding 18: Alt Text for Local Business Images
```
Claim: For local businesses, add geographic detail appropriately in alt text. For example, use "Italian restaurant interior in Paddington, Brisbane" rather than just "restaurant interior." [^51^]
Source: Marketeam Australia
URL: https://marketeam.com.au/resources/articles/seo/alt-text-seo-everything-you-need-to-know
Date: 2025-09-21
Excerpt: "If your business is local, add geographic detail appropriately (when relevant). For example, 'Italian restaurant interior in Paddington, Brisbane' rather than just 'restaurant interior.'"
Context: Product/installation photos should include location references where relevant.
Confidence: High
```

#### Finding 19: Product Image Alt Text
```
Claim: Product images should include product name, color, size, material, and context. Each alt tag should be unique and descriptive rather than generic. [^48^]
Source: SEO-Day Alt Tags Guide
URL: https://www.seo-day.de/wiki/on-page-seo/bilder-seo/alt-tags.php?lang=en
Date: 2026-04-01
Excerpt: "Description: Product name, color, size, material; Keywords: Product category, brand, model; Context: Use case, target audience... Example: <img src='laptop-macbook-pro-16.jpg' alt='MacBook Pro 16 inch Space Gray laptop for professional video editing'>"
Context: Security door product images should describe the door type, mesh, and application.
Confidence: High
```

### 2.7 Internal Linking Strategies

#### Finding 20: Descriptive Anchor Text
```
Claim: Use descriptive anchor text that explains the destination page topic. Avoid generic phrases like "click here" or "learn more." Vary between exact, partial, semantic, and branded anchors. [^50^][^46^]
Source: PWD Digital Agency (Australia) + Ava Abrazzaq
URL: https://pwd.com.au/blog/internal-linking-for-seo/ + https://avaabrazzaq.com/insights/seo/internal-linking-strategy-local-businesses/
Date: 2026-04-07 / 2026-06-01
Excerpt: "Anchor text tells search engines what the linked page covers. Instead of generic 'click here' or 'read more,' use specific phrases that describe the destination content... Vary your anchor text naturally."
Context: Strong anchors include: "Prowler Proof security door options," "sliding security doors for patios," "Sutherland Shire window screen installation."
Confidence: High
```

#### Finding 21: Internal Linking Volume
```
Claim: Blog posts should have 3-5 internal links per 1000 words. Service pages should have 5-8 links to supporting content and related services. Core service pages should have at least 5-10 internal links pointing to them. [^50^][^53^]
Source: PWD Digital Agency + Richwood Marketing
URL: https://pwd.com.au/blog/internal-linking-for-seo/
Date: 2026-04-07
Excerpt: "Blog posts: 3-5 internal links per 1000 words; Service pages: 5-8 links to supporting content and related services; Homepage: 8-12 links to your most important pages... Five highly relevant links outperform twenty random ones every time."
Context: The most important pages on most small business websites are surprisingly underlinked from body content.
Confidence: High
```

#### Finding 22: Topic Clusters and Local SEO Silos
```
Claim: Build topic clusters around service areas. Group related pages around a central pillar page with cluster pages for subtopics. Every local service page should link upward to the main service pillar and laterally to related services. [^46^][^53^]
Source: Ava Abrazzaq + Richwood Marketing
URL: https://avaabrazzaq.com/insights/seo/internal-linking-strategy-local-businesses/
Date: 2026-06-01
Excerpt: "Every local service page links upward to the main city or service-area pillar. The city pillar links downward to every justified local service page. Closely related service pages link laterally when the user intent overlaps."
Context: For Shire Security Doors, the homepage is the pillar with 4 service cluster pages (Security Doors, Window Screens, Plantation Shutters, Outdoor Blinds) linking to each other contextually.
Confidence: High
```

### 2.8 SEO-Friendly URL Structures

#### Finding 23: URL Best Practices
```
Claim: Keep URLs under 60 characters, use hyphens (not underscores) to separate words, use lowercase only, include the focus keyword naturally, and use a logical hierarchy like /service/location or /category/page. [^49^][^55^]
Source: Straight North + Octaria
URL: https://www.straightnorth.com/blog/how-to-create-seo-friendly-urls-structure-length-and-optimization-tips/
Date: 2026-06-15
Excerpt: "Separate words with hyphens (not underscores). Google treats hyphens as spaces but underscores as joiners... Include the focus keyword naturally... youragency.com/services/seo-services/technical-seo"
Context: Current URLs like /services/security-doors are well-structured. Avoid changing URL structure unless necessary.
Confidence: High
```

#### Finding 24: Local URL Patterns
```
Claim: For local pages, use clean, readable formats like domain.com/service/city rather than auto-generated codes or complex parameter strings. [^37^]
Source: Arc4 - Complete Guide to Boost Local SEO Rankings
URL: https://arc4.com/local-landing-pages/
Date: 2025-11-13
Excerpt: "URL structure follows best practices with clean, readable formats like domain.com/service/city rather than auto-generated codes or complex parameter strings."
Context: The current structure (/services/security-doors, /services/security-screens) is SEO-friendly. Future suburb pages could use /services/security-doors/sutherland-shire.
Confidence: High
```

### 2.9 Optimization for "Near Me" Searches

#### Finding 25: Google's Three Local Ranking Factors
```
Claim: Google ranks local results based on three primary factors: Relevance (how well your listing matches the search), Proximity (distance from the searcher), and Prominence (how well-known and well-reviewed your business is). [^78^][^80^]
Source: SEONinja + SOCi
URL: https://www.seoninja.com/blog/seo/near-me-seo-local-search-optimization/
Date: 2026-04-23
Excerpt: "The algorithm evaluates three primary factors: Relevance measures how well your business matches the searcher's needs. Distance considers how far your business is from the searcher's location. Prominence evaluates how well-known and reputable your business is."
Context: To rank for "security doors near me," optimize all three: relevant content, clear location signals, and strong reviews.
Confidence: High
```

#### Finding 26: Google Business Profile Optimization
```
Claim: Your Google Business Profile is the foundation of near-me ranking. Businesses in the local 3-pack earn 126% more traffic and 93% more actions. Complete every section, choose specific categories, post updates regularly, and embed a Google Map on your website. [^80^][^78^]
Source: SOCi + SEONinja
URL: https://www.soci.ai/blog/seo-near-me/
Date: 2026-05-12
Excerpt: "Businesses that rank in Google's local 3-pack earn 126% more traffic and 93% more actions than those ranked below... Claim and optimize your Google Business Profile. Keep your Name, Address, and Phone consistent."
Context: GBP should list specific categories like "Security Door Supplier" as primary with "Window Installation Service" as secondary.
Confidence: High
```

#### Finding 27: NAP Consistency
```
Claim: NAP consistency (Name, Address, Phone) across all directories is critical. Even small variations like "St." versus "Street" can confuse Google and weaken rankings. Consistent NAP across directories lifts rankings by 20%. [^133^][^125^]
Source: HiAgency + Netstripes
URL: https://hiagency.au/local-seo/best-local-directories-for-seo/ + https://netstripes.com/blog/a-complete-seo-guide-for-businesses-in-australia/
Date: 2026-03-05 / 2026-06-10
Excerpt: "Use identical business name formatting everywhere... Format addresses identically including suite numbers, street abbreviations, and postal codes... Consistent NAP (Name, Address, Phone) across directories lifts rankings by 20%."
Context: Ensure the exact same business name, address format, and phone number appear on the website, GBP, and all Australian directories.
Confidence: High
```

### 2.10 Product/Service Schema Markup

#### Finding 28: Schema Markup for Rich Results
```
Claim: Schema markup enables rich snippets that can increase click-through rates by up to 82%. It provides semantic understanding for voice search and AI assistants. JSON-LD is the preferred format recommended by Google's John Mueller. [^86^]
Source: PushLeads - Complete Guide to Local Schema Markup
URL: https://pushleads.com/seo-timeline/complete-guide-to-local-schema-markup-implementation/
Date: 2025-11-09
Excerpt: "Schema markup enables rich snippets and enhanced SERP features that can increase click-through rates by up to 82% compared to standard listings. It provides the semantic understanding necessary for voice search and AI assistants... Google has specifically recommended JSON-LD as the preferred format."
Context: Schema markup is one of the clearest ways to signal your content should be cited in AI Overviews.
Confidence: High
```

#### Finding 29: Schema Types for Local Service Businesses
```
Claim: Local businesses should implement: LocalBusiness schema on homepage, Service schema on service pages, FAQPage schema on pages with FAQs, BreadcrumbList globally, and Review/AggregateRating on testimonials. [^88^][^86^]
Source: EseoSpace + PushLeads
URL: https://eseospace.com/blog/schema-markup-for-small-business-websites/
Date: 2025-08-20
Excerpt: "Map one entity per page type: One primary LocalBusiness entity on your homepage; one Service per service page; Product on product pages... Link entities with @id: Use stable IDs to connect LocalBusiness, Organization, WebSite, WebPage, Product, and Service across your site."
Context: For Shire Security Doors, add LocalBusiness with GeoCoordinates, Service schema for each of the 4 services, and FAQPage schema to all service pages.
Confidence: High
```

#### Finding 30: LocalBusiness Schema Requirements
```
Claim: LocalBusiness schema must include complete PostalAddress, openingHours, and avoid mismatched data. Keep NAP in schema consistent with on-page content and Google Business Profile. [^88^]
Source: EseoSpace
URL: https://eseospace.com/blog/schema-markup-for-small-business-websites/
Date: 2025-08-20
Excerpt: "Be specific with types: Choose precise LocalBusiness subtypes... Keep NAP consistent: Match your schema to Google Business Profile and top directories to reinforce trust... Common Pitfalls: Marking up reviews pulled from third-party platforms; Using LocalBusiness without a complete PostalAddress or openingHours; Mismatched data."
Context: The schema description should include keywords naturally in the name and description fields.
Confidence: High
```

### 2.11 Featured Snippet Optimization

#### Finding 31: Direct Answers for Snippets
```
Claim: Keep direct answers between 40-60 words. Use bullet points or numbered lists for steps, and create comparison tables where relevant. Place the answer immediately after the heading. [^83^]
Source: DevExHub - Zero-Click SEO in 2025
URL: https://devexhub.com/blog/zero-click-seo-in-2025-how-to-optimize-for-google-s-featured-snippets
Date: 2025
Excerpt: "Keep your direct answers between 40-60 words. Use bullet points or numbered lists when explaining steps. Create comparison tables where relevant... Use H2 for main topics, H3 for subtopics, and provide answers directly under the headings."
Context: Google pulls featured snippets from well-structured content that answers questions directly and concisely.
Confidence: High
```

#### Finding 32: Target Question-Based Keywords
```
Claim: Use long-tail, question-based keywords to target featured snippets. Focus on "how," "what," "where," and "why" queries that your audience is actually searching for. Use Google's "People Also Ask" and AnswerThePublic for research. [^83^]
Source: DevExHub
URL: https://devexhub.com/blog/zero-click-seo-in-2025-how-to-optimize-for-google-s-featured-snippets
Excerpt: "Use long-tail, question-based keywords like 'What are the best digital marketing strategies in 2025?' Use tools like Google's 'People Also Ask', AnswerThePublic, SEMrush or Ubersuggest."
Context: For security doors, target questions like "What are the best security doors for coastal homes?" or "How much do security doors cost in Sydney?"
Confidence: High
```

### 2.12 Voice Search Content Optimization

#### Finding 33: Conversational Keywords
```
Claim: Voice search queries are naturally conversational. Target long-tail keywords, question phrases ("how," "what," "where," "why"), and natural language patterns. Write at a middle school reading level. [^81^][^84^]
Source: Design in DC + SocioLabs
URL: https://designindc.com/blog/how-to-optimize-your-website-for-voice-search-in-2025/
Date: 2025
Excerpt: "Identify long-tail keywords: These mirror the natural, conversational phrasing users employ with voice assistants... Focus on question-based phrases: Think about common query starters like 'how,' 'what,' 'where,' or 'why.'"
Context: Instead of "security doors Sutherland Shire," target "Where can I get security doors installed in Sutherland Shire?"
Confidence: High
```

#### Finding 34: FAQ Sections for Voice Search
```
Claim: FAQ sections are voice search goldmines. Create 40-80 word answers that directly address common customer questions. Structure answers to sound natural when read aloud by voice assistants. [^85^]
Source: Graphicwise
URL: https://graphicwise.com/voice-search-local-seo/
Date: 2025-08-28
Excerpt: "FAQ page development: This becomes your voice search goldmine. Create 40-80 word answers that directly address common customer questions. Structure these answers to sound natural when read aloud by voice assistants."
Context: Each service page should include an FAQ section with 5-8 question/answer pairs.
Confidence: High
```

#### Finding 35: Essential Schema for Voice Search
```
Claim: Essential schema types for voice search include LocalBusiness schema, FAQPage schema, and Speakable schema (to identify voice-friendly content sections). Featured snippets are the primary source for spoken voice responses. [^85^]
Source: Graphicwise
URL: https://graphicwise.com/voice-search-local-seo/
Date: 2025-08-28
Excerpt: "Essential schema types for local businesses: LocalBusiness schema for core business information; FAQPage schema for question-and-answer content; Speakable schema to identify voice-friendly content sections... Featured snippets capture a significant portion of voice search traffic."
Context: 12.3% of search queries display featured snippets, and voice assistants frequently source answers from these results.
Confidence: High
```

#### Finding 36: Local Voice Search Optimization
```
Claim: Include geo-specific keywords like "restaurants near me" or "plumber in [city/town]." Keep Google Business Profile updated with accurate NAP. Voice assistants prioritize fast, mobile-friendly, technically sound websites with excellent Core Web Vitals. [^81^][^90^]
Source: Design in DC + BTWeb Group
URL: https://btwebgroup.com/blog/preparing-for-the-voice-search-revolution-seo-strategies-for-2025
Date: 2025-05-13
Excerpt: "Include geo-specific keywords: Use phrases like 'restaurants near me' or 'plumber in [city/town].' Keep your Google My Business profile updated: Make sure your name, address, and phone number (NAP) are accurate."
Context: Most voice searches are performed on mobile devices, making mobile-first optimization essential.
Confidence: High
```

---

## 3. Current Website Analysis

### Homepage (https://shire-security-doors-demo.vercel.app/)
**Current Title:** "Shire Security Doors and Screens | Security Doors Sutherland Shire"  
**Current H1:** "Sutherland Shire security doors and screens" (implied from hero section)  
**Content Assessment:** The homepage has a strong value proposition and clear trust signals (licence number, Prowler Proof authorisation, NSSA membership). However, the body content is relatively thin with only ~150 words of descriptive text.  
**Strengths:** Clean URL structure, mobile-responsive design, clear CTA buttons ("Free Measure & Quote"), trust signals prominently displayed  
**Weaknesses:** Limited body copy, no FAQ section, no embedded Google Map, no schema markup detected

### Security Doors Page (/services/security-doors)
**Current Title:** "Security Doors Sydney | Shire Security Doors and Screens"  
**Current H1:** "Security Doors"  
**Content Assessment:** Product categories listed (ForceField, Protec, Sliding, Diamond) with brief descriptions. Total body text ~200-300 words.  
**Strengths:** Clear product hierarchy, mentions Lockwood hardware, covers multiple door types  
**Weaknesses:** H1 lacks location qualifier, thin content, no FAQ, no pricing guidance, no customer testimonials

### Window Screens Page (/services/security-screens)
**Current Title:** "Security Screens Sydney | Shire Security Doors and Screens"  
**Current H1:** "Security Window Screens"  
**Content Assessment:** Similar structure to Security Doors with product categories (Fixed, Hinged, Sliding, Guardian). Body text ~200-300 words.  
**Strengths:** Product differentiation is clear, mentions fall prevention  
**Weaknesses:** Same thin content issues, H1 lacks location, no schema markup

### Plantation Shutters Page (/services/plantation-shutters)
**Current Title:** "Plantation Shutters Sydney | Shire Security Doors and Screens"  
**Current H1:** "Plantation Shutters"  
**Content Assessment:** Softer interior-focused messaging. Mentions Thermopoly material, light control, temperature comfort. ~200-250 words.  
**Strengths:** Good tone differentiation from security pages  
**Weaknesses:** Same content thinness, no location in H1, no FAQ

### Outdoor Blinds Page (/services/outdoor-blinds)
*(Not reviewed in detail but expected to follow same pattern)*

### Contact Page (/contact)
*(Standard contact page - should include NAP, embedded map, contact form, and LocalBusiness schema)*

---

## 4. Specific Recommendations by Page

### 4.1 Homepage Recommendations

#### Current Title Tag:
```
Shire Security Doors and Screens | Security Doors Sutherland Shire
```

#### Recommended Title Tag:
```
Security Doors & Screens Sutherland Shire | Prowler Proof Dealer
```
**Rationale:** Front-loads primary keyword "Security Doors & Screens," includes location "Sutherland Shire," adds "Prowler Proof Dealer" as a trust/USPs qualifier. 54 characters. [^31^][^45^]

#### Recommended Meta Description:
```
Prowler Proof authorised dealer installing security doors, window screens, plantation shutters & outdoor blinds across Sutherland Shire. Free measure & quote. Lic #000105713.
```
**Rationale:** 159 characters. Includes all 4 services, brand affiliation (Prowler Proof), location (Sutherland Shire), CTA (Free measure & quote), and trust signal (licence number). [^32^][^37^]

#### Recommended H1:
```
Security Doors and Screens in Sutherland Shire
```

#### Recommended H2 Structure:
```
H1: Security Doors and Screens in Sutherland Shire
H2: Premium Security Solutions for Sutherland Shire Homes
  [Intro paragraph with target keyword in first 100 words]
H2: Our Security Services
  H3: Security Doors
  H3: Security Window Screens
  H3: Plantation Shutters
  H3: Outdoor Blinds
H2: Why Choose Shire Security Doors and Screens
  H3: Prowler Proof Authorised Dealer
  H3: Licensed Security Installer (#000105713)
  H3: Local Family-Owned Business
H2: Sutherland Shire Service Areas
  [List suburbs: Cronulla, Caringbah, Miranda, Gymea, etc.]
H2: Customer Reviews
H2: Frequently Asked Questions
  H3: What areas do you service in Sutherland Shire?
  H3: Are you a licensed security door installer?
  H3: What is a Prowler Proof authorised dealer?
  H3: How much do security doors cost in Sydney?
  H3: Do you offer free quotes and measurements?
H2: Get Your Free Measure and Quote Today
```

#### Recommended Content Expansion:
Expand homepage content from ~150 words to 600-900 words covering:
- Introduction with "Sutherland Shire" and "security doors" in first 100 words
- Service overview with links to each service page
- Trust signals (Prowler Proof, licence, NSSA)
- Service areas with suburb list (links to future suburb pages)
- Brief testimonial section
- FAQ section with 5 questions (40-60 word answers each) [^83^][^85^]

#### Recommended Internal Links:
- Link to each of the 4 service pages from the "Our Security Services" section
- Link to Contact page from CTA sections
- Add contextual links using anchor text like "our security door installation services" [^50^][^46^]

---

### 4.2 Security Doors Service Page Recommendations

#### Current Title Tag:
```
Security Doors Sydney | Shire Security Doors and Screens
```

#### Recommended Title Tag:
```
Security Doors Sutherland Shire & Sydney | Prowler Proof
```
**Rationale:** 59 characters. Targets both primary location (Sutherland Shire) and broader Sydney searches. Includes "Prowler Proof" for brand authority. [^45^][^37^]

#### Recommended Meta Description:
```
Custom hinged & sliding security doors installed across Sutherland Shire. Prowler Proof ForceField, Protec & Diamond options. Free measure & quote. Call today.
```
**Rationale:** 160 characters. Lists door types, includes location, brand, and CTA. [^31^][^32^]

#### Recommended H1:
```
Security Doors in Sutherland Shire
```

#### Recommended H2 Structure:
```
H1: Security Doors in Sutherland Shire
H2: Custom Security Door Solutions for Your Home
  [Intro with "security doors Sutherland Shire" in first 100 words]
H2: Our Security Door Range
  H3: ForceField Stainless Steel Security Doors
  H3: Protec Perforated Aluminium Security Doors
  H3: Sliding Security Doors
  H3: Diamond Design Security Doors
H2: Security Door Hardware and Locking
  H3: Lockwood 8654 and 8653 Locking Systems
  H3: 3-Point Multi-Lock Security
H2: Why Choose Prowler Proof Security Doors
  H3: 316 Marine Grade Stainless Steel
  H3: Hidden Installation Technology (HIT)
  H3: Welded Corner Construction
  H3: Australian Made and Tested
H2: Security Door Installation Process
  H3: Free On-Site Measure and Quote
  H3: Custom Manufacturing to Your Opening
  H3: Professional Installation
H2: Security Doors for Coastal Homes
  [Content about coastal corrosion resistance for Sutherland Shire proximity to ocean]
H2: Service Areas
  [Cronulla, Caringbah, Miranda, Gymea, Sutherland, Menai, Bangor, etc.]
H2: Frequently Asked Questions
  H3: What is the best security door for a beachside home?
  H3: How much does a Prowler Proof security door cost?
  H3: What is the difference between ForceField and Protec?
  H3: Do security doors come with a warranty?
  H3: How long does security door installation take?
  H3: Are your security doors compliant with Australian Standards?
H2: Get a Free Security Door Quote
```

#### Recommended Content Length:
Expand to 1,000-1,200 words of unique, comprehensive content covering all H2/H3 sections. [^126^][^131^]

#### Recommended Alt Text Examples:
```
- "Prowler Proof ForceField stainless steel security door installed on Sutherland Shire home front entry"
- "Sliding security door on patio overlooking Sutherland Shire backyard"
- "Lockwood 3-point lock system on Prowler Proof security door"
- "Hidden Installation Technology security door frame detail"
```

#### Recommended Schema:
- Service schema with serviceType: "Security Door Installation"
- FAQPage schema for the FAQ section
- BreadcrumbList schema
- AggregateRating schema (when reviews available) [^86^][^88^]

---

### 4.3 Window Screens Service Page Recommendations

#### Recommended Title Tag:
```
Security Window Screens Sutherland Shire | Prowler Proof
```
**Rationale:** 60 characters. Clear service + location + brand. [^37^][^45^]

#### Recommended Meta Description:
```
Prowler Proof security window screens for fixed, hinged, sliding & elevated windows across Sutherland Shire. Guardian fall prevention available. Free quote.
```
**Rationale:** 159 characters. Covers all product types, location, brand, and CTA. [^32^][^37^]

#### Recommended H1:
```
Security Window Screens in Sutherland Shire
```

#### Recommended H2 Structure:
```
H1: Security Window Screens in Sutherland Shire
H2: Window Security Without Compromising Airflow
  [Intro with "security screens Sutherland Shire" in first 100 words]
H2: Our Window Screen Options
  H3: Fixed Window Security Screens
  H3: Hinged Window Screens
  H3: Sliding Window Screens
  H3: Guardian Fall Prevention Screens
H2: Why Security Window Screens Matter
  H3: Keep Windows Open Safely
  H3: Protection from Intruders and Insects
  H3: Fall Prevention for Upper Storeys
H2: Prowler Proof Window Screen Features
  H3: 316 Marine Grade Stainless Steel Mesh
  H3: Welded Corner Construction
  H3: Hidden Installation Technology
H2: Window Screen Installation Process
H2: Service Areas Across Sutherland Shire
H2: Frequently Asked Questions
  H3: What is the difference between fixed and hinged window screens?
  H3: Are security window screens strong enough to stop intruders?
  H3: Do you install fall prevention screens for upstairs windows?
  H3: Will security screens block my view?
  H3: How do I clean security window screens?
  H3: What areas in Sutherland Shire do you service?
H2: Request a Free Window Screen Quote
```

#### Recommended Content Length:
Expand to 900-1,100 words. [^130^][^131^]

#### Recommended Internal Links:
- Link to Security Doors page: "Our range of security doors for your entryways"
- Link to Plantation Shutters page: "indoor window treatment options"
- Link to Contact page: "Book your free window screen measure" [^50^][^47^]

---

### 4.4 Plantation Shutters Service Page Recommendations

#### Recommended Title Tag:
```
Plantation Shutters Sutherland Shire | Supply & Install
```
**Rationale:** 56 characters. Service + location + supply/install qualifier. [^45^][^37^]

#### Recommended Meta Description:
```
Custom Thermopoly plantation shutters for windows & doors across Sutherland Shire. Light control, privacy & temperature comfort. Free in-home measure & quote.
```
**Rationale:** 158 characters. Covers material, benefits, services, location, and CTA. [^32^]

#### Recommended H1:
```
Plantation Shutters in Sutherland Shire
```

#### Recommended H2 Structure:
```
H1: Plantation Shutters in Sutherland Shire
H2: Stylish Indoor Shutters for Sutherland Shire Homes
  [Intro with "plantation shutters Sutherland Shire" in first 100 words]
H2: Why Choose Plantation Shutters
  H3: Light Control and Privacy
  H3: Temperature Comfort Year-Round
  H3: Durable and Low Maintenance
  H3: Made to Fit Any Opening
H2: Thermopoly Plantation Shutters
  H3: Reinforced Material for Longevity
  H3: Suitable for Wet Areas
  H3: Easy to Clean and Maintain
H2: Shutter Applications
  H3: Living Room and Bedroom Windows
  H3: Bathroom and Kitchen Shutters
  H3: Bay Windows and Sliding Doors
H2: Our Shutter Installation Process
H2: Plantation Shutters vs Other Window Treatments
H2: Service Areas
H2: Frequently Asked Questions
  H3: What are plantation shutters made of?
  H3: How much do plantation shutters cost in Sydney?
  H3: Are plantation shutters good for insulation?
  H3: Can plantation shutters be installed in bathrooms?
  H3: How long does shutter installation take?
H2: Request Your Free Shutter Quote
```

#### Recommended Content Length:
Expand to 800-1,000 words. [^130^][^131^]

---

### 4.5 Outdoor Blinds Service Page Recommendations

#### Recommended Title Tag:
```
Outdoor Blinds Sutherland Shire & Sydney | Supply & Install
```
**Rationale:** 60 characters. Service + dual location targeting + qualifier. [^37^][^45^]

#### Recommended Meta Description:
```
Premium outdoor blinds for patios, alfresco areas & balconies across Sutherland Shire. Weather protection with style. Free on-site measure & quote available.
```
**Rationale:** 158 characters. Application-focused, location-specific, includes CTA. [^32^][^37^]

#### Recommended H1:
```
Outdoor Blinds in Sutherland Shire
```

#### Recommended H2 Structure:
```
H1: Outdoor Blinds in Sutherland Shire
H2: Transform Your Outdoor Living Space
  [Intro with "outdoor blinds Sutherland Shire" in first 100 words]
H2: Outdoor Blind Options
  H3: Patio and Alfresco Blinds
  H3: Balcony Outdoor Blinds
  H3: Ziptrak and Track-Guided Systems
  H3: Motorised Outdoor Blinds
H2: Benefits of Outdoor Blinds
  H3: Weather and UV Protection
  H3: Privacy from Neighbours
  H3: Extend Your Living Space
  H3: Energy Efficiency
H2: Outdoor Blinds for Coastal Conditions
  [Specific content about Sutherland Shire coastal conditions and material durability]
H2: Custom Measurement and Installation
H2: Service Areas Across Sutherland Shire
H2: Frequently Asked Questions
  H3: What types of outdoor blinds do you offer?
  H3: How much do outdoor blinds cost in Sydney?
  H3: Are outdoor blinds weatherproof?
  H3: Do you offer motorised outdoor blinds?
  H3: How long does outdoor blind installation take?
H2: Get Your Free Outdoor Blinds Quote
```

#### Recommended Content Length:
Expand to 800-1,000 words. [^130^][^131^]

---

### 4.6 Contact Page Recommendations

#### Recommended Title Tag:
```
Contact Us | Security Door Installer Sutherland Shire
```
**Rationale:** 55 characters. Contact intent + service + location. [^37^][^45^]

#### Recommended Meta Description:
```
Contact Shire Security Doors for a free measure & quote across Sutherland Shire. Licensed installer. Prowler Proof authorised dealer. Call or enquire online.
```
**Rationale:** 160 characters. CTA-focused with trust signals. [^32^][^37^]

#### Recommended H1:
```
Contact Shire Security Doors and Screens
```

#### Required Elements:
- Full NAP (Name, Address, Phone) in Schema markup
- Embedded Google Map linked to GBP
- Contact form with service selection dropdown
- Licence number: #000105713
- Business hours
- Service area list
- LocalBusiness JSON-LD schema [^88^][^86^]

---

## 5. Implementation Priority Matrix

### Critical (Week 1-2) - Quick Wins
| Priority | Action | Impact | Effort |
|----------|--------|--------|--------|
| 1 | Update all title tags to include location keywords front-loaded | High | Low |
| 2 | Write unique meta descriptions for all 6 pages | High | Low |
| 3 | Update H1 tags to include "{Service} in Sutherland Shire" | High | Low |
| 4 | Add LocalBusiness schema to homepage and Contact page | High | Medium |
| 5 | Add Service schema to all 4 service pages | High | Medium |
| 6 | Add FAQPage schema to service pages with FAQ sections | High | Low |

### High Priority (Week 3-4) - Content Expansion
| Priority | Action | Impact | Effort |
|----------|--------|--------|--------|
| 7 | Expand homepage content to 600-900 words | High | Medium |
| 8 | Expand Security Doors page to 1,000+ words | High | Medium |
| 9 | Add FAQ sections (5-8 Q&As) to all service pages | High | Medium |
| 10 | Add alt text to all images (5-15 words, descriptive) | Medium | Low |
| 11 | Add internal links between service pages | Medium | Low |
| 12 | Embed Google Map on Contact page | Medium | Low |

### Medium Priority (Month 2) - Advanced Optimization
| Priority | Action | Impact | Effort |
|----------|--------|--------|--------|
| 13 | Add BreadcrumbList schema globally | Medium | Low |
| 14 | Create suburb-specific content sections | Medium | High |
| 15 | Add review/testimonial sections to service pages | Medium | Medium |
| 16 | Implement Speakable schema for voice search | Medium | Low |
| 17 | Add HowTo schema for installation process content | Medium | Medium |
| 18 | Create image sitemap for all product images | Low | Medium |

---

## 6. References

| Citation | Source | URL | Date |
|----------|--------|-----|------|
| [^31^] | SeekLab - SEO Title Tags & Meta Descriptions Best Practices 2026 | https://seeklab.io/blog/on-page-seo-titles-metas-structure/ | 2026-06-03 |
| [^32^] | TerraHQ - Essential Local SEO Checklist 2026 | https://terrahq.com/en/blog/optimizing-local-seo-the-2024-8-step-checklist/ | 2026-06-08 |
| [^33^] | SEO Team Toronto - Header Structure Best Practices | https://www.seoteamtoronto.ca/blog/header-structure-best-practices-h1-h2-h3 | 2026-02-03 |
| [^34^] | Search Atlas - Keyword Density 2025 | https://searchatlas.com/blog/keyword-density/ | 2026-01-26 |
| [^35^] | Post Affiliate Pro - Optimal Keyword Density 2025 | https://www.postaffiliatepro.com/faq/optimal-keyword-density/ | 2025-11-28 |
| [^36^] | BIANYS - Mastering Precise Keyword Placement 2025 | https://www.bianys.com/mastering-precise-keyword-placement-for-superior-seo-rankings-an-in-depth-practical-guide-2025/ | 2025 |
| [^37^] | Arc4 - Complete Guide to Boost Local SEO Rankings 2026 | https://arc4.com/local-landing-pages/ | 2025-11-13 |
| [^38^] | Armour Corporation - Keyword Placement Strategies | https://armourcorporation.com/mastering-precise-keyword-placement-for-superior-on-page-seo-techniques-strategies-and-deep-implementation/ | 2025-11-05 |
| [^39^] | Medium - Beginner's Guide to On-Page SEO 2025 | https://medium.com/@VivekDM40/the-ultimate-beginners-guide-to-on-page-seo-in-2025-10-techniques-every-new-blogger-must-master-654977e9fe7f | 2025-10-20 |
| [^40^] | Great Bay College - Website Style Guide SEO | https://mygbcc.greatbay.edu/wp-content/uploads/2024/01/ccsnh-style-guide.pdf | N/A |
| [^41^] | BrandLume - Keyword Density in 2025 | https://brandlume.com/keyword-density-does-still-matter-seo/ | 2025-05-23 |
| [^42^] | DevTrios - H1 Tag Best Practices 2026 | https://devtrios.com/blog/h1-tag-best-practices/ | 2026-03-01 |
| [^43^] | Knapsack Creative - Local SEO Tips 2026 | https://knapsackcreative.com/blog/seo/how-local-seo-is-powering-growth-for-service-based-business | 2026-02-08 |
| [^44^] | Hobo Web - HTML Headings for SEO | https://www.hobo-web.co.uk/headings-seo-checklist/ | 2025-09-30 |
| [^45^] | Best Version Media - Location-Based Page Titles | https://www.bestversionmedia.com/location-based-page-titles-explained-a-practical-strategy-to-boost-local-seo/ | 2025-10-22 |
| [^46^] | Ava Abrazzaq - Internal Linking for Local Businesses | https://avaabrazzaq.com/insights/seo/internal-linking-strategy-local-businesses/ | 2026-06-01 |
| [^47^] | Stackra - Internal Linking for Small Business | https://stackra.app/blog/internal-linking-strategy-small-business/ | 2026-06-01 |
| [^48^] | SEO-Day - Alt Tags Best Practices 2025 | https://www.seo-day.de/wiki/on-page-seo/bilder-seo/alt-tags.php?lang=en | 2026-04-01 |
| [^49^] | Straight North - SEO-Friendly URLs | https://www.straightnorth.com/blog/how-to-create-seo-friendly-urls-structure-length-and-optimization-tips/ | 2026-06-15 |
| [^50^] | PWD Digital Agency - Internal Linking Guide (Australia) | https://pwd.com.au/blog/internal-linking-for-seo/ | 2026-04-07 |
| [^51^] | Marketeam Australia - Alt Text SEO Guide | https://marketeam.com.au/resources/articles/seo/alt-text-seo-everything-you-need-to-know | 2025-09-21 |
| [^52^] | Amsive - Alt Text for SEO Guidelines | https://www.amsive.com/insights/seo/alt-text-to-supercharge-discoverability-seo-guidelines-for-smarter-image-optimization/ | 2025-12-22 |
| [^53^] | Richwood Marketing - Internal Linking Strategy | https://richwoodmarketing.com/blog/internal-linking-seo-strategy-tips/ | N/A |
| [^54^] | Lachimedia - Internal Linking for Local SEO | https://lachimedia.com/blog/seo/simple-internal-linking-strategies-to-boost-local-seo/ | N/A |
| [^55^] | Octaria - SEO-Friendly URL Structure 2025 | https://www.octaria.com/blog/seo-friendly-url-structure-best-practices-2025 | N/A |
| [^78^] | SEONinja - Near Me SEO Optimization | https://www.seoninja.com/blog/seo/near-me-seo-local-search-optimization/ | 2026-04-23 |
| [^79^] | Precision Marketing Partners - Local SEO Strategies | https://precisionmarketingpartners.com/effective-local-seo-strategies-for-small-businesses-today/ | 2026-04-17 |
| [^80^] | SOCi - How to Rank for Near Me Searches | https://www.soci.ai/blog/seo-near-me/ | 2026-05-12 |
| [^81^] | Design in DC - Voice Search Optimization 2025 | https://designindc.com/blog/how-to-optimize-your-website-for-voice-search-in-2025/ | 2025 |
| [^82^] | Zensciences - Local SEO 2025 | https://zensciences.com/blogs/local-search-optimization-how-do-you-actually-improve-your-local-seo-rankings-today/ | 2025-12-23 |
| [^83^] | DevExHub - Featured Snippets Optimization 2025 | https://devexhub.com/blog/zero-click-seo-in-2025-how-to-optimize-for-google-s-featured-snippets | 2025 |
| [^84^] | SocioLabs - Voice Search SEO 2025 | https://sociolabs.in/voice-search-optimization-seo-2025/ | 2026-02-18 |
| [^85^] | Graphicwise - Voice Search Local SEO Tips | https://graphicwise.com/voice-search-local-seo/ | 2025-08-28 |
| [^86^] | PushLeads - Local Schema Markup Guide | https://pushleads.com/seo-timeline/complete-guide-to-local-schema-markup-implementation/ | 2025-11-09 |
| [^87^] | GetPin - Google Business Profile Optimization | https://getpin.com/google-business-profile-en/guide-google-business-profile-optimization-2025/ | 2025-12-29 |
| [^88^] | EseoSpace - Schema Markup for Small Business | https://eseospace.com/blog/schema-markup-for-small-business-websites/ | 2025-08-20 |
| [^89^] | Deborah.ba - Voice Search for Local Businesses | https://deborah.ba/voice-search-optimization-for-local-businesses/ | 2025-06-04 |
| [^90^] | BTWeb Group - Voice Search SEO Strategies | https://btwebgroup.com/blog/preparing-for-the-voice-search-revolution-seo-strategies-for-2025 | 2025-05-13 |
| [^125^] | Netstripes - SEO Guide for Australian Businesses | https://netstripes.com/blog/a-complete-seo-guide-for-businesses-in-australia/ | 2026-06-10 |
| [^126^] | Accentuate Agency - Word Count for SEO | https://www.accentuate.agency/word-count-for-seo/ | 2025-09-10 |
| [^127^] | Yostrato - SEO Best Practices Local Business | https://yostrato.com/seo/seo-best-practices/ | 2025-09-11 |
| [^128^] | SurferSEO - Word Count Doesn't Matter for SEO | https://surferseo.com/blog/word-count-does-not-matter-for-seo/ | 2025-08-14 |
| [^129^] | ClickRank - Ideal Content Length for SEO | https://www.clickrank.ai/ideal-content-length-for-seo/ | 2025-12-30 |
| [^130^] | Yoast - Word Count and SEO | https://yoast.com/blog-post-word-count-seo/ | 2025-12-22 |
| [^131^] | SEMrush - Best Content Length for SEO | https://www.semrush.com/blog/what-is-the-best-content-length-for-seo/ | 2025-09-16 |
| [^132^] | Click Intelligence - Ideal Blog Post Length 2025 | https://www.clickintelligence.co.uk/content-length-whats-the-ideal-length-of-a-blog-post-for-seo-in-2025/ | 2025-01-03 |
| [^133^] | HiAgency - Best Local Directories Australia | https://hiagency.au/local-seo/best-local-directories-for-seo/ | 2026-03-05 |
| [^134^] | Birdeye - SEO for Small Business Australia | https://birdeye.com/blog/seo-for-small-business-australia/ | 2025-07-01 |
| [^135^] | PageOptimizer Pro - SEO Content Word Count | https://www.pageoptimizer.pro/blog/how-long-should-seo-content-be-finding-the-ideal-word-count-for-ranking-success | 2024-12-17 |
| [^136^] | Search Engine Land - Content Length and SEO | https://searchengineland.com/content-length-depth-and-seo-everything-you-need-to-know-in-2025-447197 | 2024-10-03 |
| [^137^] | Prowler Proof Official Website | https://prowlerproof.com.au/ | 2025-10-14 |
| [^138^] | Gordon Digital - Local SEO Ultimate Guide 2025 (Australia) | https://gordondigital.com.au/knowledge-centre/local-seo-ultimate-guide-2025/ | 2026-03-23 |

---

*Report compiled from 18+ web searches covering title tags, meta descriptions, heading structures, keyword optimization, content length, image alt text, internal linking, URL structure, near-me optimization, schema markup, featured snippets, and voice search. All findings include inline citations with source URLs and publication dates.*
