# SEO Project Requirements Analysis
## Shire Security Doors and Screens — Sutherland Shire, Sydney
### Website: https://shire-security-doors-demo.vercel.app/

---

## 1. EXPLICIT REQUIREMENTS (Directly Stated by User)

### REQ-001: Comprehensive SEO Report
- **Description**: Create a detailed SEO report ready to hand off to an AI agent for execution
- **Priority**: P0 — Critical
- **Details**: The report must contain all required instructions, research findings, keyword targets, and action items needed for the AI agent to execute the SEO strategy independently

### REQ-002: Content Page Creation (Keyword-Optimized)
- **Description**: Create any content pages suggested by the SEO research, fully optimized for target keywords
- **Priority**: P0 — Critical
- **Details**: Content must be ready to publish — not just recommendations. Must include proper keyword targeting, on-page SEO, and alignment with user search intent

### REQ-003: Generative Engine Optimization (GEO) Research & Implementation
- **Description**: Research and implement what is needed to rank in AI search tools (ChatGPT, Perplexity, Google AI Overviews, Gemini, Claude)
- **Priority**: P0 — Critical
- **Details**: User specifically referenced "GEO" — Generative Engine Optimization — as a distinct discipline from traditional SEO. Must cover both technical GEO signals and content structuring for AI citation

### REQ-004: Rankings That Actually Convert
- **Description**: The strategy must produce actual ranking results, not just theoretical recommendations
- **Priority**: P0 — Critical
- **Details**: User's language ("actually start ranking") indicates prior failed SEO efforts. Needs measurable, tangible ranking improvements in both traditional Google and AI search environments

### REQ-005: AI-Agent-Ready Deliverable Format
- **Description**: All deliverables must be structured so an AI agent can consume and execute them without human interpretation
- **Priority**: P1 — High
- **Details**: The report is not for human reading — it is the instruction set for an AI agent. Requires precise, structured, actionable format with clear priorities and dependencies

---

## 2. IMPLICIT REQUIREMENTS (Inferred from Context)

### REQ-101: Local SEO Dominance (Sutherland Shire + Surrounds)
- **Priority**: P0 — Critical
- **Evidence**: Business is explicitly local ("Sutherland Shire"), has suburb service pages (350+ suburbs listed), family-owned local identity is central to branding
- **Requirements**:
  - Target "[service] + [suburb]" keyword combinations across all 350+ service areas
  - Google Business Profile optimization
  - Local pack ranking strategy
  - NAP (Name, Address, Phone) consistency across all mentions
  - Local backlink building (Shire directories, community sites, local publications)
  - Review generation strategy for Google and local platforms

### REQ-102: Multi-Product Service Coverage
- **Priority**: P0 — Critical
- **Evidence**: Website has 5 distinct product categories: Security Doors, Security Screens/Windows, Plantation Shutters, Outdoor Blinds, Fly Screens
- **Requirements**:
  - Each product line needs its own keyword cluster and content strategy
  - Cross-selling content that positions the business as a one-stop installer
  - Product comparison content (e.g., ForceField vs Crimsafe already exists — more needed)

### REQ-103: Prowler Proof Brand Authority & Dealer SEO
- **Priority**: P1 — High
- **Evidence**: Business is an "Authorised Prowler Proof Dealer" — this is a key trust signal prominently displayed
- **Requirements**:
  - Rank for "Prowler Proof" branded + location queries
  - Content that reinforces authorised dealer status
  - Compete against other Prowler Proof dealers in Sydney area
  - Product-specific content for ForceField, Protec, Guardian, Diamond lines

### REQ-104: E-E-A-T Signal Strengthening
- **Priority**: P1 — High
- **Evidence**: Master Security Licence #000105713, NSSA Member, Prowler Proof Authorised Dealer — these are credibility signals that must be amplified
- **Requirements**:
  - Author bylines with credentials (Steve as the owner/expert)
  - Author bio pages with security industry credentials
  - Schema markup for Person, Organization, Review, LocalBusiness
  - Trust signals prominently displayed on all pages
  - Case studies with real customer names/photos

### REQ-105: Competitive Differentiation (vs Crimsafe & Generic Installers)
- **Priority**: P1 — High
- **Evidence**: Website already has a ForceField vs Crimsafe comparison page — competitive positioning is a strategic priority
- **Requirements**:
  - Comparison content against major competitors (Crimsafe, Jim's Security Doors, generic installers)
  - Content highlighting differentiators: 316 marine grade steel, Hidden Installation Technology, local family-owned service, welded vs screw-clamp construction
  - Competitive keyword targeting (e.g., "better than crimsafe", "crimsafe alternative sutherland shire")

### REQ-106: Conversion-Optimized Content Structure
- **Priority**: P1 — High
- **Evidence**: Website has strong CTAs ("Call Now", "Free Measure & Quote"), phone number prominent, conversion-focused copy throughout
- **Requirements**:
  - Every content page must have clear conversion paths
  - Phone number (0410 474 256) and email (steve@shiredoors.com.au) prominently featured
  - Content that pre-qualifies leads and moves them toward quote/booking
  - FAQ content that overcomes objections before the call

### REQ-107: Technical SEO Foundation
- **Priority**: P1 — High
- **Evidence**: Website is on Vercel (good for speed), modern build, but requires technical audit for full SEO readiness
- **Requirements**:
  - Core Web Vitals optimization (LCP < 2.5s, INP < 200ms, CLS < 0.1)
  - Schema markup (LocalBusiness, Service, FAQPage, Article, HowTo, BreadcrumbList)
  - XML sitemap optimization
  - Robots.txt optimization (ensure AI crawlers NOT blocked — GPTBot, ClaudeBot, PerplexityBot)
  - Mobile-first optimization
  - Internal linking structure improvement
  - URL structure optimization

### REQ-108: Content Freshness & Update Cadence
- **Priority**: P2 — Medium
- **Evidence**: Blog already has 10+ guides covering products, pricing, standards — content exists but needs ongoing freshness
- **Requirements**:
  - Quarterly content refresh plan
  - "Last Updated" timestamps on all content
  - Annual statistics and data refresh cycle
  - Seasonal content calendar (summer security prep, winter maintenance, etc.)

### REQ-109: Voice Search Optimization
- **Priority**: P2 — Medium
- **Evidence**: Voice search accounts for ~30% of AI answer engine interactions; AI search is inherently conversational
- **Requirements**:
  - Conversational heading structures (questions people actually ask)
  - Q&A format throughout content
  - Short sentence length for extracted answers (< 20 words)
  - SpeakableSpecification schema markup

### REQ-110: llms.txt & AI Crawler Accessibility
- **Priority**: P1 — High
- **Evidence**: GEO best practices for 2026 require explicit AI accessibility
- **Requirements**:
  - Create `/llms.txt` file at root domain guiding AI crawlers to priority content
  - Verify `robots.txt` does not block GPTBot, ClaudeBot, PerplexityBot, ChatGPT-User
  - Ensure content is server-side rendered (not hidden behind JavaScript)
  - Check Cloudflare settings don't auto-block AI crawlers

### REQ-111: Third-Party Entity Building
- **Priority**: P2 — Medium
- **Evidence**: AI citation confidence depends on brand mentions across independent credible sources
- **Requirements**:
  - Google Business Profile optimization and review generation
  - Presence on local directories (TrueLocal, Yelp, Word of Mouth, Hipages)
  - Industry directory listings (NSSA, security trade bodies)
  - LinkedIn presence for Steve (owner)
  - Reddit/forum participation in local community discussions
  - Press mentions in local Sutherland Shire publications

### REQ-112: FAQ & Answer-First Content Architecture
- **Priority**: P1 — High
- **Evidence**: AI search engines extract direct answers; FAQ schema is disproportionately powerful for GEO
- **Requirements**:
  - Answer-first structure: direct answer in first 2-3 sentences of every page
  - FAQ sections (minimum 6 questions) on every service page
  - FAQPage schema markup on all FAQ sections
  - Atomic Answers: standalone 40-60 word paragraphs AI can cite directly
  - Question-based H2/H3 headers mirroring actual search queries

### REQ-113: Schema Markup Stack (Triple Schema)
- **Priority**: P1 — High
- **Evidence**: Stacking FAQPage + Article + HowTo schema using JSON-LD @graph format is a 2026 GEO best practice
- **Requirements**:
  - FAQPage schema on all FAQ sections
  - Article schema on all blog/guides content (with author, datePublished, dateModified)
  - HowTo schema on process content (installation, measuring, choosing products)
  - LocalBusiness schema with full details
  - Service schema for each product category
  - BreadcrumbList schema sitewide
  - Review schema for testimonials

### REQ-114: Topic Cluster Architecture
- **Priority**: P1 — High
- **Evidence**: AI systems break complex queries into sub-queries; comprehensive topic coverage builds topical authority
- **Requirements**:
  - Pillar pages for each product category
  - Cluster content covering every sub-question for each product
  - Internal linking between pillar and cluster content
  - Complete coverage of: security door types, materials, standards, pricing, installation process, maintenance, comparison with alternatives

---

## 3. DELIVERABLES EXPECTED

### DEL-001: Comprehensive SEO/GEO Audit Report
- **Format**: Structured markdown document ready for AI agent consumption
- **Contents**:
  - Current website SEO health score
  - Technical SEO audit findings
  - Keyword research and opportunity analysis
  - Competitor analysis (traditional + AI search)
  - Content gap analysis
  - GEO readiness assessment
  - Prioritized action plan with dependencies

### DEL-002: Keyword Strategy Document
- **Format**: Structured spreadsheet + narrative document
- **Contents**:
  - Primary keywords (high volume, commercial intent)
  - Secondary keywords (long-tail, informational)
  - Local keywords (service + suburb combinations)
  - GEO/conversational keywords (question-based, AI-search optimized)
  - Branded keywords (Prowler Proof + location)
  - Competitive keywords (vs Crimsafe, vs generic installers)
  - Search volume, difficulty, intent classification for each
  - Keyword-to-page mapping

### DEL-003: Content Calendar & Production Plan
- **Format**: Structured document with templates
- **Contents**:
  - New content pages to create (full list with specifications)
  - Existing content to optimize (prioritized list)
  - Content templates (service page, blog post, comparison page, suburb page, FAQ page)
  - Publishing schedule with priorities
  - Content briefs for each new page (keyword targets, structure, schema, internal links)

### DEL-004: Ready-to-Publish Content Pages (Keyword-Optimized)
- **Format**: Markdown/HTML with schema markup, meta tags, internal links
- **Contents** (suggested based on analysis):
  - Service-specific landing pages for each of 5 product categories
  - Suburb-specific service pages (top 20 priority suburbs)
  - Comparison pages (vs Crimsafe, vs Jim's, vs DIY)
  - "How to choose" buyer guides
  - FAQ pages for each product line
  - Pricing/content pages targeting cost-related queries
  - Coastal/salt-air specific content (differentiator)
  - Installation process content
  - Maintenance/care guides
  - Standards/compliance guides (AS 5039)

### DEL-005: GEO Implementation Guide
- **Format**: Technical document for AI agent
- **Contents**:
  - llms.txt file content
  - robots.txt configuration for AI crawlers
  - Schema markup specifications (JSON-LD @graph)
  - Answer-first content structure templates
  - FAQ section specifications
  - Author attribution structure
  - Content freshness protocol
  - AI crawler monitoring setup

### DEL-006: Technical SEO Implementation Guide
- **Format**: Technical specification document
- **Contents**:
  - Core Web Vitals optimization checklist
  - Schema markup implementation guide
  - Internal linking architecture recommendations
  - XML sitemap optimization
  - URL structure recommendations
  - Mobile optimization checklist
  - Image optimization guidelines
  - Page speed improvement plan

### DEL-007: Local SEO Playbook
- **Format**: Action-oriented document for AI agent
- **Contents**:
  - Google Business Profile optimization steps
  - Local citation building list (directories, platforms)
  - Review generation strategy and templates
  - Suburb page creation workflow (350+ suburbs)
  - Local backlink opportunities
  - NAP consistency audit and fix plan

### DEL-008: E-E-A-T & Authority Building Plan
- **Format**: Strategic document with tactical steps
- **Contents**:
  - Author profile setup (Steve as security expert)
  - Organization schema implementation
  - Trust signal placement strategy
  - Third-party citation building plan
  - Case study collection workflow
  - Industry credential display optimization

---

## 4. SUCCESS CRITERIA

### Traditional SEO Metrics (KPIs)
| Metric | Baseline | 90-Day Target | 180-Day Target |
|--------|----------|--------------|----------------|
| Organic traffic (monthly) | TBD (measure baseline) | +50% | +150% |
| Keywords ranking in top 10 | TBD | +30 new keywords | +80 new keywords |
| Keywords ranking in top 3 | TBD | +10 new keywords | +30 new keywords |
| Local pack appearances | TBD | Top 3 for 20+ suburbs | Top 3 for 50+ suburbs |
| Google Business Profile views/actions | TBD | +100% | +300% |
| Core Web Vitals score | TBD | All "Good" | Maintain "Good" |

### GEO Metrics (AI Search Visibility KPIs)
| Metric | Baseline | 90-Day Target | 180-Day Target |
|--------|----------|--------------|----------------|
| AI citation rate (brand mentions in AI answers) | 0 | Cited for 10+ prompts | Cited for 30+ prompts |
| Share of Synthesis (brand appearance in AI responses) | 0% | 10% for core queries | 25% for core queries |
| AI referral traffic (from Perplexity, ChatGPT, etc.) | TBD | +50 clicks/month | +200 clicks/month |
| Brand search volume increase | TBD | +25% | +75% |
| Direct answer inclusion (Google AI Overviews) | None | Featured for 5+ queries | Featured for 15+ queries |

### Conversion Metrics
| Metric | Baseline | 90-Day Target | 180-Day Target |
|--------|----------|--------------|----------------|
| Quote requests (form submissions) | TBD | +30% | +80% |
| Phone calls from website | TBD | +30% | +80% |
| Contact page visits | TBD | +50% | +150% |

### Content Deliverables
| Metric | Target |
|--------|--------|
| New content pages published | 25+ in first 90 days |
| Existing pages optimized | All 20+ existing pages |
| Suburb pages created/live | Top 50 priority suburbs |
| Blog posts published | 12+ in first 90 days |
| FAQ sections added | All service pages + 10+ dedicated |
| Schema markup coverage | 100% of pages |

---

## 5. CONSTRAINTS & LIMITATIONS

### C-001: Local Market Scope
- **Constraint**: Business serves Sutherland Shire and surrounding Sydney areas only — cannot target national/international keywords
- **Impact**: Keyword volume limited by local search volume; must maximize long-tail local combinations

### C-002: Vercel Hosting Platform
- **Constraint**: Website hosted on Vercel — server configuration may be limited
- **Impact**: Server-side rendering, edge caching, and some technical optimizations may require Vercel-specific approaches

### C-003: Single Business Owner (Steve)
- **Constraint**: Steve is the primary contact/installer — limited time for content approvals, review responses, interview participation
- **Impact**: Content creation must be efficient; review generation strategy must be automated/streamlined; author content must work with limited Steve availability

### C-004: Family-Owned Budget Realities
- **Constraint**: Likely limited marketing budget — must prioritize highest-impact, lowest-cost tactics
- **Impact**: Focus on content SEO, local SEO, and GEO (low-cost, high-return) over paid strategies; prioritize quick wins

### C-005: Prowler Proof Brand Restrictions
- **Constraint**: As an authorised dealer, must comply with Prowler Proof brand guidelines and may have limited flexibility in product claims
- **Impact**: Content must be accurate to Prowler Proof specifications; cannot make unapproved comparative claims

### C-006: AI Agent Execution Model
- **Constraint**: Report will be executed by an AI agent — cannot rely on human judgment calls or subjective assessments
- **Impact**: All instructions must be unambiguous, with clear criteria for decisions; templates must be fill-in-the-blank; no "use your best judgment" instructions

### C-007: Competitive Market (Sydney Security)
- **Constraint**: Sydney security door market is competitive with established players (Crimsafe, Jim's Security Doors, national brands)
- **Impact**: Differentiation must be clear and consistent; cannot compete on brand recognition alone

### C-008: No Physical Storefront (Service-Based)
- **Constraint**: Appears to be mobile/installation-only service (no showroom address visible)
- **Impact**: Local SEO may be challenged without physical address; must optimize around service-area model

### C-009: New/Low-Traffic Domain
- **Constraint**: `shire-security-doors-demo.vercel.app` is on a demo subdomain — may need migration to production domain
- **Impact**: Current domain may not be the final live domain; SEO strategy must account for potential domain migration

---

## 6. TARGET AUDIENCE (The AI Agent Executor)

### Primary Consumer: AI Agent
- **Role**: The user's AI agent will read this report and execute all recommendations automatically
- **Capabilities**: Can read structured documents, follow precise instructions, generate content, implement technical changes
- **Limitations**: Cannot make subjective judgments, cannot access external accounts without credentials, cannot perform physical actions (like calling directories)

### Secondary Consumer: Business Owner (Steve)
- **Role**: Reviews high-level strategy, provides business context, approves content direction
- **Needs**: Clear, non-technical overview of what will be done and expected results

### Tertiary Consumer: Future Human SEO Manager
- **Role**: May take over strategy execution from the AI agent
- **Needs**: Documented rationale, clear audit trail, transferable knowledge

### Document Design Implications
- Every instruction must be: Specific, Measurable, Actionable, Relevant, Time-bound (SMART)
- Use structured formats (tables, checklists, templates) over narrative prose
- Include explicit prioritization (P0/P1/P2) so AI agent knows execution order
- Provide fallback/alternative approaches where decisions depend on external factors
- Include validation criteria so AI agent can confirm completion of each task

---

## 7. PRIORITY RANKING OF REQUIREMENTS

### P0 — CRITICAL (Must have, immediate execution)
| ID | Requirement | Rationale |
|----|-------------|-----------|
| REQ-001 | Comprehensive SEO report for AI agent | Core deliverable; everything else flows from this |
| REQ-002 | Keyword-optimized content pages | Directly drives rankings and traffic |
| REQ-003 | GEO research & implementation | Explicitly requested; competitive necessity |
| REQ-004 | Actual ranking results | User's stated goal — must deliver measurable outcomes |
| REQ-101 | Local SEO (Sutherland Shire + suburbs) | Business model is hyper-local; primary revenue driver |
| REQ-102 | Multi-product service coverage | 5 product lines each represent ranking opportunities |

### P1 — HIGH (Essential for success, execute after P0)
| ID | Requirement | Rationale |
|----|-------------|-----------|
| REQ-005 | AI-agent-ready deliverable format | Enables efficient execution |
| REQ-103 | Prowler Proof brand authority | Key differentiator and branded search volume |
| REQ-104 | E-E-A-T signal strengthening | Required for both SEO and GEO success |
| REQ-105 | Competitive differentiation | Market is competitive; must stand out |
| REQ-106 | Conversion-optimized content | Traffic without conversions is worthless |
| REQ-107 | Technical SEO foundation | Enables all other SEO efforts |
| REQ-110 | llms.txt & AI crawler accessibility | Prerequisite for GEO citations |
| REQ-112 | FAQ & answer-first architecture | Directly impacts AI citation rates |
| REQ-113 | Schema markup stack | Technical requirement for GEO |
| REQ-114 | Topic cluster architecture | Builds topical authority for AI systems |

### P2 — MEDIUM (Important, execute when P0/P1 complete)
| ID | Requirement | Rationale |
|----|-------------|-----------|
| REQ-108 | Content freshness & update cadence | Long-term maintenance; less urgent than creation |
| REQ-109 | Voice search optimization | Emerging channel; lower volume currently |
| REQ-111 | Third-party entity building | Builds authority but takes time to develop |

### P3 — LOW (Nice to have, future phase)
| ID | Requirement | Rationale |
|----|-------------|-----------|
| — | Advanced link building campaigns | Requires budget and relationships |
| — | Video content optimization | High effort; lower immediate priority |
| — | International SEO expansion | Outside business scope |
| — | Paid search integration | User asked for SEO, not SEM |

---

## 8. EXECUTION PHASES (Recommended)

### Phase 1: Foundation (Weeks 1-2) — All P0 items
- Technical SEO audit and fixes
- Baseline measurement setup
- Keyword research and mapping
- llms.txt and robots.txt configuration
- Schema markup implementation
- Google Business Profile optimization

### Phase 2: Content Creation (Weeks 3-8) — P0 + P1 content items
- Service page optimization (5 categories)
- Top suburb page creation (50 priority suburbs)
- Blog content production (12+ posts)
- FAQ sections on all service pages
- Comparison and buyer guide content
- Author profile and E-E-A-T setup

### Phase 3: GEO Optimization (Weeks 6-10) — P1 GEO items
- Answer-first restructuring of all content
- FAQPage + Article + HowTo schema stacking
- Conversational query optimization
- Content freshness protocol activation
- AI crawler monitoring setup

### Phase 4: Authority Building (Weeks 8-16) — P1 + P2 items
- Third-party directory submissions
- Local citation building
- Review generation campaign
- Entity building on LinkedIn, forums
- Content update cycle (quarterly)

### Phase 5: Measurement & Iteration (Ongoing)
- Weekly ranking tracking
- Monthly AI citation monitoring
- Quarterly content refresh
- Continuous GEO optimization

---

## 9. KEY ASSUMPTIONS

1. The current website (demo subdomain) will either become the live site or the SEO strategy will be transferred to a production domain
2. Steve (the business owner) is willing to provide input for content accuracy but has limited time
3. The business has a valid Google Business Profile that can be optimized
4. Content will be published with approval but the AI agent has authority to create and optimize
5. The competitive landscape remains stable during the execution period
6. Budget constraints favor organic/content strategies over paid tactics

---

*Document prepared for: Shire Security Doors and Screens*
*Target executor: AI Agent*
*Date: Current session*
*Website: https://shire-security-doors-demo.vercel.app/*
