# Shire Security Doors — Comprehensive SEO & GEO Strategy Plan

## Project Overview
Full SEO audit, Generative Engine Optimization (GEO) research, keyword-optimized content creation, and an AI-agent-ready SEO report for https://shire-security-doors-demo.vercel.app/

## Website Inventory (Current State)
| Page | URL | Notes |
|------|-----|-------|
| Homepage | `/` | Good structure, needs SEO optimization |
| Security Doors | `/services/security-doors` | Thin content, needs expansion |
| Window Screens | `/services/security-screens` | Thin content |
| Plantation Shutters | `/services/plantation-shutters` | Thin content |
| Outdoor Blinds | `/services/outdoor-blinds` | Thin content |
| Contact | `/contact` | Good conversion page |
| Footer links | (not actual pages) | Service areas, Security guides, FAQ, Pricing guide, ForceField vs Crimsafe |

## Stages

### Stage 1: Deep Research (deep-research-swarm skill)
**Goal**: Research everything needed for a comprehensive SEO & GEO strategy

**Dimensions**:
1. Technical SEO audit requirements & best practices 2025-2026
2. Local SEO for Australian trades/home services (Sutherland Shire)
3. Keyword research for security doors, screens, shutters, blinds (Australia)
4. Generative Engine Optimization (GEO) — how to rank in AI search (ChatGPT, Gemini, Perplexity, Copilot)
5. Competitor analysis — top-ranking security door companies in Sydney
6. Content gap analysis — what pages/content are missing
7. Prowler Proof product SEO & brand comparison content
8. E-E-A-T signals for local trades businesses
9. Schema markup & structured data for local business
10. Conversion rate optimization for tradesperson websites

**Route**: Route B (Focused Search) — specific question with clear dimensions

### Stage 2: SEO Report Writing (report-writing skill)
**Goal**: Produce comprehensive SEO report ready for AI agent execution
- Technical audit findings
- Keyword research results
- Content strategy & page recommendations
- GEO optimization tactics
- Implementation roadmap

### Stage 3: Content Creation (report-writing skill)
**Goal**: Create keyword-optimized content pages for suggested new pages:
- Service area pages (key suburbs)
- FAQ page
- Security guides content
- ForceField vs Crimsafe comparison
- Pricing guide
- Individual product pages

### Stage 4: Assembly & Delivery
- Final SEO report in .docx format
- All content pages as individual .docx files
- Implementation checklist for AI agent
