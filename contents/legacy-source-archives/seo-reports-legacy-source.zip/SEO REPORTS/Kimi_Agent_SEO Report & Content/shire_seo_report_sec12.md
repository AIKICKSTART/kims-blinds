## 12. Implementation Roadmap

This chapter translates the 11-dimensional research analysis into a sequenced, executable action plan. The roadmap is organised into four phases of escalating complexity, with each phase building upon the previous. Tasks are assigned to specific weeks, expected outcomes are quantified, and every action references the research findings justifying its priority.

### 12.1 Phase 1: Foundation (Weeks 1-2)

Phase 1 concentrates on actions with the highest cross-dimensional leverage — those advancing technical SEO, local SEO, GEO, and conversion optimisation simultaneously. The research identified 12 "quick wins" serving 20+ dimension recommendations, capable of delivering a 25-50% improvement in baseline visibility within 14 days[^1^].

#### 12.1.1 Week 1: Schema, Bing Webmaster, robots.txt, Title Tags, GBP

The first week addresses the six actions confirmed by five or more research dimensions as universally critical[^2^]. These can be executed in parallel.

**Schema Markup Deployment (4 hours):** Deploy a single JSON-LD `@graph` block containing LocalBusiness (HomeAndConstructionBusiness subtype), Organization, Service, FAQPage, AggregateRating, and BreadcrumbList schemas. This serves six dimensions simultaneously, producing a 35% GEO citation lift and 25-30% CTR increase from rich results eligibility[^3^]. FAQPage schema alone is cited at 3.2x higher rates by AI engines[^4^].

**Bing Webmaster Tools Verification (30 minutes):** Verify ownership and submit the XML sitemap. 87% of ChatGPT citations correspond to Bing top results — without Bing indexing, the site is invisible to ChatGPT's 800 million weekly active users[^5^].

**Google Business Profile Optimisation (4 hours):** Achieve 100% profile completion, upload 15+ installation and team photos, add up to 20 Sutherland Shire suburbs as service areas, and publish the first Google Post. A fully completed GBP receives 7x more clicks and 42% more direction requests[^6^].

**Title Tag and H1 Restructure (3 hours):** Front-load primary keywords, append "| Sutherland Shire" as a location suffix, and ensure each page has a single unique H1 matching the title tag's core phrase[^7^].

**NAP Consistency Audit (2 hours):** Document the canonical Name, Address, and Phone format and verify exact matches across the website, GBP, and existing listings. Even variations as minor as "St" versus "Street" dilute local authority[^8^].

**Mobile Click-to-Call and CTA Fixes (2 hours):** Add a sticky click-to-call button to the mobile viewport, convert all phone numbers to `tel:` links with 48x48px touch targets, and switch CTA copy to first-person ("Get My Free Quote"). Sticky click-to-call increases inbound calls by 30-100%[^9^]; first-person CTAs outperform by up to 90%[^10^].

**Master Security Licence Display (30 minutes):** Add Master Security Licence #000105713 to the header or footer of every page adjacent to the phone number — a top trust signal across five dimensions[^11^].

**Contact Form Reduction (1 hour):** Reduce to five fields: Name (required), Email (required), Phone (optional), Suburb (required), and Service Type (dropdown, required). Phone should be optional (it carries a 6.3% abandonment rate) and Message should also be optional[^12^].

#### 12.1.2 Week 2: ForceField vs Crimsafe Page, FAQ Page, Review System

**Create ForceField vs Crimsafe Comparison Page (8 hours):** The highest-ROI content investment identified. "Prowler Proof vs Crimsafe" attracts 600-900 monthly searches, the footer references this non-existent page, and no Sutherland Shire-specific comparison exists[^13^]. Include side-by-side comparison tables (316 Marine Grade vs 304 Structural Grade, fully welded vs screw-clamp, warranty differences), FAQ schema with 8-10 questions, and coastal corrosion context. Architect in three layers: a 60-80 word direct answer opening for GEO, a 1,000+ word body for SEO, and a structured FAQ section[^14^].

**Create Comprehensive FAQ Page (6 hours):** Build a dedicated page with 20+ questions, each answered in 40-60 self-contained words with FAQPage schema. The first two questions must be strategically chosen — Google displays only the first two as rich results[^15^]. Include pricing ranges, installation timelines, and Australian Standards references.

**Implement Systematic Review Generation (4 hours setup):** Configure an SMS review request system triggered 24 hours post-installation with a direct Google review link. Target 5-10 new reviews monthly, with 50+ reviews at 4.5+ stars within six months[^16^]. Businesses with 50+ reviews generate 50% more leads[^17^].

**Expand Existing Service Pages (12 hours):** Expand each of the six existing pages to 800-1,200 words with embedded FAQ sections using schema. Add contextual cross-links between services[^18^].

#### 12.1.3 Expected Outcomes

By end of Week 2: all six pages carry valid schema with zero errors; Bing Webmaster Tools reports indexed status; GBP is 100% complete with weekly posting active; the comparison and FAQ pages are published; the review system is sending requests; and all service pages are 800+ words. Estimated impact: 15-25% organic impression increase within 30 days.

### 12.2 Phase 2: Content Expansion (Weeks 3-8)

Phase 2 addresses the content deficit — the current six-page site cannot rank for 80%+ of relevant keywords, while competitors maintain 25-40 pages[^19^]. This phase delivers the 10 Tier 1 and 8 Tier 2 pages identified in the research.

#### 12.2.1 Weeks 3-4: Service Area + Three Suburb Pages + Pricing Guide

**Sutherland Shire Service Area Pillar Page (6 hours):** A 2,000+ word anchor page targeting "security doors Sutherland Shire" (200-400 monthly searches). Link to all suburb pages and establish topical authority, referencing local landmarks, housing characteristics, and Shire-specific security concerns (salt air, bushfire zones)[^20^].

**Cronulla, Miranda, and Caringbah Suburb Pages (12 hours):** Three landing pages with 400+ words of genuinely unique content each — not templated swaps. Cronulla emphasises coastal corrosion and 316 Marine Grade; Miranda references the commercial hub; Caringbah addresses mixed residential-commercial security needs[^21^]. Each must reference local landmarks, housing types, and suburb-specific testimonials.

**Security Door Pricing Guide (6 hours):** Target "how much do security doors cost Sydney" (500-800 monthly searches). Include ranges: entry-level hinged ($450+), stainless steel mesh ($700+), premium ForceField ($1,200-$1,600), window screens ($480-$700)[^22^].

#### 12.2.2 Weeks 5-6: Buying Guide + Window Screens Guide + Maintenance

**Security Doors Buying Guide (10 hours):** A 2,500+ word pillar targeting research-phase keywords. Include comparison tables, material specs, Australian Standards (AS5039, AS5040, AS5041), and FAQ schema[^23^]. This page becomes the anchor for the Security Doors content cluster, linking to the comparison page, pricing guide, installation process, and maintenance content.

**Window Security Screens Guide (8 hours):** Target "window security screens Sydney" (400-600 searches). Include Guardian Fall Prevention content and cross-sell links to security doors. Window screens naturally complement security doors — homeowners who secure their entry points often progress to window protection.

**Child Safety / Guardian Fall Prevention Page (6 hours):** Address NSW Planning Portal requirements for window safety devices. Target "fall prevention window screens Sydney" and "child safe window screens NSW" (200-350 searches each, Low-Medium competition)[^24^]. This content targets parents of young children in multi-storey homes — a high-emotion, high-conversion audience.

**How to Clean and Maintain Security Doors (4 hours):** A HowTo-schema guide for featured snippets, including coastal maintenance schedules and 316 Marine Grade care[^25^]. The coastal maintenance angle is unique to Sutherland Shire and provides genuine geographic differentiation.

#### 12.2.3 Weeks 7-8: More Suburb Pages + Shutter/Blind Content

**Gymea, Kirrawee, Sylvania Suburb Pages (12 hours):** Continue suburb rollout with 400+ unique words each. Gymea: village atmosphere and heritage homes. Kirrawee: residential-industrial mix. Sylvania: waterfront properties and salt air[^26^].

**Plantation Shutters Guide (8 hours):** Elevated to Tier 1 — "plantation shutters Sydney" commands 2,000-3,500 monthly searches, exceeding security doors (1,300-2,000). Capture this top-of-funnel traffic for cross-selling[^27^].

**Outdoor Blinds Guide (8 hours):** "Outdoor blinds Sydney" at 2,500-4,000 searches — the highest volume across all categories[^28^].

**316 Marine Grade vs 304 Stainless Steel (6 hours):** The technical differentiator establishing the geographic competitive moat for coastal homes[^29^].

#### 12.2.4 Expected Outcomes

By end of Week 8: 24+ indexed pages, each with 800+ words, embedded FAQ schema, and three-layer GEO-SEO architecture. Target: 50+ keywords ranking in positions 1-30, with 10+ in the top 10.

### 12.3 Phase 3: Authority Building (Weeks 9-12)

Phase 3 shifts to authority signals — backlinks, citations, E-E-A-T reinforcement, and brand mentions. Brand mention frequency is the strongest AI citation predictor (0.334 correlation), with the top 25% of brands earning 10x more AI citations[^30^].

#### 12.3.1 Directories, Link Building, Digital PR

**Australian Directory Submissions (8 hours):** Submit to 20 directories: Google Business Profile, Yellow Pages, True Local, Yelp Australia, Bing Places, Apple Business Connect, Facebook Business, Hotfrog, StartLocal, AussieWeb, hipages, Airtasker, OneFlare, Foursquare, Brownbook, Cylex, Localsearch, Word of Mouth, and ProductReview.com.au[^31^]. NAP must match the canonical format exactly.

**Local Backlinks (ongoing):** Join Sutherland Shire Business Chamber ($200-500/year) for a .org.au backlink. Sponsor a local sports team for a branded club website link. Local backlinks outperform national ones of higher domain authority for local SEO[^32^].

**Digital PR (ongoing):** Register with SourceBottle to respond to journalist queries. Target 1-3 media mentions per quarter[^33^].

**Guest Posting (12 hours):** Publish three guest posts on Australian home improvement blogs, each with a natural backlink to a relevant service page[^34^].

#### 12.3.2 E-E-A-T Content

**"Meet Steve" About Page (4 hours):** A personal brand page with credentials, photos, and 15+ years of experience. Human faces increase conversion by 48%[^35^]; 77% of consumers prefer businesses with a strong founder brand[^36^]. Advanced Security Doors has built recognition around "Corey" — Steve is an equally powerful but invisible asset[^37^]. Implement Person schema and author all blog content under Steve's byline.

**Case Studies (8 hours):** Publish 3-4 case studies with before/after photos from real Sutherland Shire installations. Include product specs, customer testimonials, and timelines[^38^].

**Original Research (12 hours):** Survey 20-30 customers (5-7 questions) and publish the "Sutherland Shire Home Security Report 2025" with infographics. Original research receives 4.31x more citations and provides a +41% AI visibility lift[^39^].

#### 12.3.3 Expected Outcomes

By end of Week 12: 20-25 referring domains from directory submissions, local sponsorships, guest posts, and organic link acquisition; 3-4 published case studies with before/after photography; an active review generation system producing 5-10 new reviews monthly; and one original research asset generating media interest and AI citations. Target: 50+ Google reviews at 4.5+ stars, with review response rate maintained at 100% within 24 hours.

### 12.4 Phase 4: GEO and Monitoring (Months 4-6)

Phase 4 addresses emerging GEO standards, sustained brand mention building, and systematic monitoring. Citation volatility research indicates 40-60% of AI-cited sources change monthly, requiring continuous optimisation[^40^].

#### 12.4.1 llms.txt, Brand Mentions, Forum Participation

**Create llms.txt (2 hours):** Implement an `llms.txt` file at root domain following the emerging standard for AI crawler transparency, complementing robots.txt[^41^].

**Brand Mention Strategy (3 hours/week):** Authentic participation on Reddit (r/Sydney, r/HomeImprovement), Quora (security-related answers), and local Facebook community groups. Target 2+ new brand mentions monthly[^42^].

**Seasonal Content (6 hours):** Publish the first seasonal piece — "Prepare Your Home for Bushfire Season" or "Summer Home Security Guide." Seasonal content generates compounding annual returns[^43^].

#### 12.4.2 AI Citation Monitoring

**Monthly AI Citation Audit:** Manually test 10-15 priority conversational queries across ChatGPT, Perplexity, Google AI Overviews, and Bing Copilot. Track citations, referenced pages, and competitor comparison[^44^].

**Quarterly Content Updates:** Refresh pricing, statistics, and "Last Updated" dates. AI-cited content averages 1,000 days old — freshness signals provide competitive advantage[^45^].

#### 12.4.3 Expected Outcomes

By end of Month 6: 10+ AI citations monthly across platforms; 25%+ AI Share of Voice; 10+ new referring domains; and 31+ indexed pages at 800+ average word count.

### 12.5 KPI Dashboard

| KPI Category | Metric | Baseline | 30-Day Target | 90-Day Target | 180-Day Target | Measurement Tool |
|---|---|---|---|---|---|---|
| **Traditional SEO** | Indexed pages | 6 | 6 (all optimised) | 24 | 31+ | Google Search Console |
| | Target keywords in top 10 | <5 | 5-8 | 15-20 | 25+ | Ahrefs / SEMrush |
| | Core Web Vitals (LCP) | Unknown | <2.5s | <2.0s | <1.8s | Vercel Speed Insights |
| | Referring domains | ~0-5 | 5-10 | 15-25 | 30-50 | Ahrefs |
| **Local SEO** | Google reviews (total) | Current count | +5-10 | +20-30 | 50+ | Google Business Profile |
| | Average review rating | Current | 4.5+ | 4.5+ | 4.5+ | Google Business Profile |
| | Local Pack position | Unknown | Positions 4-6 | Positions 2-3 | Position 1-3 | Local Falcon |
| | Directory citations | <5 | 10-15 | 20-25 | 30-40 | Manual audit |
| **GEO** | AI citation frequency | 0 | 2-3/month | 5-8/month | 10+/month | Manual testing |
| | Bing indexed pages | Unknown | 6 | 24 | 31+ | Bing Webmaster Tools |
| | AI Share of Voice | 0% | 5-10% | 15-20% | 25%+ | Brand vs competitor audit |
| | Schema error rate | 100% (no schema) | 0% | 0% | 0% | Rich Results Test |
| **Business** | Organic impressions | Current | +15-25% | +60-80% | +120-150% | Google Search Console |
| | Phone calls from website | Current | +30-50% | +60-80% | +100%+ | Call tracking |
| | Form submissions | Current | +20-30% | +50-70% | +80-100% | GA4 |
| | Visitor-to-lead rate | Unknown | 2-3% | 3-4% | 3-5% | GA4 |

#### 12.5.1 Traditional SEO KPIs

Traditional SEO tracks indexed pages growing from 6 to 31+ by Month 6; keyword rankings expanding from fewer than 5 to 25+ in the top 10; and Core Web Vitals improving through Next.js platform advantages (dynamic sitemap.ts, next/image, ISR)[^46^]. The referring domain target of 30-50 aligns with 20 directory submissions, local sponsorships, guest posts, and organic acquisition from original research.

#### 12.5.2 Local SEO KPIs

Local SEO centres on review velocity (50+ at 4.5+ stars within 180 days, requiring 5-10 monthly)[^47^] and Local Pack progression from positions 4-6 to 1-3, driven by GBP optimisation, NAP consistency across 30-40 citations, and suburb page publication[^48^].

#### 12.5.3 GEO KPIs

GEO measurement requires manual testing across ChatGPT, Perplexity, Google AI Overviews, and Bing Copilot using 10-15 standardised conversational queries[^49^]. AI citation frequency should grow from zero to 10+ monthly, driven by schema, answer-first architecture, FAQ deployment, brand mentions, and original research. Bing indexed pages serve as a ChatGPT visibility proxy given the 87% citation correlation[^50^].

#### 12.5.4 Business KPIs

Business outcomes connect SEO and GEO activity directly to revenue. The 100%+ phone call increase target by Month 6 is driven by the combined effect of sticky click-to-call implementation (30-100% lift), GBP optimisation (7x clicks multiplier), suburb page local traffic, and review volume reaching the 50+ threshold that generates 50% more leads[^51^]. Form submission improvements rely on the five-field form reduction (~120% conversion lift) and first-person CTA language (up to 90% CTR increase)[^52^]. The 3-5% visitor-to-lead conversion rate target represents trade-industry best practice, supported by trust badge placement, Master Licence display, published case studies, and systematic review generation creating a compounding trust flywheel.
