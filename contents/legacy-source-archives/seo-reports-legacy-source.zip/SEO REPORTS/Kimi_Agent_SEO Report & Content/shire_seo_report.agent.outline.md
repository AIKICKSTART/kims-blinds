# Shire Security Doors & Screens — Comprehensive SEO & GEO Strategy Report

## Executive Summary
### Strategic Overview
#### Current website (6 pages) is structurally incapable of ranking for 80%+ of relevant keywords; competitors average 25-40 pages
#### Three-pillar approach: Traditional SEO + Local SEO + Generative Engine Optimization (GEO) must work together
#### 25 cross-dimensional insights reveal critical quick wins: schema markup (4-hour task, 6-dimension impact), Bing Webmaster registration (30 minutes), review generation flywheel
#### Target: 10 Tier 1 content pages within 30 days, 50+ Google reviews within 90 days, AI citation visibility within 60 days
### Key Metrics
#### Australian home security market: USD 2.2B (2025) → USD 5.3B (2034), 9.70% CAGR
#### Primary keywords: "security doors sydney" (1,300-2,000/mo), "plantation shutters sydney" (2,000-3,500/mo), "outdoor blinds sydney" (2,500-4,000/mo)
#### GEO opportunity: 48% of Google queries now show AI Overviews; ChatGPT has 800M weekly active users

## 1. Technical SEO Audit (~2500 words, 2 tables)
### 1.1 Current Technical State
#### 1.1.1 Next.js on Vercel provides solid foundation with automatic HTTPS and CDN distribution
#### 1.1.2 Missing technical elements: XML sitemap, robots.txt optimization, canonical tags, breadcrumb navigation
#### 1.1.3 Image optimization needed: next/image implementation with proper width/height attributes and alt text
### 1.2 Core Web Vitals Requirements
#### 1.2.1 Target thresholds: LCP < 2.5s, INP < 200ms, CLS < 0.1 for Google ranking signals
#### 1.2.2 Vercel Speed Insights recommended for continuous Core Web Vitals monitoring
#### 1.2.3 Image compression strategy for product photos and gallery images (security door installations)
### 1.3 Site Architecture & URL Structure
#### 1.3.1 Current /services/ prefix is appropriate; maintain hierarchical structure for new pages
#### 1.3.2 Recommended URL patterns: /[service]/, /service-areas/[suburb]/, /guides/[topic]/, /faq/
#### 1.3.3 Internal linking strategy: 3-5 contextual links per 1000 words, descriptive anchor text
### 1.4 Mobile-First & Performance
#### 1.4.1 68% of Australian searches are mobile; mobile visitors 8x more likely to call
#### 1.4.2 Click-to-call implementation: tel:0410474256 protocol on all phone numbers
#### 1.4.3 Sticky CTA button recommendation for mobile (+25% sales based on industry data)
### 1.5 GEO Technical Foundations
#### 1.5.1 Bing Webmaster Tools registration is CRITICAL — 87% of ChatGPT citations come from Bing index
#### 1.5.2 robots.txt must NOT block GPTBot, ClaudeBot, PerplexityBot, ChatGPT-User, BingBot
#### 1.5.3 llms.txt file creation to guide AI crawlers to priority content
#### 1.5.4 Server-side rendering (SSR) verification — ensure content not hidden behind JavaScript for AI crawlers

## 2. On-Page SEO Optimization (~2500 words, 1 table)
### 2.1 Title Tag & Meta Description Optimization
#### 2.1.1 Title tag formula: [Primary Keyword] | [Secondary] — [Brand] — keep under 60 characters
#### 2.1.2 Meta description formula: compelling copy with primary keyword + CTA — 120-160 characters
#### 2.1.3 Page-by-page title and meta recommendations for all 6 current pages (table)
### 2.2 Heading Structure (H1-H6)
#### 2.2.1 H1 must include primary keyword + location (e.g., "Security Doors Sutherland Shire & Sydney")
#### 2.2.2 H2/H3 structure: question-based headers mirroring actual search queries for featured snippets
#### 2.2.3 One H1 per page; logical hierarchy without skips
### 2.3 Content Optimization
#### 2.3.1 Service pages need expansion from current thin content to 800-1,200 words minimum
#### 2.3.2 Keyword density: 1-2% natural placement; prioritize readability over exact-match
#### 2.3.3 LSI keywords and semantic search optimization (related terms: "security screen doors", "home security")
### 2.4 Image Optimization
#### 2.4.1 All images need descriptive alt text (5-15 words) including location and service context
#### 2.4.2 Image filename optimization: security-doors-cronulla.jpg vs IMG_1234.jpg
#### 2.4.3 WebP format with fallback; lazy loading for below-fold images

## 3. Keyword Research & Strategy (~3000 words, 3 tables)
### 3.1 Primary Keywords (High Volume, Commercial Intent)
#### 3.1.1 Security doors cluster: "security doors sydney" (1,300-2,000/mo), "security screen doors sydney" (600-900/mo), "security doors sutherland shire" (200-400/mo)
#### 3.1.2 Plantation shutters cluster: "plantation shutters sydney" (2,000-3,500/mo), "plantation shutters sutherland shire" (300-500/mo)
#### 3.1.3 Outdoor blinds cluster: "outdoor blinds sydney" (2,500-4,000/mo), "zip track outdoor blinds sydney" (400-600/mo)
### 3.2 Branded & Comparison Keywords
#### 3.2.1 Prowler Proof branded: "prowler proof" (3,000-5,000/mo nationally), "prowler proof sydney" (500-800/mo), "prowler proof sutherland shire" (50-100/mo)
#### 3.2.2 Comparison keywords: "prowler proof vs crimsafe" (600-900/mo), "forcefield vs crimsafe" (200-350/mo)
#### 3.2.3 Branded + location: competitive moat against other Prowler Proof dealers
### 3.3 Long-Tail & Question Keywords
#### 3.3.1 Cost queries: "how much do security doors cost sydney" (500-800/mo), "security door installation cost" (300-500/mo)
#### 3.3.2 Problem/solution: "best security doors for coastal homes" (100-200/mo), "child safe window screens nsw" (200-350/mo)
#### 3.3.3 How-to queries: "how to clean security doors" (200-350/mo), "how to measure for security screen" (150-250/mo)
### 3.4 Location-Specific Keywords
#### 3.4.1 Top 10 Sutherland Shire suburbs by search volume with competition level (table)
#### 3.4.2 Suburb page strategy: unique content per suburb, not templated swaps
#### 3.4.3 Service area expansion keywords beyond Sutherland Shire

## 4. Local SEO Strategy (~2500 words, 2 tables)
### 4.1 Google Business Profile Optimization
#### 4.1.1 Primary category: "Security System Installer" — secondary categories to add
#### 4.1.2 Business description optimization with keywords, services, and service areas
#### 4.1.3 Photo strategy: upload 20+ high-quality photos (products, installations, team, before/after)
#### 4.1.4 GBP post schedule: weekly posts with offers, tips, and completed project photos
### 4.2 NAP Consistency & Citations
#### 4.2.1 NAP audit across all platforms — even minor formatting variations harm rankings
#### 4.2.2 Top 20 Australian business directories for submission (table with URLs)
#### 4.2.3 Industry-specific directories: NSSA member directory, Prowler Proof dealer locator
### 4.3 Review Generation Strategy
#### 4.3.1 Target: 5-10 new Google reviews per month; 50+ reviews at 4.5+ stars within 90 days
#### 4.3.2 SMS review request system: automated follow-up 24-48 hours post-installation
#### 4.3.3 Review response template for all reviews (positive and negative)
### 4.4 Service Area Pages
#### 4.4.1 Sutherland Shire anchor page: comprehensive overview with suburb links
#### 4.4.2 Individual suburb pages: Cronulla, Miranda, Caringbah, Gymea, Sutherland, Menai, Engadine, etc.
#### 4.4.3 Suburb page content formula: local landmarks, housing types, security concerns, local projects

## 5. Generative Engine Optimization (GEO) (~3000 words, 2 tables)
### 5.1 Understanding AI Search Engines
#### 5.1.1 How ChatGPT, Perplexity, Google AI Overviews, and Gemini select sources to cite
#### 5.1.2 Retrieval-Augmented Generation (RAG) process: semantic understanding → retrieval → generation → citation
#### 5.1.3 Key difference: GEO focuses on being CITED, not just ranking in blue links
### 5.2 GEO Content Structure
#### 5.2.1 Answer-first framework: direct answer in first 50-80 words (disproportionately influences AI citations)
#### 5.2.2 Three-layer page architecture: (1) Direct answer box 60-80 words, (2) Comprehensive body 1000+ words, (3) FAQ section with schema 5-8 questions
#### 5.2.3 Statistics and hard data: +41% visibility lift from unique, citable statistics (Princeton study)
### 5.3 Conversational Query Optimization
#### 5.3.1 30+ conversational queries to optimize for (table organized by category)
#### 5.3.2 Question-based H2/H3 headers mirroring natural language questions
#### 5.3.3 Atomic answers: standalone 40-60 word paragraphs AI can cite directly
### 5.4 Brand Mention & Authority Strategy
#### 5.4.1 Brand mentions show 0.664 correlation with AI Overview visibility — strongest predictor
#### 5.4.2 Reddit and forum participation strategy for local community discussions
#### 5.4.3 Digital PR: SourceBottle (Australian HARO), local press mentions, expert roundups
### 5.5 GEO Measurement
#### 5.5.1 KPIs: AI Citation Rate, Share of Model, brand mention accuracy, referral traffic from AI
#### 5.5.2 Manual tracking spreadsheet: query tested, AI platform, cited?, position, date
#### 5.5.3 Monthly AI visibility audit process

## 6. Schema Markup & Structured Data (~2500 words, 1 table, code blocks)
### 6.1 Schema Strategy Overview
#### 6.1.1 Schema markup is single highest-leverage action: serves SEO, GEO, CRO, Local SEO, E-E-A-T simultaneously
#### 6.1.2 JSON-LD @graph approach: stack multiple schema types in single block
#### 6.1.3 35% increase in AI citation probability with structured data
### 6.2 Required Schema Types
#### 6.2.1 LocalBusiness schema: name, address, geo, hours, priceRange, hasOfferCatalog, areaServed
#### 6.2.2 Service schema for each of 4 service categories via hasOfferCatalog
#### 6.2.3 FAQPage schema: #1 structured data type for AI citations (3.2x featured snippet rate)
#### 6.2.4 Organization schema with sameAs links for Knowledge Graph
#### 6.2.5 BreadcrumbList schema for all pages
#### 6.2.6 HowTo schema for guides and installation content
### 6.3 Implementation
#### 6.3.1 Complete JSON-LD @graph block for homepage (copy-paste ready code)
#### 6.3.2 Per-page schema recommendations
#### 6.3.3 Testing and validation with Google Rich Results Test and Schema.org Validator

## 7. E-E-A-T Enhancement Plan (~2000 words, 1 table)
### 7.1 Experience & Expertise Signals
#### 7.1.1 Owner "Steve" as author entity: bylines on all content with Person schema and LinkedIn profile
#### 7.1.2 "Meet Steve" page with credentials, photos, personal story, and 10+ years experience
#### 7.1.3 Case studies with real customer names, photos, and detailed project descriptions
### 7.2 Authoritativeness Signals
#### 7.2.1 Master Security Licence #000105713: prominent display on every page
#### 7.2.2 NSSA membership and Prowler Proof Authorised Dealer badges
#### 7.2.3 Industry content: security guides referencing Australian Standards (AS 5039, AS 2047)
### 7.3 Trustworthiness Signals
#### 7.3.1 About Us page: company history, values, team photos, physical location
#### 7.3.2 Contact information prominently displayed: phone (0410 474 256), email (steve@shiredoors.com.au)
#### 7.3.3 Privacy policy and terms of service pages
#### 7.3.4 SSL certificate and secure browsing indicators

## 8. Content Strategy & New Page Recommendations (~3000 words, 2 tables)
### 8.1 Content Gap Analysis
#### 8.1.1 Current 6 pages vs competitor average of 25-40 pages: structural content deficit
#### 8.1.2 Footer references 5 non-existent pages: Service areas, Security guides, FAQ, ForceField vs Crimsafe, Pricing guide
#### 8.1.3 Topic cluster architecture needed: 5 pillar clusters identified
### 8.2 Tier 1 Priority Pages (Create in Month 1)
#### 8.2.1 ForceField vs Crimsafe Comparison: 600-900 monthly searches, highest commercial-intent gap
#### 8.2.2 FAQ Page: 20+ questions with FAQPage schema, #1 structured data for AI citations
#### 8.2.3 Sutherland Shire Service Area: local SEO anchor page
#### 8.2.4 Security Door Pricing Guide: "how much do security doors cost" — 500-800 searches/mo
#### 8.2.5 Security Doors Buying Guide: 2,500+ word topical authority pillar
#### 8.2.6-8.2.10 Suburb pages: Cronulla, Miranda, Caringbah + coastal corrosion guide + maintenance guide
### 8.3 Tier 2 & 3 Pages (Months 2-6)
#### 8.3.1 Additional suburb pages (8 more), window screens guide, shutter guides, blind guides
#### 8.3.2 How-to content with HowTo schema: cleaning, measuring, choosing products
#### 8.3.3 Seasonal content: summer security prep, winter maintenance, holiday security tips

## 9. Competitor Analysis (~2000 words, 2 tables)
### 9.1 Top 10 Competitors
#### 9.1.1 Direct competitors: SP Screens Sutherland Shire (4.7 stars, 130+ reviews), Advanced Security Doors (5.0, 220+ reviews), Kings Security Doors, Decor Lace
#### 9.1.2 Indirect competitors: Empire Window Furnishings (1,600+ reviews), Sydney Wide Security Doors, Serious Security
#### 9.1.3 Competitor strengths/weaknesses matrix (table)
### 9.2 Competitive Positioning
#### 9.2.1 Key differentiators: Prowler Proof 316 Marine Grade, fully welded corners, 10-year full replacement warranty
#### 9.2.2 Coastal corrosion angle: unique advantage for Cronulla, Bundeena, Port Hacking
#### 9.2.3 Family-owned local service vs corporate chains
### 9.3 Content & Keyword Gaps
#### 9.3.1 No competitor has Sutherland Shire-specific brand comparison guide
#### 9.3.2 Suburb pages are blue ocean territory — very low competition
#### 9.3.3 Pricing transparency gap: few competitors publish pricing guidance

## 10. Conversion Rate Optimization (~2000 words, 1 table)
### 10.1 CTA Optimization
#### 10.1.1 Primary CTA "Free Measure & Quote" — optimize placement above fold on all pages
#### 10.1.2 Secondary CTA "Call Steve" with click-to-call: tel:0410474256
#### 10.1.3 First-person CTA testing: "Get My Free Quote" vs "Get Your Free Quote" (+90% CTR potential)
### 10.2 Trust Signal Placement
#### 10.2.1 Master Security Licence #000105713 badge: above fold on every page
#### 10.2.2 10-year warranty badge: prominent placement near pricing mentions
#### 10.2.3 Testimonials: 3+ per page increases conversion 34%; video testimonials highest impact
### 10.3 Form & Contact Optimization
#### 10.3.1 Quote form: reduce to 5 fields or fewer (+120% conversion)
#### 10.3.2 Form placement: sticky sidebar on desktop, inline on mobile
#### 10.3.3 Response speed commitment: "We respond within 1 hour" — first responder wins 78% of trade jobs

## 11. Off-Page SEO & Link Building (~2000 words, 1 table)
### 11.1 Local Link Building
#### 11.1.1 Sutherland Shire Business Chamber membership ($200-500/yr, .org.au backlink)
#### 11.1.2 Local sports team sponsorships ($250-500, community visibility + .org backlink)
#### 11.1.3 Local event sponsorships and community engagement
### 11.2 Industry & Manufacturer Links
#### 11.2.1 NSSA member directory backlink
#### 11.2.2 Prowler Proof authorised dealer directory listing
#### 11.2.3 Supplier and trade partner link opportunities
### 11.3 Directory Submissions
#### 11.3.1 Tier 1 directories: Google Business Profile, TrueLocal, Yelp AU, Word of Mouth, StartLocal
#### 11.3.2 Tier 2 directories: industry-specific (security, home improvement)
#### 11.3.3 Tier 3 directories: general Australian business listings
### 11.4 Digital PR & Brand Mentions
#### 11.4.1 SourceBottle registration (Australian HARO) for journalist queries
#### 11.4.2 Local press: St George & Sutherland Shire Leader
#### 11.4.3 Expert commentary on home security topics

## 12. Implementation Roadmap (~2500 words, 1 table, timeline)
### 12.1 Phase 1: Foundation (Weeks 1-2)
#### 12.1.1 Week 1 critical actions: schema markup, Bing Webmaster, robots.txt, title tags, GBP optimization
#### 12.1.2 Week 2: ForceField vs Crimsafe page, FAQ page, review generation system setup
#### 12.1.3 Expected outcomes: technical foundation complete, 2 new pages published
### 12.2 Phase 2: Content Expansion (Weeks 3-8)
#### 12.2.1 Weeks 3-4: Service area page + 3 suburb pages + pricing guide
#### 12.2.2 Weeks 5-6: Buying guide + window screens guide + maintenance guide
#### 12.2.3 Weeks 7-8: Additional suburb pages + shutter/blind content expansion
#### 12.2.4 Expected outcomes: 10+ new pages published, keyword coverage expanded 3x
### 12.3 Phase 3: Authority Building (Weeks 9-12)
#### 12.3.1 Weeks 9-10: Directory submissions (20+), local link building, digital PR outreach
#### 12.3.2 Weeks 11-12: E-E-A-T content (case studies, Steve profile, industry guides)
#### 12.3.3 Expected outcomes: 30+ new backlinks, 50+ reviews, topical authority established
### 12.4 Phase 4: GEO Optimization & Monitoring (Months 4-6)
#### 12.4.1 Month 4: llms.txt deployment, brand mention campaign, Reddit/forum participation
#### 12.4.2 Months 5-6: AI citation monitoring, content refresh cycle, seasonal content
#### 12.4.3 Expected outcomes: AI citations across 4+ platforms, measurable referral traffic from AI
### 12.5 KPI Dashboard & Success Metrics
#### 12.5.1 Traditional SEO KPIs: organic traffic, keyword rankings, CTR, bounce rate
#### 12.5.2 Local SEO KPIs: Local Pack position, review count/rating, GBP impressions/actions
#### 12.5.3 GEO KPIs: AI citation rate, Share of Model, brand mention accuracy
#### 12.5.4 Business KPIs: quote requests, phone calls, conversion rate

# References
## shire_seo_report.agent.outline.md
- **Type**: Report outline
- **Description**: This outline file
- **Path**: /mnt/agents/output/shire_seo_report.agent.outline.md

## Research Dimension Files
- **Type**: Deep research artifacts
- **Description**: 11 dimension files covering all SEO/GEO aspects
- **Path**: /mnt/agents/output/research/seo_geo_dim01.md through seo_geo_dim11.md

## Cross-Verification
- **Type**: Research quality verification
- **Description**: Confidence tiers and conflict analysis
- **Path**: /mnt/agents/output/research/seo_geo_cross_verification.md

## Insights
- **Type**: Strategic insights
- **Description**: Cross-dimensional insights
- **Path**: /mnt/agents/output/research/seo_geo_insight.md

## Synthesis
- **Type**: Research synthesis
- **Description**: Consolidated research findings
- **Path**: /mnt/agents/output/research/synthesis_document.md
