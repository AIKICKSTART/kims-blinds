## 2. On-Page SEO Optimisation

On-page SEO remains the foundational layer upon which every other optimisation effort depends. For Shire Security Doors and Screens, the current website presents a familiar picture for a family-owned trade business: a clean, professionally designed site with strong trust signals (Prowler Proof authorisation, Master Security Licence #000105713, NSSA membership) but thin content, under-optimised title tags, and missing structured data. Research across 250+ sources confirms that on-page signals — title tags, heading hierarchy, content depth, and image optimisation — are the variables most directly under the business's control and the fastest path to measurable ranking improvements [^31^][^32^][^33^]. This chapter provides the AI agent with precise, executable instructions for every page.

### 2.1 Title Tag and Meta Description Optimisation

#### 2.1.1 Title Tag Formula

The title tag is the single most impactful on-page element for both rankings and click-through rate. Research from 2025-2026 confirms that search engines assign greater weight to the first few words [^45^], which means front-loading the primary keyword is non-negotiable. The formula for every page on the Shire Security Doors site is:

**[Primary Keyword] | [Secondary Qualifier] — [Brand]**

Key constraints: keep the total character count under 60 characters to avoid truncation in search results, include the location qualifier ("Sutherland Shire" or "Sydney") for every location-relevant page, and place the brand name at the end [^31^][^37^]. For service pages, the more specific formula is: **Service + Qualifier + Location — Brand** [^31^]. The current homepage title — "Shire Security Doors and Screens | Security Doors Sutherland Shire" — violates the front-loading principle by leading with the brand name rather than the primary keyword. Each service page title must include both the target keyword and location within the 60-character limit [^32^].

#### 2.1.2 Meta Description Formula

Meta descriptions, while not a direct ranking factor, function as the page's advertisement in search results and are a major lever for click-through rate [^31^]. The optimal length is 120-160 characters, with mobile devices typically truncating earlier [^31^][^32^]. Every meta description must feature local keywords, a unique selling proposition specific to that page, and a compelling call-to-action. The formula is:

**[Primary service] + [Location] + [Key differentiator] + [CTA]**

Each of the six pages requires a unique meta description — duplicate or missing descriptions represent missed opportunities to match searcher intent [^32^]. Descriptions should include the Prowler Proof authorisation, the free measure and quote offer, or the licence number as trust signals where space permits.

#### 2.1.3 Page-by-Page Title and Meta Recommendations

The table below provides the exact title tag and meta description for each of the six current pages, engineered to the formulas above with character counts verified.

| Page | Current Title | Recommended Title (Chars) | Recommended Meta Description (Chars) |
|------|--------------|---------------------------|--------------------------------------|
| Homepage | Shire Security Doors and Screens \| Security Doors Sutherland Shire | Security Doors & Screens Sutherland Shire \| Prowler Proof Dealer (54) | Prowler Proof authorised dealer installing security doors, window screens, plantation shutters & outdoor blinds across Sutherland Shire. Free measure & quote. Lic #000105713. (159) |
| Security Doors | Security Doors Sydney \| Shire Security Doors and Screens | Security Doors Sutherland Shire & Sydney \| Prowler Proof (59) | Custom hinged & sliding security doors installed across Sutherland Shire. Prowler Proof ForceField, Protec & Diamond options. Free measure & quote. Call today. (160) |
| Window Screens | Security Screens Sydney \| Shire Security Doors and Screens | Security Window Screens Sutherland Shire \| Prowler Proof (60) | Prowler Proof security window screens for fixed, hinged, sliding & elevated windows across Sutherland Shire. Guardian fall prevention available. Free quote. (159) |
| Plantation Shutters | Plantation Shutters Sydney \| Shire Security Doors and Screens | Plantation Shutters Sutherland Shire \| Supply & Install (56) | Custom Thermopoly plantation shutters for windows & doors across Sutherland Shire. Light control, privacy & temperature comfort. Free in-home measure & quote. (158) |
| Outdoor Blinds | Outdoor Blinds Sydney \| Shire Security Doors and Screens | Outdoor Blinds Sutherland Shire & Sydney \| Supply & Install (60) | Premium outdoor blinds for patios, alfresco areas & balconies across Sutherland Shire. Weather protection with style. Free on-site measure & quote available. (158) |
| Contact | (Generic or missing) | Contact Us \| Security Door Installer Sutherland Shire (55) | Contact Shire Security Doors for a free measure & quote across Sutherland Shire. Licensed installer. Prowler Proof authorised dealer. Call or enquire online. (160) |

Every recommended title front-loads the primary service keyword, includes the Sutherland Shire location qualifier, and stays within the 60-character truncation threshold [^31^][^45^]. The homepage title adds "Prowler Proof Dealer" as a trust signal because brand recognition for Prowler Proof drives significant branded search volume (3,000-5,000 monthly searches) [^139^]. Meta descriptions are each unique, include all four services on the homepage, specify product ranges on service pages, and close with a call-to-action [^32^][^37^]. The licence number inclusion on the homepage meta description reinforces the Master Security Licence #000105713 trust signal that the cross-verification analysis identified as critical across five independent research dimensions.

### 2.2 Heading Structure (H1-H6)

#### 2.2.1 H1 Must Include Primary Keyword and Location

The H1 tag serves as the page's primary topical promise — it tells both readers and search crawlers what the page is about [^33^]. For a local service business, the H1 must include the primary service keyword plus the geographic qualifier. The formula is: **{Service} in {Location}** [^32^][^33^]. The current Security Doors page uses "Security Doors" as its H1, which fails to signal geographic relevance. The corrected H1 is "Security Doors in Sutherland Shire." This same pattern applies to every service page: "Security Window Screens in Sutherland Shire," "Plantation Shutters in Sutherland Shire," and "Outdoor Blinds in Sutherland Shire." The homepage H1 becomes "Security Doors and Screens in Sutherland Shire." Each H1 must be the only H1 on its page — duplicate H1s dilute topical focus and confuse crawlers [^33^].

#### 2.2.2 H2 and H3 Structure: Question-Based Headers Mirroring Search Queries

H2 tags function as the main supporting sections of the page topic, and each should answer a meaningful sub-question or decision point that a prospective customer actually has [^33^]. The recommended structure follows the buyer evaluation flow: Problem → Solution → Proof → Next Step, which is the template most effective for service pages [^33^]. For the Security Doors page, the H2 sequence is: "Custom Security Door Solutions for Your Home" (introduction), "Our Security Door Range" (solution), "Why Choose Prowler Proof Security Doors" (proof), "Security Door Installation Process" (process), "Security Doors for Coastal Homes" (location-specific value), "Service Areas" (local relevance), "Frequently Asked Questions" (objection handling), and "Get a Free Security Door Quote" (next step). Under each H2, H3 tags subdivide the content into scannable sections — for example, under "Our Security Door Range," H3s cover ForceField, Protec, Sliding, and Diamond options.

Crucially, H2 and H3 headings should be written as questions or statements that mirror actual search queries. Question-based headers such as "What Is the Best Security Door for a Beachside Home?" or "How Much Does a Prowler Proof Security Door Cost?" align with voice search patterns and improve the probability of featured snippet capture [^83^]. The first one to two sentences under each H2 should answer the heading directly — this improves reader clarity and creates snippet-ready sections that Google can extract for position-zero results [^33^].

#### 2.2.3 One H1 Per Page; Logical Hierarchy Without Skips

The heading hierarchy must not skip levels — jumping from H2 to H4 because a template "looks right" breaks the semantic structure that search engines use to understand content relationships [^33^][^42^]. H3 tags should only appear when an H2 requires sub-structure. Headings must make sense out of context because search can surface a section without the rest of the page [^42^]. For every page on the Shire Security Doors site, the hierarchy is: one H1 → multiple H2s → H3s only as children of H2s → H4s only where deep technical subdivision is required (for example, under warranty terms or installation specifications). Headings should never be used as styling elements — if a visual design requires large text that is not a structural section header, use CSS rather than a heading tag [^33^].

### 2.3 Content Optimisation

#### 2.3.1 Service Page Content Expansion

The current service pages contain approximately 200-300 words of body text each, which sits well below the minimum threshold for competitive ranking. Research confirms that while Google does not use word count as a direct ranking signal — text-length factors dropped to zero in correlation studies — what matters is topical coverage, relevance, and completeness [^128^][^131^]. A 1,000-word page can outrank a 3,000-word article if it better aligns with searcher needs [^131^]. For local trade service pages, the practical target is 800-1,200 words of genuinely useful content [^126^][^130^].

Each service page must expand from its current 200-300 words to a minimum of 800 words, with the Security Doors page (the highest-priority service) targeting 1,000-1,200 words. The homepage should expand from approximately 150 words to 600-900 words. Content expansion must follow the H2/H3 structure outlined in Section 2.2 and include: a direct answer paragraph in the first 60-80 words (optimised for AI search citations), product range descriptions, location-specific content (coastal conditions for Sutherland Shire homes), service area lists with suburb names (Cronulla, Caringbah, Miranda, Gymea, Sutherland, Menai, Bangor, and others), an FAQ section with five to eight question-answer pairs, and a testimonial or social proof section. NSW Police data shows more than 80% of residential burglaries enter through a door or accessible window [^189^] — this statistic should appear in the Security Doors page introduction as a behavioural driver.

The cross-verification analysis identified content expansion from six pages to 25+ as a universal priority across five research dimensions, confirming that competitor sites ranking well maintain 25-40+ indexed pages while the current site has only six.

#### 2.3.2 Keyword Density: 1-2% Natural Placement

Ideal keyword density falls between 1% and 2% when content is written naturally for human readers [^34^][^36^]. Google's NLP-based ranking algorithms reward clarity and coherence, not keyword repetition [^34^]. For an 800-word page targeting "security doors Sutherland Shire," the primary keyword should appear 8-12 times maximum, including its natural variants.

Strategic placement matters more than exact frequency. The primary keyword must appear in: the title tag and meta description, the H1 heading, the first 100 words of body content, at least one H2 heading, image alt text, and the anchor text of internal links pointing to the page [^34^][^38^]. The first 100 words carry extra weight with search engines — include the target keyword naturally within this opening section without forcing it [^38^]. For the Security Doors page, the first 100 words should include "security doors" and "Sutherland Shire" in a natural sentence such as: "We design, manufacture, and install custom security doors across Sutherland Shire, from Cronulla to Menai."

#### 2.3.3 LSI Keywords and Semantic Search Optimisation

Modern search engines use natural language processing to understand semantic relationships between terms, which means repeating the exact target keyword is no longer necessary or advisable [^35^][^34^]. Instead, content should incorporate Latent Semantic Indexing (LSI) keywords — synonyms and related terms that are contextually relevant to the main keyword [^35^]. For the Security Doors page, semantic variations include: "security screen doors," "home security doors Sydney," "stainless steel security doors," "Prowler Proof doors," "hinged security doors," "sliding security doors," and "marine grade security screens." For the Window Screens page, use variants such as "window security screens," "fall prevention screens," "Guardian screens," "316 stainless steel mesh," and "security screen installation."

The Plantation Shutters page should semantically connect to "indoor shutters," "Thermopoly shutters," "window shutters Sydney," and "shutter installation Sutherland Shire." This semantic approach signals comprehensive topical coverage to Google's NLP algorithms while producing more natural, readable content for prospective customers [^35^]. The keyword research identifies specific product-name keywords (ForceField, Protec, Guardian, Diamond) that should appear on their respective service pages as branded semantic signals.

### 2.4 Image Optimisation

#### 2.4.1 Descriptive Alt Text (5-15 Words)

Every image on the site requires descriptive alt text that serves both accessibility (screen readers) and SEO (image indexing, relevance signals) [^48^][^51^]. The optimal length is 5-15 words or approximately 125 characters [^48^]. Alt text must be precise, context-related, and include the primary keyword naturally without keyword stuffing [^51^]. For a local business, geographic detail should be added where relevant — for example, "Prowler Proof ForceField stainless steel security door installed on Sutherland Shire home front entry" rather than the generic "security door" [^51^].

Product images should include product name, material, and context [^48^]. Specific alt text examples for the Security Doors page include: "Prowler Proof ForceField stainless steel security door installed on Sutherland Shire home front entry" (11 words), "Sliding security door on patio overlooking Sutherland Shire backyard" (10 words), "Lockwood 3-point lock system on Prowler Proof security door" (10 words), and "Hidden Installation Technology security door frame detail close-up" (9 words). Each alt tag must be unique — duplicate alt text across multiple images wastes a ranking signal opportunity and creates a poor accessibility experience.

#### 2.4.2 Image Filename Optimisation

Image filenames should use descriptive, keyword-rich phrases separated by hyphens, not underscores or spaces [^49^]. Before uploading, every image filename must be renamed from generic defaults (such as IMG_1234.jpg) to descriptive formats such as: `prowler-proof-forcefield-security-door-sutherland-shire.jpg`, `sliding-security-door-cronulla-installation.jpg`, or `plantation-shutters-thermopoly-sutherland-shire-home.jpg`. Hyphens are treated as word separators by Google, while underscores join words together into a single string [^49^]. Filenames should include the primary service keyword and location where contextually appropriate.

#### 2.4.3 WebP Format with Fallback and Lazy Loading

All images should be served in WebP format with JPEG fallback for older browsers. The site is built on Next.js hosted on Vercel, which provides the built-in `next/image` component — this component automatically serves images in WebP or AVIF format (whichever the browser supports), handles responsive sizing, and implements lazy loading without additional configuration [^49^]. The AI agent must ensure every `<img>` tag is converted to the Next.js `<Image>` component with proper width, height, and priority attributes. Above-the-fold images (hero section) should use `priority={true}` to prevent lazy loading of critical visual content, while all below-the-fold images should lazy-load to improve Largest Contentful Paint. Alt text must be specified as the `alt` prop on every Image component — missing alt attributes represent both an accessibility failure and a missed SEO signal [^48^][^51^].

The combination of optimised alt text, descriptive filenames, modern format delivery, and lazy loading creates a comprehensive image optimisation layer that improves page speed, accessibility compliance, and image search visibility — the latter being particularly valuable for a visually-driven product business where customers search for specific door styles and installation examples.
